#!/usr/bin/env python3
"""Mandarin OS · Panel de control (como el de Windows 7).

Portada «Ajustar la configuración del equipo» con las ocho categorías y sus enlaces, «Ver por»
Categoría o Iconos grandes, y páginas propias: Sistema, Personalización, Desinstalar un programa,
Dispositivos y Cuentas de usuario. Lo demás abre la herramienta de XFCE que corresponde.

Uso: mandarin-panel [sistema | apariencia | programas | dispositivos | usuario]
"""
import os
import platform
import shutil
import subprocess
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, GdkPixbuf, Gio, GLib, Gtk, asegurar_agente, cargar_css, clase, cristal, ejecutar, etiqueta, existe, icono, modo, oscuro, pixbuf, tam, usuario  # noqa: E402
from gi.repository import GObject, Pango  # noqa: E402
import aspecto  # noqa: E402
from comun import recargar_css  # noqa: E402

GLib.set_prgname('mandarin-panel')
Gdk.set_program_class('mandarin-panel')  # WM_CLASS igual al .desktop: la barra (docklike) lo junta con el anclado
GLib.set_application_name('Panel de control')

CSS = b"""
button.m-cat label { font-family: "Inter Display", "Inter", sans-serif; font-weight: 500; font-size: 12.5pt; }
button.m-sub label { font-size: 9.5pt; }
.m-pagina { background-color: @theme_base_color; }
.m-tarjeta-tema { padding: 8px; border-radius: 2px; }
.m-muestra-claro { background-color: #faf7f3; border: 1px solid #d3c6b8; border-radius: 2px; }
.m-muestra-oscuro { background-color: #1c1612; border: 1px solid #4d423a; border-radius: 2px; }
.m-muestra-barra-claro { background-color: #ffffff; }
.m-muestra-barra-oscuro { background-color: #251e19; }
.m-muestra-acento { background-color: #f26b1d; }
.m-lateral-panel { background-image: linear-gradient(to bottom, alpha(@theme_selected_bg_color, 0.10), alpha(@theme_selected_bg_color, 0.03));
                   border-right: 1px solid alpha(@theme_fg_color, 0.08); }
.m-lateral-panel button.m-enlace label { font-size: 9.5pt; }
.m-lateral-panel button.m-principal label { color: @theme_fg_color; }
.m-lista { border: 1px solid alpha(@theme_fg_color, 0.14); }
.m-lista treeview.view header button { padding: 4px 8px; }
.m-ordenes { padding: 3px 6px; background-image: linear-gradient(to bottom, alpha(@theme_selected_bg_color, 0.06), alpha(@theme_selected_bg_color, 0.12));
             border: 1px solid alpha(@theme_fg_color, 0.10); border-bottom: none; }
"""

# Paquetes sin los que el escritorio deja de funcionar: no se ofrecen para desinstalar
PROTEGIDOS = {'xfce4-session', 'xfce4-panel', 'xfwm4', 'xfdesktop4', 'xfce4-settings', 'xfconf', 'thunar', 'lightdm',
			  'lightdm-gtk-greeter', 'python3', 'python3-gi', 'gir1.2-gtk-3.0', 'network-manager', 'pipewire', 'wireplumber',
			  'xserver-xorg', 'dbus', 'polkitd', 'picom', 'imagemagick', 'xdg-utils', 'libglib2.0-bin'}

PAGINAS = {'sistema': 'Sistema', 'apariencia': 'Personalización', 'programas': 'Programas y características',
		   'dispositivos': 'Dispositivos', 'usuario': 'Cuentas de usuario', 'hora': 'Fecha y hora', 'teclado': 'Teclado táctil'}
REGIONES = {'Europe': 'Europa', 'America': 'América', 'Africa': 'África', 'Asia': 'Asia', 'Atlantic': 'Atlántico',
			'Pacific': 'Pacífico', 'Indian': 'Índico', 'Australia': 'Australia', 'Antarctica': 'Antártida', 'Arctic': 'Ártico'}
DIAS_SEMANA = ('lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo')
MESES = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre',
		 'diciembre')


def terminal(orden):
	"""Abre la terminal con una orden y la deja abierta al terminar (para apt, passwd…)."""
	return ejecutar('xfce4-terminal', '--hold', '-x', 'bash', '-c', orden)


class Panel(Gtk.ApplicationWindow):
	def __init__(self, app, pagina='inicio'):
		super().__init__(application=app, title='Panel de control')
		self.set_default_size(960, 640)
		self.set_icon_name('preferences-system')
		cristal(self)
		self.set_position(Gtk.WindowPosition.CENTER)  # centrada, como en la maqueta (xfwm4 las pondría arriba a la izquierda)
		self.vista = 'categoria'
		raiz = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.add(raiz)
		raiz.pack_start(self.barra(), False, False, 0)
		self.pila = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=120)
		clase(self.pila, 'm-contenido')
		raiz.pack_start(self.pila, True, True, 0)
		self.paginas = {'inicio': self.pagina_inicio, 'sistema': self.pagina_sistema, 'apariencia': self.pagina_apariencia,
						'programas': self.pagina_programas, 'dispositivos': self.pagina_dispositivos, 'usuario': self.pagina_usuario,
						'hora': self.pagina_hora, 'teclado': self.pagina_teclado}
		self.historia = []
		self.show_all()
		self.ir(pagina if pagina in self.paginas else 'inicio')

	# ---------- barra superior ----------
	def barra(self):
		caja = clase(Gtk.Box(spacing=6, margin_start=10, margin_end=10, margin_top=6, margin_bottom=6), 'm-barra')
		self.b_atras = Gtk.Button.new_from_icon_name('go-previous-symbolic', Gtk.IconSize.BUTTON)
		self.b_atras.connect('clicked', lambda *a: self.atras())
		caja.pack_start(self.b_atras, False, False, 0)
		self.migas = clase(Gtk.Box(), 'm-ruta')
		caja.pack_start(self.migas, True, True, 0)
		self.buscador = Gtk.SearchEntry(placeholder_text='Buscar en el Panel de control')
		self.buscador.set_size_request(240, -1)
		self.buscador.connect('search-changed', lambda *a: self.buscar())
		caja.pack_start(self.buscador, False, False, 0)
		marco = clase(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), 'm-barra', 'm-borde-abajo')
		marco.pack_start(caja, False, False, 0)
		return marco

	def pintar_migas(self, pagina):
		for h in self.migas.get_children():
			self.migas.remove(h)
		self.migas.pack_start(Gtk.Image.new_from_icon_name('preferences-system', Gtk.IconSize.MENU), False, False, 4)
		tramos = [('Panel de control', 'inicio')] + ([(PAGINAS[pagina], pagina)] if pagina in PAGINAS else [])
		for i, (texto, destino) in enumerate(tramos):
			if i:
				self.migas.pack_start(etiqueta('›', 'm-tenue'), False, False, 0)
			b = clase(Gtk.Button(label=texto), 'm-plano')
			if i == len(tramos) - 1:
				clase(b.get_child(), 'm-fuerte')
			b.connect('clicked', lambda _b, d=destino: self.ir(d))
			self.migas.pack_start(b, False, False, 0)
		self.migas.show_all()

	# ---------- navegación ----------
	def ir(self, pagina, guardar=True):
		if guardar and getattr(self, 'actual', None):
			self.historia.append(self.actual)
		self.actual = pagina
		vieja = self.pila.get_child_by_name(pagina)
		if vieja:
			self.pila.remove(vieja)
		contenido = self.paginas[pagina]()
		if pagina == 'programas':  # la lista ya trae su propio desplazamiento, como en Windows
			cuerpo = clase(Gtk.Box(), 'm-pagina')
			cuerpo.pack_start(contenido, True, True, 0)
		else:
			cuerpo = clase(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER), 'm-pagina')
			cuerpo.add(contenido)
		if pagina == 'inicio':
			envoltura = cuerpo
		else:
			envoltura = Gtk.Box()
			envoltura.pack_start(self.lateral(pagina), False, False, 0)
			envoltura.pack_start(cuerpo, True, True, 0)
		envoltura.show_all()
		self.pila.add_named(envoltura, pagina)
		self.pila.set_visible_child_name(pagina)
		self.pintar_migas(pagina)
		self.b_atras.set_sensitive(bool(self.historia))
		self.set_title(PAGINAS.get(pagina, 'Panel de control'))

	def atras(self):
		if self.historia:
			self.ir(self.historia.pop(), guardar=False)

	def buscar(self):
		texto = self.buscador.get_text().strip().lower()
		if self.actual != 'inicio':
			self.ir('inicio')
		self.pintar_inicio(texto)

	# ---------- panel lateral de las páginas (como el de Windows 7) ----------
	def enlace(self, texto, funcion, *clases):
		b = clase(Gtk.Button(halign=Gtk.Align.START), 'm-enlace', *clases)
		lbl = Gtk.Label(label=texto, xalign=0, wrap=True, max_width_chars=26)
		lbl.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
		b.add(lbl)
		b.connect('clicked', lambda *a: funcion())
		return b

	def lateral(self, pagina):
		h = self.herramienta
		enlaces, vea = {
			'sistema': ([('Dispositivos', lambda: self.ir('dispositivos')),
						 ('Configuración avanzada del sistema', lambda: h('xfce4-settings-manager')),
						 ('Administrador de tareas', lambda: h('mandarin-tareas')),
						 ('Salud del equipo', lambda: h('mandarin-salud'))],
						[('Buscar actualizaciones', lambda: ejecutar('mandarin-update')),
						 ('Personalización', lambda: self.ir('apariencia'))]),
			'apariencia': ([('Cambiar iconos del escritorio', lambda: h('xfdesktop-settings')),
							('Cambiar el puntero del mouse', lambda: h('xfce4-mouse-settings')),
							('Ventanas y efectos', lambda: h('xfwm4-settings'))],
						   [('Pantalla', lambda: h('xfce4-display-settings')),
							('Barra de tareas', lambda: h('xfce4-panel', '--preferences')),
							('Accesibilidad', lambda: h('xfce4-accessibility-settings'))]),
			'programas': ([('Ver actualizaciones instaladas', lambda: ejecutar('mandarin-update', 'historial')),
						   ('Instalar un programa de Windows', self.instalar_exe)],
						  [('Programas predeterminados', lambda: h('xfce4-mime-settings'))]),
			'dispositivos': ([('Pantalla', lambda: h('xfce4-display-settings')), ('Sonido', lambda: h('pavucontrol')),
							  ('Mouse', lambda: h('xfce4-mouse-settings')), ('Teclado', lambda: h('xfce4-keyboard-settings'))],
							 [('Opciones de energía', lambda: h('xfce4-power-manager-settings'))]),
			'usuario': ([('Cambiar la contraseña', lambda: terminal('passwd'))],
						[('Personalización', lambda: self.ir('apariencia'))]),
			'hora': ([('Cambiar la distribución del teclado', lambda: h('xfce4-keyboard-settings'))],
					 [('Buscar actualizaciones', lambda: ejecutar('mandarin-update'))]),
			'teclado': ([('Abrir el teclado táctil', lambda: ejecutar('mandarin-teclado', '--mostrar')),
						 ('Distribución del teclado', lambda: h('xfce4-keyboard-settings'))],
						[('Dispositivos', lambda: self.ir('dispositivos')), ('Accesibilidad', lambda: h('xfce4-accessibility-settings'))]),
		}.get(pagina, ([], []))
		caja = clase(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7), 'm-lateral-panel')
		caja.set_size_request(220, -1)
		interior = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7, margin=18, margin_top=20)
		interior.pack_start(self.enlace('Ventana principal del Panel de control', lambda: self.ir('inicio'), 'm-principal'), False, False, 0)
		for texto, f in enlaces:
			interior.pack_start(self.enlace(texto, f), False, False, 0)
		caja.pack_start(interior, False, False, 0)
		if vea:
			abajo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=18)
			abajo.pack_start(etiqueta('Vea también', 'm-tenue', 'm-pie'), False, False, 0)
			for texto, f in vea:
				abajo.pack_start(self.enlace(texto, f), False, False, 0)
			caja.pack_end(abajo, False, False, 0)
		return caja

	def instalar_exe(self):
		d = Gtk.FileChooserDialog(title='Instalar un programa de Windows', transient_for=self, action=Gtk.FileChooserAction.OPEN)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Instalar', Gtk.ResponseType.OK)
		filtro = Gtk.FileFilter()
		filtro.set_name('Programas de Windows (.exe, .msi)')
		for patron in ('*.exe', '*.EXE', '*.msi', '*.MSI'):
			filtro.add_pattern(patron)
		d.add_filter(filtro)
		d.set_current_folder(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) or GLib.get_home_dir())
		if d.run() == Gtk.ResponseType.OK and d.get_filename():
			ejecutar('mandarin-exe', d.get_filename())
		d.destroy()

	# ---------- acciones ----------
	def herramienta(self, *orden):
		if existe(orden[0]):
			ejecutar(*orden)
		else:
			self.aviso('Esta herramienta no está instalada.', f'Falta el programa «{orden[0]}».')

	def aviso(self, titulo, texto):
		d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.OK, text=titulo)
		d.format_secondary_text(texto)
		d.run()
		d.destroy()

	def categorias(self):
		h = self.herramienta
		return [
			('Sistema y seguridad', 'preferences-system', [
				('Revisar el estado del equipo', lambda: ejecutar('mandarin-salud')),
				('Buscar actualizaciones', lambda: ejecutar('mandarin-update')),
				('Ver la memoria y el procesador', lambda: self.ir('sistema'))]),
			('Redes e Internet', 'preferences-system-network', [
				('Ver el estado y las tareas de red', lambda: h('nm-connection-editor')),
				('Conectarse a una red', lambda: h('nm-connection-editor'))]),
			('Hardware y sonido', 'preferences-desktop-peripherals', [
				('Ver dispositivos e impresoras', lambda: self.ir('dispositivos')),
				('Agregar un dispositivo Bluetooth', lambda: h('blueman-manager')),
				('Teclado táctil', lambda: self.ir('teclado')),
				('Ajustar el volumen del sistema', lambda: h('pavucontrol')),
				('Opciones de energía', lambda: h('xfce4-power-manager-settings')),
				('Pantalla', lambda: h('xfce4-display-settings'))]),
			('Programas', 'system-software-install', [
				('Desinstalar un programa', lambda: self.ir('programas')),
				('Programas predeterminados', lambda: h('xfce4-mime-settings'))]),
			('Cuentas de usuario', 'system-users', [
				('Cambiar la imagen de la cuenta', lambda: self.ir('usuario')),
				('Cambiar la contraseña', lambda: terminal('passwd'))]),
			('Apariencia y personalización', 'preferences-desktop-theme', [
				('Cambiar el tema', lambda: self.ir('apariencia')),
				('Cambiar el fondo de escritorio', lambda: h('xfdesktop-settings')),
				('Ajustar la resolución de pantalla', lambda: h('xfce4-display-settings'))]),
			('Reloj, idioma y región', 'preferences-system-time', [
				('Cambiar la fecha y la hora', lambda: self.ir('hora')),
				('Cambiar la zona horaria', lambda: self.ir('hora')),
				('Cambiar la distribución del teclado', lambda: h('xfce4-keyboard-settings'))]),
			('Accesibilidad', 'preferences-desktop-accessibility', [
				('Optimizar la presentación visual', lambda: h('xfce4-accessibility-settings')),
				('Usar el teclado en pantalla', lambda: self.ir('teclado')),
				('Cambiar el funcionamiento del mouse', lambda: h('xfce4-mouse-settings'))]),
		]

	def elementos(self):
		h = self.herramienta
		return sorted([
			('Accesibilidad', 'preferences-desktop-accessibility', lambda: h('xfce4-accessibility-settings')),
			('Barra de tareas', 'xfce4-panel', lambda: h('xfce4-panel', '--preferences')),
			('Centro de redes', 'preferences-system-network', lambda: h('nm-connection-editor')),
			('Configuración avanzada', 'org.xfce.settings.manager', lambda: h('xfce4-settings-manager')),
			('Cuentas de usuario', 'system-users', lambda: self.ir('usuario')),
			('Dispositivos', 'preferences-desktop-peripherals', lambda: self.ir('dispositivos')),
			('Energía', 'xfce4-power-manager-settings', lambda: h('xfce4-power-manager-settings')),
			('Fecha y hora', 'preferences-system-time', lambda: self.ir('hora')),
			('Fondo de escritorio', 'preferences-desktop-wallpaper', lambda: h('xfdesktop-settings')),
			('Mouse', 'preferences-desktop-peripherals', lambda: h('xfce4-mouse-settings')),
			('Notificaciones', 'preferences-system-notifications', lambda: h('xfce4-notifyd-config')),
			('Pantalla', 'preferences-desktop-display', lambda: h('xfce4-display-settings')),
			('Personalización', 'preferences-desktop-theme', lambda: self.ir('apariencia')),
			('Programas predeterminados', 'preferences-desktop-default-applications', lambda: h('xfce4-mime-settings')),
			('Programas y características', 'system-software-install', lambda: self.ir('programas')),
			('Sistema', 'computer', lambda: self.ir('sistema')),
			('Sonido', 'audio-card', lambda: h('pavucontrol')),
			('Teclado', 'preferences-desktop-keyboard', lambda: h('xfce4-keyboard-settings')),
			('Ventanas', 'preferences-system-windows', lambda: h('xfwm4-settings')),
		], key=lambda e: e[0])

	# ---------- portada ----------
	def pagina_inicio(self):
		self.caja_inicio = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=28, margin_top=22)
		self.pintar_inicio(self.buscador.get_text().strip().lower())
		return self.caja_inicio

	def pintar_inicio(self, texto=''):
		caja = self.caja_inicio
		for h in caja.get_children():
			caja.remove(h)
		cabecera = Gtk.Box(spacing=8)
		cabecera.pack_start(etiqueta('Ajustar la configuración del equipo', 'm-titulo1'), True, True, 0)
		cabecera.pack_start(etiqueta('Ver por:', 'm-tenue'), False, False, 0)
		ver = Gtk.ComboBoxText()
		ver.append('categoria', 'Categoría')
		ver.append('iconos', 'Iconos grandes')
		ver.set_active_id(self.vista)
		ver.connect('changed', lambda c: (setattr(self, 'vista', c.get_active_id()), self.pintar_inicio(self.buscador.get_text().strip().lower())))
		ver.set_valign(Gtk.Align.CENTER)
		cabecera.pack_start(ver, False, False, 0)
		caja.pack_start(cabecera, False, False, 0)
		if self.vista == 'categoria' and not texto:
			rejilla = Gtk.Grid(column_spacing=40, row_spacing=26, margin_top=18, column_homogeneous=True)
			for i, (titulo, icono_n, enlaces) in enumerate(self.categorias()):
				rejilla.attach(self.categoria(titulo, icono_n, enlaces), i % 2, i // 2, 1, 1)
			caja.pack_start(rejilla, False, False, 0)
		else:
			elementos = self.elementos()
			if texto:
				elementos = [e for e in elementos if texto in e[0].lower()]
				for titulo, _i, enlaces in self.categorias():
					for t, f in enlaces:
						if texto in t.lower() or texto in titulo.lower():
							elementos.append((t, _i, f))
			rejilla = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=4, min_children_per_line=2, column_spacing=8, row_spacing=8, margin_top=18, homogeneous=True)
			for titulo, icono_n, f in elementos:
				b = clase(Gtk.Button(), 'm-plano', 'm-baldosa')
				fila = Gtk.Box(spacing=10)
				fila.pack_start(icono(icono_n, 32), False, False, 0)
				fila.pack_start(etiqueta(titulo, xalign=0, elipsis=True), True, True, 0)
				b.add(fila)
				b.connect('clicked', lambda _b, f=f: f())
				rejilla.add(b)
			if not elementos:
				caja.pack_start(etiqueta('No hay nada en el Panel de control que se llame así.', 'm-tenue'), False, False, 20)
			caja.pack_start(rejilla, False, False, 0)
		caja.show_all()

	def categoria(self, titulo, icono_n, enlaces):
		caja = Gtk.Box(spacing=14)
		caja.pack_start(icono(icono_n, 48), False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
		t = clase(Gtk.Button(label=titulo, halign=Gtk.Align.START), 'm-enlace', 'm-cat')
		t.connect('clicked', lambda *a: enlaces[0][1]())
		textos.pack_start(t, False, False, 0)
		for texto, f in enlaces:
			b = clase(Gtk.Button(label=texto, halign=Gtk.Align.START), 'm-enlace', 'm-sub')
			b.connect('clicked', lambda _b, f=f: f())
			textos.pack_start(b, False, False, 0)
		caja.pack_start(textos, True, True, 0)
		return caja

	# ---------- páginas propias ----------
	def pagina_base(self, titulo, descripcion=None):
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=28, margin_top=22)
		caja.pack_start(etiqueta(titulo, 'm-titulo1'), False, False, 0)
		if descripcion:
			caja.pack_start(etiqueta(descripcion, 'm-tenue'), False, False, 0)
		return caja

	def seccion(self, caja, titulo, filas):
		caja.pack_start(etiqueta(titulo, 'm-titulo3', 'm-acento'), False, False, 10)
		rejilla = Gtk.Grid(column_spacing=28, row_spacing=6, margin_start=16)
		for i, (k, v) in enumerate(filas):
			rejilla.attach(etiqueta(k + ':', 'm-tenue'), 0, i, 1, 1)
			valor = etiqueta(v)
			valor.set_selectable(True)
			rejilla.attach(valor, 1, i, 1, 1)
		caja.pack_start(rejilla, False, False, 0)

	def pagina_sistema(self):
		caja = self.pagina_base('Ver información básica acerca del equipo')
		cabecera = Gtk.Box(spacing=18, margin_top=6)
		logo = Gtk.Image()
		nombre = 'logo-horizontal-naranja.svg'
		rutas = ('/usr/share/mandarin/' + nombre, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../share/mandarin', nombre))
		try:
			logo.set_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(next(r for r in rutas if os.path.exists(r)), -1, 56, True))
		except (GLib.Error, StopIteration):
			logo = icono('mandarin-os', 56)
		cabecera.pack_start(logo, False, False, 0)
		caja.pack_start(cabecera, False, False, 0)
		self.seccion(caja, 'Edición', [('Sistema', 'Mandarin OS 1.0'), ('Basado en', self.base_debian())])
		completo = modo() == 'completo'
		self.seccion(caja, 'Sistema', [
			('Procesador', self.procesador()), ('Memoria instalada (RAM)', self.memoria()),
			('Tipo de sistema', f'Sistema operativo de {64 if platform.machine().endswith("64") else 32} bits'),
			('Gráfica', self.grafica()),
			('Modo', 'Completo: cristal en vivo' if completo else 'Ligero: cristal fingido, pensado para equipos antiguos'),
			('Programas de Windows', 'Proton (la gráfica tiene Vulkan)' if completo else 'Wine')])
		self.seccion(caja, 'Nombre del equipo', [('Nombre', GLib.get_host_name()), ('Usuario', usuario())])
		b = Gtk.Button(label='Buscar actualizaciones', halign=Gtk.Align.START, margin_top=12)
		b.connect('clicked', lambda *a: ejecutar('mandarin-update'))
		caja.pack_start(b, False, False, 0)
		return caja

	def procesador(self):
		try:
			with open('/proc/cpuinfo') as f:
				for linea in f:
					if linea.startswith('model name'):
						nucleos = os.cpu_count() or 1
						return ' '.join(linea.split(':', 1)[1].split()) + (f' ({nucleos} núcleos)' if nucleos > 1 else '')
		except OSError:
			pass
		return platform.processor() or 'Desconocido'

	def memoria(self):
		try:
			with open('/proc/meminfo') as f:
				kb = int(f.readline().split()[1])
			return f'{kb / 1024 / 1024:.1f} GB'.replace('.', ',')
		except (OSError, ValueError, IndexError):
			return 'Desconocida'

	def grafica(self):
		if not existe('lspci'):
			return 'Desconocida'
		try:
			salida = subprocess.run(['lspci'], capture_output=True, text=True, timeout=3).stdout
		except (OSError, subprocess.SubprocessError):
			return 'Desconocida'
		for linea in salida.splitlines():
			if 'VGA' in linea or '3D controller' in linea or 'Display' in linea:
				return linea.split(': ', 1)[-1]
		return 'Desconocida'

	def base_debian(self):
		try:
			with open('/etc/debian_version') as f:
				return f'Debian {f.read().strip()}'
		except OSError:
			return 'Debian'

	def pagina_apariencia(self):
		caja = self.pagina_base('Cambiar el aspecto del equipo', 'Elige el tema y si quieres el cristal esmerilado de las ventanas y la barra.')
		caja.pack_start(etiqueta('Tema', 'm-titulo3', 'm-acento'), False, False, 10)
		temas = Gtk.Box(spacing=16, margin_start=16)
		actual_oscuro = oscuro()
		for nombre, es_oscuro in (('Claro', False), ('Oscuro', True)):
			b = clase(Gtk.ToggleButton(), 'm-plano', 'm-tarjeta-tema')
			b.set_active(es_oscuro == actual_oscuro)
			v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
			muestra = clase(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), 'm-muestra-oscuro' if es_oscuro else 'm-muestra-claro')
			muestra.set_size_request(150, 92)
			ventana = clase(Gtk.Box(margin=12, margin_bottom=0), 'm-muestra-barra-oscuro' if es_oscuro else 'm-muestra-barra-claro')
			ventana.set_size_request(-1, 54)
			acento = clase(Gtk.Box(), 'm-muestra-acento')
			acento.set_size_request(30, 8)
			acento.set_valign(Gtk.Align.END)
			acento.set_margin_bottom(8)
			acento.set_margin_start(8)
			ventana.pack_start(acento, False, False, 0)
			muestra.pack_start(ventana, True, True, 0)
			v.pack_start(muestra, False, False, 0)
			v.pack_start(etiqueta(nombre, xalign=0.5), False, False, 0)
			b.add(v)
			b.connect('clicked', lambda _b, o=es_oscuro: self.poner_tema(o))
			temas.pack_start(b, False, False, 0)
		caja.pack_start(temas, False, False, 0)
		self.seccion_acento(caja)
		self.seccion_orbe(caja)
		caja.pack_start(etiqueta('Cristal esmerilado', 'm-titulo3', 'm-acento'), False, False, 10)
		pref = ''
		try:
			with open(os.path.expanduser('~/.config/mandarin/modo')) as f:
				pref = f.read().strip()
		except OSError:
			pass
		radios = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=16)
		grupo = None
		for texto, valor in (('Automático: según la gráfica del equipo (recomendado)', ''), ('Siempre: cristal en vivo, necesita una gráfica moderna', 'completo'),
							 ('Nunca: modo ligero, el más rápido en equipos antiguos', 'ligero')):
			r = Gtk.RadioButton.new_with_label_from_widget(grupo, texto)
			grupo = grupo or r
			r.set_active(pref == valor)
			r.connect('toggled', lambda rb, v=valor: rb.get_active() and self.poner_modo(v))
			radios.pack_start(r, False, False, 0)
		caja.pack_start(radios, False, False, 0)
		caja.pack_start(etiqueta('El cambio de cristal se aplica la próxima vez que entres en la sesión.', 'm-pie', 'm-tenue'), False, False, 4)
		self.seccion_fondo(caja)
		return caja

	# ---------- fondo de escritorio ----------
	FONDOS = '/usr/share/backgrounds/mandarin'

	def fondo_actual(self):
		try:
			with open(os.path.expanduser('~/.config/mandarin/fondo')) as f:
				ruta = f.read().strip()
				if os.path.isfile(ruta):
					return ruta
		except OSError:
			pass
		r = subprocess.run(['xfconf-query', '-c', 'xfce4-desktop', '-l'], capture_output=True, text=True)
		for prop in r.stdout.split():
			if prop.endswith('/last-image'):
				valor = subprocess.run(['xfconf-query', '-c', 'xfce4-desktop', '-p', prop], capture_output=True, text=True).stdout.strip()
				if os.path.isfile(valor):
					return valor
		return ''

	def seccion_fondo(self, caja):
		caja.pack_start(etiqueta('Fondo de escritorio', 'm-titulo3', 'm-acento'), False, False, 10)
		actual = self.fondo_actual()
		fondos = sorted(os.path.join(self.FONDOS, f) for f in os.listdir(self.FONDOS)
						if f.lower().endswith(('.jpg', '.jpeg', '.png'))) if os.path.isdir(self.FONDOS) else []
		# primero el de siempre (dunas), y el tuyo si es una imagen propia
		fondos.sort(key=lambda r: not r.endswith('/dunas.jpg'))
		if actual and actual not in fondos:
			fondos.insert(0, actual)
		rejilla = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=5, min_children_per_line=3,
							  column_spacing=10, row_spacing=10, margin_start=16, homogeneous=True)
		for ruta in fondos:
			b = clase(Gtk.ToggleButton(), 'm-plano', 'm-tarjeta-tema')
			b.set_active(ruta == actual)
			b.set_tooltip_text(os.path.splitext(os.path.basename(ruta))[0].replace('-', ' ').capitalize())
			imagen = Gtk.Image()
			imagen.set_size_request(144, 81)
			b.add(imagen)
			b.connect('clicked', lambda _b, r=ruta: self.poner_fondo(r))
			rejilla.add(b)
			GLib.idle_add(self.miniatura, imagen, ruta)   # sin esperar a cargar las fotos
		caja.pack_start(rejilla, False, False, 0)
		botones = Gtk.Box(spacing=8, margin_start=16, margin_top=4)
		examinar = Gtk.Button(label='Elegir una imagen tuya…')
		examinar.connect('clicked', lambda *a: self.elegir_fondo())
		botones.pack_start(examinar, False, False, 0)
		mas = Gtk.Button(label='Más opciones (ajuste, varias pantallas)…')
		mas.connect('clicked', lambda *a: self.herramienta('xfdesktop-settings'))
		botones.pack_start(mas, False, False, 0)
		caja.pack_start(botones, False, False, 0)

	@staticmethod
	def miniatura(imagen, ruta):
		try:
			foto = GdkPixbuf.Pixbuf.new_from_file_at_scale(ruta, 288, 162, False)
			imagen.set_from_pixbuf(foto.scale_simple(144, 81, GdkPixbuf.InterpType.BILINEAR))
		except GLib.Error:
			imagen.set_from_icon_name('image-missing', Gtk.IconSize.DIALOG)
		return False

	def poner_fondo(self, ruta):
		subprocess.run(['mandarin-fondo', ruta], check=False)
		GLib.timeout_add(200, lambda: self.ir('apariencia', guardar=False) or False)

	def elegir_fondo(self):
		d = Gtk.FileChooserDialog(title='Elige una imagen para el fondo de escritorio', transient_for=self,
								  action=Gtk.FileChooserAction.OPEN)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Poner de fondo', Gtk.ResponseType.OK)
		filtro = Gtk.FileFilter()
		filtro.set_name('Imágenes')
		filtro.add_pixbuf_formats()
		d.add_filter(filtro)
		d.set_current_folder(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or GLib.get_home_dir())
		if d.run() == Gtk.ResponseType.OK and d.get_filename():
			self.poner_fondo(d.get_filename())
		d.destroy()

	# ---------- color de acento y botón de inicio ----------
	def muestra_color(self, hexa, elegido, al_pulsar, nombre):
		b = clase(Gtk.Button(relief=Gtk.ReliefStyle.NONE), 'm-plano')
		b.set_tooltip_text(nombre)
		area = Gtk.DrawingArea()
		area.set_size_request(34, 34)

		def pintar(_a, cr):
			r, g, bl = aspecto.rgb(hexa)
			if elegido:   # un anillo alrededor del color elegido
				cr.set_source_rgb(r, g, bl)
				cr.rectangle(0, 0, 34, 34)
				cr.fill()
				cr.set_source_rgb(1, 1, 1)
				cr.rectangle(3, 3, 28, 28)
				cr.fill()
			cr.set_source_rgb(r, g, bl)
			cr.rectangle(5, 5, 24, 24)
			cr.fill()
		area.connect('draw', pintar)
		b.add(area)
		b.connect('clicked', lambda *_: al_pulsar(hexa))
		return b

	def otro_color(self, actual, al_elegir):
		d = Gtk.ColorChooserDialog(title='Elige un color', transient_for=self)
		d.set_use_alpha(False)
		rgba = Gdk.RGBA()
		rgba.parse(actual)
		d.set_rgba(rgba)
		if d.run() == Gtk.ResponseType.OK:
			c = d.get_rgba()
			al_elegir(aspecto.a_hex((c.red, c.green, c.blue)))
		d.destroy()

	def fila_colores(self, actual, al_pulsar, primero=None):
		fila = Gtk.Box(spacing=2, margin_start=12)
		if primero:
			fila.pack_start(primero, False, False, 6)
		for nombre, hexa in aspecto.COLORES:
			fila.pack_start(self.muestra_color(hexa, hexa == actual, al_pulsar, nombre), False, False, 0)
		otro = Gtk.Button(label='Otro color…', valign=Gtk.Align.CENTER, margin_start=8)
		otro.connect('clicked', lambda *_: self.otro_color(actual or aspecto.acento(), al_pulsar))
		fila.pack_start(otro, False, False, 0)
		if actual and actual not in dict((h, n) for n, h in aspecto.COLORES):
			fila.pack_start(self.muestra_color(actual, True, al_pulsar, 'Tu color'), False, False, 6)
		return fila

	def seccion_acento(self, caja):
		caja.pack_start(etiqueta('Color de acento', 'm-titulo3', 'm-acento'), False, False, 10)
		caja.pack_start(etiqueta('El color de los botones, las selecciones y los detalles de las ventanas (el naranja de Mandarin).',
								 'm-tenue', 'm-pie'), False, False, 0)
		caja.pack_start(self.fila_colores(aspecto.acento(), self.poner_acento), False, False, 0)

	def poner_acento(self, hexa):
		aspecto.guardar_acento(hexa)

		def aplicar():
			aspecto.aplicar(recargar=True)
			GLib.idle_add(lambda: (recargar_css(), self.ir('apariencia', guardar=False)) and False)
		threading.Thread(target=aplicar, daemon=True).start()

	def seccion_orbe(self, caja):
		conf = aspecto.orbe()
		caja.pack_start(etiqueta('Botón de inicio', 'm-titulo3', 'm-acento'), False, False, 10)
		caja.pack_start(etiqueta('El botón redondo de la barra de tareas: elige su icono y su color.', 'm-tenue', 'm-pie'),
						False, False, 0)
		iconos = Gtk.Box(spacing=10, margin_start=16)
		for clave, nombre in aspecto.ICONOS_ORBE:
			b = clase(Gtk.ToggleButton(), 'm-plano', 'm-tarjeta-tema')
			b.set_active(conf['icono'] == clave)
			v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
			area = Gtk.DrawingArea()
			area.set_size_request(64, 50)
			prueba = dict(conf, icono=clave)
			if clave == 'imagen' and not conf['imagen']:
				prueba = dict(conf, icono='imagen', imagen='')
			area.connect('draw', lambda _a, cr, p=prueba, k=clave: self.pintar_muestra_orbe(cr, p, k))
			v.pack_start(area, False, False, 0)
			v.pack_start(etiqueta(nombre, 'm-pie', xalign=0.5), False, False, 0)
			b.add(v)
			b.connect('clicked', lambda _b, k=clave: self.poner_icono_orbe(k))
			iconos.pack_start(b, False, False, 0)
		caja.pack_start(iconos, False, False, 0)
		igual = Gtk.ToggleButton(label='Igual que el acento', valign=Gtk.Align.CENTER)
		igual.set_active(conf['color'] == 'acento')
		igual.connect('clicked', lambda *_: self.poner_color_orbe('acento'))
		actual = conf['color'] if aspecto.valido(conf['color']) else None
		caja.pack_start(self.fila_colores(actual, self.poner_color_orbe, igual), False, False, 4)

	@staticmethod
	def pintar_muestra_orbe(cr, conf, clave):
		if clave == 'imagen' and not conf['imagen']:   # todavía sin imagen: un círculo con «+»
			cr.set_source_rgba(0.5, 0.45, 0.4, 0.35)
			cr.arc(32, 25, 21, 0, 6.2832)
			cr.fill()
			cr.set_source_rgb(1, 1, 1)
			cr.rectangle(30.5, 15, 3, 20)
			cr.rectangle(22, 23.5, 20, 3)
			cr.fill()
			return
		aspecto.pintar_orbe(cr, 32, 25, 21, conf)

	def poner_icono_orbe(self, clave):
		if clave == 'imagen':
			d = Gtk.FileChooserDialog(title='Elige una imagen para el botón de inicio', transient_for=self,
									  action=Gtk.FileChooserAction.OPEN)
			d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Elegir', Gtk.ResponseType.OK)
			filtro = Gtk.FileFilter()
			filtro.set_name('Imágenes')
			filtro.add_pixbuf_formats()
			d.add_filter(filtro)
			d.set_current_folder(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or GLib.get_home_dir())
			if d.run() == Gtk.ResponseType.OK and d.get_filename():
				try:
					aspecto.guardar_imagen_orbe(d.get_filename())
				except OSError as e:
					self.aviso('No se ha podido usar esa imagen.', str(e))
			d.destroy()
		else:
			aspecto.guardar_orbe(icono=clave)
		GLib.timeout_add(150, lambda: self.ir('apariencia', guardar=False) or False)

	def poner_color_orbe(self, valor):
		aspecto.guardar_orbe(color=valor)
		GLib.timeout_add(150, lambda: self.ir('apariencia', guardar=False) or False)

	def pagina_teclado(self):
		caja = self.pagina_base('Teclado táctil', 'El teclado en pantalla de Mandarin, para escribir tocando la pantalla.')
		abrir = Gtk.Button(label='Abrir el teclado táctil', halign=Gtk.Align.START, margin_start=16, margin_top=6)
		abrir.connect('clicked', lambda *a: ejecutar('mandarin-teclado', '--mostrar'))
		caja.pack_start(abrir, False, False, 0)
		caja.pack_start(etiqueta('Botón en la barra de tareas', 'm-titulo3', 'm-acento'), False, False, 10)
		caja.pack_start(etiqueta('Un botón con un teclado junto a la red y el volumen: al tocarlo se abre el teclado.', 'm-tenue'),
						False, False, 0)
		try:
			with open(os.path.expanduser('~/.config/mandarin/teclado-boton')) as f:
				pref = f.read().strip()
		except OSError:
			pref = ''
		pref = pref if pref in ('siempre', 'nunca') else 'tableta'
		radios = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=16)
		grupo = None
		for texto, valor in (('Solo en modo tableta, con el portátil plegado (recomendado)', 'tableta'),
							 ('Siempre', 'siempre'), ('Nunca', 'nunca')):
			r = Gtk.RadioButton.new_with_label_from_widget(grupo, texto)
			grupo = grupo or r
			r.set_active(pref == valor)
			r.connect('toggled', lambda rb, v=valor: rb.get_active() and self.poner_boton_teclado(v))
			radios.pack_start(r, False, False, 0)
		caja.pack_start(radios, False, False, 0)
		try:
			with open('/run/mandarin/tableta') as f:
				plegado = f.read().strip() == '1'
			estado = ('Este equipo avisa cuando se pliega como tableta. Ahora está ' +
					  ('plegado como tableta.' if plegado else 'en modo portátil.'))
		except OSError:
			estado = ('Este equipo no avisa cuando se pliega como tableta: si quieres el botón a mano, elige «Siempre».')
		caja.pack_start(etiqueta(estado, 'm-pie', 'm-tenue'), False, False, 4)
		caja.pack_start(etiqueta('También se abre desde el Centro de actividades (Windows + A) y desde el menú de inicio.',
								 'm-pie', 'm-tenue'), False, False, 0)
		return caja

	def poner_boton_teclado(self, valor):
		ruta = os.path.expanduser('~/.config/mandarin/teclado-boton')
		os.makedirs(os.path.dirname(ruta), exist_ok=True)
		with open(ruta, 'w') as f:
			f.write(valor + '\n')
		if valor != 'nunca':
			ejecutar('mandarin-teclado', '--fondo')   # si no estaba en segundo plano, que arranque ya con su botón

	def poner_tema(self, es_oscuro):
		tema = 'Mandarin-Oscuro' if es_oscuro else 'Mandarin'
		for canal, prop, valor in (('xsettings', '/Net/ThemeName', tema), ('xsettings', '/Net/IconThemeName', tema), ('xfwm4', '/general/theme', tema)):
			subprocess.run(['xfconf-query', '-c', canal, '-p', prop, '-n', '-t', 'string', '-s', valor], check=False)
		GLib.timeout_add(600, lambda: self.ir('apariencia', guardar=False) or False)

	def poner_modo(self, valor):
		ruta = os.path.expanduser('~/.config/mandarin/modo')
		os.makedirs(os.path.dirname(ruta), exist_ok=True)
		if valor:
			with open(ruta, 'w') as f:
				f.write(valor + '\n')
		elif os.path.exists(ruta):
			os.remove(ruta)

	def pagina_programas(self):
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=28, margin_top=22, margin_bottom=0)
		caja.pack_start(etiqueta('Desinstalar o cambiar un programa', 'm-titulo1'), False, False, 0)
		caja.pack_start(etiqueta('Para desinstalar un programa, selecciónalo en la lista y después haz clic en Desinstalar.', 'm-tenue'), False, False, 0)
		# Columnas: icono, nombre, editor, instalado el, tamaño, versión, tamaño en KB (para ordenar), paquete, app
		self.modelo_prog = Gtk.ListStore(GdkPixbuf.Pixbuf, str, str, str, str, str, GObject.TYPE_INT64, str, GObject.TYPE_PYOBJECT)
		ordenes = clase(Gtk.Box(spacing=4, margin_top=10), 'm-ordenes')
		b_org = Gtk.MenuButton(label='Organizar', relief=Gtk.ReliefStyle.NONE)
		menu = Gtk.Menu()
		for texto, f in (('Actualizar la lista', lambda: self.ir('programas', guardar=False)), ('Instalar un programa de Windows…', self.instalar_exe)):
			item = Gtk.MenuItem(label=texto)
			item.connect('activate', lambda _i, f=f: f())
			menu.append(item)
		menu.show_all()
		b_org.set_popup(menu)
		ordenes.pack_start(b_org, False, False, 0)
		self.b_desinstalar = clase(Gtk.Button(label='Desinstalar', relief=Gtk.ReliefStyle.NONE, sensitive=False), 'm-plano')
		self.b_desinstalar.connect('clicked', lambda *a: self.desinstalar_seleccion())
		ordenes.pack_start(self.b_desinstalar, False, False, 0)
		caja.pack_start(ordenes, False, False, 0)
		vista = Gtk.TreeView(model=self.modelo_prog, headers_clickable=True, enable_search=True, search_column=1)
		col = Gtk.TreeViewColumn(title='Nombre')
		col.set_resizable(True)
		col.set_expand(True)
		col.set_min_width(230)
		col.set_sort_column_id(1)
		r_icono = Gtk.CellRendererPixbuf(xpad=4)
		r_nombre = Gtk.CellRendererText(ellipsize=Pango.EllipsizeMode.END)
		col.pack_start(r_icono, False)
		col.pack_start(r_nombre, True)
		col.add_attribute(r_icono, 'pixbuf', 0)
		col.add_attribute(r_nombre, 'text', 1)
		vista.append_column(col)
		for titulo, i, orden, derecha in (('Editor', 2, 2, False), ('Se instaló el', 3, 3, False), ('Tamaño', 4, 6, True), ('Versión', 5, 5, False)):
			r = Gtk.CellRendererText(ellipsize=Pango.EllipsizeMode.END, xalign=1.0 if derecha else 0.0)
			c = Gtk.TreeViewColumn(titulo, r, text=i)
			c.set_resizable(True)
			c.set_sort_column_id(orden)
			c.set_min_width(90)
			if titulo == 'Editor':
				c.set_fixed_width(170)
				c.set_sizing(Gtk.TreeViewColumnSizing.FIXED)
			vista.append_column(c)
		self.modelo_prog.set_sort_column_id(1, Gtk.SortType.ASCENDING)
		vista.get_selection().connect('changed', lambda s: self.b_desinstalar.set_sensitive(s.count_selected_rows() > 0))
		vista.connect('row-activated', lambda *a: self.desinstalar_seleccion())
		self.vista_prog = vista
		desplaza = clase(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.AUTOMATIC), 'm-lista')
		desplaza.add(vista)
		caja.pack_start(desplaza, True, True, 0)
		pie = Gtk.Box(spacing=12, margin_top=6, margin_bottom=10)
		pie.pack_start(icono('system-software-install', 40), False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
		self.pie_prog1 = etiqueta('Programas instalados actualmente', 'm-fuerte')
		self.pie_prog2 = etiqueta('Buscando programas…', 'm-tenue', 'm-pie')
		textos.pack_start(self.pie_prog1, False, False, 0)
		textos.pack_start(self.pie_prog2, False, False, 0)
		pie.pack_start(textos, True, True, 0)
		caja.pack_start(pie, False, False, 0)
		self.cargar_programas()
		return caja

	def cargar_programas(self):
		"""Rellena la lista; el paquete, el tamaño y la versión salen de dpkg en un hilo aparte."""
		# los ajustes de XFCE son «elementos del Panel de control», no programas (como en Windows)
		apps = [a for a in Gio.AppInfo.get_all() if a.should_show() and hasattr(a, 'get_filename')
				and 'X-XFCE-SettingsDialog' not in (a.get_categories() or '')]
		modelo = self.modelo_prog
		archivos = [a.get_filename() or '' for a in apps]

		def trabajo():
			def origen(f):  # los nombres de Windows del gancho están copiados en /usr/local
				return '/usr/share/applications/' + os.path.basename(f) if f.startswith('/usr/local/share/applications/') else f
			paquete_de = {}
			buscar = sorted({origen(f) for f in archivos if f.startswith('/usr/')})
			if buscar and existe('dpkg'):
				try:
					salida = subprocess.run(['dpkg', '-S', *buscar], capture_output=True, text=True, timeout=30).stdout
					for linea in salida.splitlines():
						if ': ' in linea and not linea.startswith(('diversion', 'local diversion')):
							pk, ruta = linea.split(': ', 1)
							paquete_de[ruta.strip()] = pk.split(',')[0].strip()
				except (OSError, subprocess.SubprocessError):
					pass
			datos = {}
			paquetes = sorted(set(paquete_de.values()))
			if paquetes:
				try:
					salida = subprocess.run(['dpkg-query', '-W', '-f', '${binary:Package}\t${Version}\t${Installed-Size}\t${Maintainer}\n', *paquetes],
											capture_output=True, text=True, timeout=30).stdout
					for linea in salida.splitlines():
						p = linea.split('\t')
						if len(p) == 4:
							instalado = ''
							for nombre in (p[0], p[0].split(':')[0]):
								lista = f'/var/lib/dpkg/info/{nombre}.list'
								if os.path.exists(lista):
									instalado = GLib.DateTime.new_from_unix_local(int(os.path.getmtime(lista))).format('%d/%m/%Y')
									break
							kb = int(p[2]) if p[2].isdigit() else 0
							datos[p[0]] = (p[1], kb, p[3].split('<')[0].strip(), instalado)
							datos.setdefault(p[0].split(':')[0], datos[p[0]])
				except (OSError, subprocess.SubprocessError):
					pass
			filas = []
			for app, f in zip(apps, archivos):
				pk = paquete_de.get(origen(f), '')
				version, kb, editor, instalado = datos.get(pk, ('', 0, '', ''))
				if '/wine/' in f:
					editor = 'Programa de Windows'
				elif 'mandarin' in os.path.basename(f) and not pk:
					editor = 'Mandarin OS'
				filas.append((app, pk, version, kb, editor, instalado))
			GLib.idle_add(pintar, filas)

		def pintar(filas):
			modelo.clear()
			total, vistos = 0, set()
			for app, pk, version, kb, editor, instalado in filas:
				modelo.append([pixbuf(app.get_icon(), 24), app.get_display_name(), editor, instalado,
							   tam(kb * 1024) if kb else '', version, kb, pk, app])
				if pk and pk not in vistos:
					vistos.add(pk)
					total += kb
			self.pie_prog1.set_text('Programas instalados actualmente' + (f'    Tamaño total: {tam(total * 1024)}' if total else ''))
			self.pie_prog2.set_text(f'{len(filas)} programas instalados')
			return False

		threading.Thread(target=trabajo, daemon=True).start()

	def desinstalar_seleccion(self):
		modelo, it = self.vista_prog.get_selection().get_selected()
		if it is not None:
			self.desinstalar(modelo[it][8], modelo[it][7])

	def desinstalar(self, app, paquete=''):
		archivo = app.get_filename() or ''
		nombre = app.get_display_name()
		if '/wine/' in archivo:
			ejecutar('wine', 'uninstaller')  # el «Agregar o quitar programas» del propio Wine
			return
		if not paquete or paquete.split(':')[0] in PROTEGIDOS:
			if 'mandarin' in os.path.basename(archivo) or paquete:
				self.aviso(f'«{nombre}» forma parte de Mandarin OS.', 'No se puede desinstalar porque el sistema lo necesita.')
			else:
				self.aviso(f'No se puede desinstalar «{nombre}» desde aquí.', 'No viene de ningún paquete del sistema.')
			return
		d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION, buttons=Gtk.ButtonsType.NONE,
							  text=f'¿Desinstalar {nombre}?')
		d.format_secondary_text(f'Se quitará el paquete «{paquete}». Te pedirá tu contraseña.')
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Desinstalar', Gtk.ResponseType.OK)
		clase(d.get_widget_for_response(Gtk.ResponseType.OK), 'destructive-action')
		if d.run() == Gtk.ResponseType.OK:
			terminal(f'sudo apt remove {paquete}')
		d.destroy()

	def pagina_dispositivos(self):
		caja = self.pagina_base('Dispositivos', 'Lo que tiene conectado este equipo.')
		grupos = {'Pantalla y gráfica': [], 'Red': [], 'Sonido': [], 'Almacenamiento': [], 'USB': []}
		if existe('lspci'):
			try:
				for linea in subprocess.run(['lspci'], capture_output=True, text=True, timeout=3).stdout.splitlines():
					clase_disp, _, nombre = linea.partition(' ')[2].partition(': ')
					if any(x in clase_disp for x in ('VGA', '3D', 'Display')):
						grupos['Pantalla y gráfica'].append(nombre)
					elif any(x in clase_disp for x in ('Network', 'Ethernet')):
						grupos['Red'].append(nombre)
					elif 'Audio' in clase_disp or 'Multimedia' in clase_disp:
						grupos['Sonido'].append(nombre)
					elif any(x in clase_disp for x in ('SATA', 'IDE', 'RAID', 'Non-Volatile', 'Mass storage')):
						grupos['Almacenamiento'].append(nombre)
			except (OSError, subprocess.SubprocessError):
				pass
		if existe('lsusb'):
			try:
				for linea in subprocess.run(['lsusb'], capture_output=True, text=True, timeout=3).stdout.splitlines():
					nombre = linea.split(' ', 6)[-1] if linea.count(' ') >= 6 else linea
					if 'root hub' not in nombre:
						grupos['USB'].append(nombre)
			except (OSError, subprocess.SubprocessError):
				pass
		iconos = {'Pantalla y gráfica': 'video-display', 'Red': 'network-wireless', 'Sonido': 'audio-card', 'Almacenamiento': 'drive-harddisk', 'USB': 'drive-removable-media'}
		for grupo, nombres in grupos.items():
			if not nombres:
				continue
			caja.pack_start(etiqueta(grupo, 'm-titulo3', 'm-acento'), False, False, 8)
			for n in nombres:
				fila = Gtk.Box(spacing=10, margin_start=16)
				fila.pack_start(icono(iconos[grupo], 24), False, False, 0)
				fila.pack_start(etiqueta(n, elipsis=True), True, True, 0)
				caja.pack_start(fila, False, False, 0)
		b = Gtk.Button(label='Configurar la pantalla', halign=Gtk.Align.START, margin_top=14)
		b.connect('clicked', lambda *a: self.herramienta('xfce4-display-settings'))
		caja.pack_start(b, False, False, 0)
		return caja

	# ---------- fecha y hora (como Configuración › Hora e idioma de Windows 10) ----------
	@staticmethod
	def estado_hora():
		"""Lo que dice timedatectl: Timezone, NTP (hora automática), NTPSynchronized, CanNTP, LocalRTC."""
		datos = {}
		try:
			salida = subprocess.run(['timedatectl', 'show'], capture_output=True, text=True, timeout=5).stdout
		except (OSError, subprocess.SubprocessError):
			return datos
		for linea in salida.splitlines():
			clave, _, valor = linea.partition('=')
			datos[clave] = valor
		return datos

	@staticmethod
	def zonas_horarias():
		"""[(desfase, id, texto)] como «(UTC+01:00) Madrid · Europa», ordenadas como en Windows."""
		try:
			ids = subprocess.run(['timedatectl', 'list-timezones'], capture_output=True, text=True, timeout=5).stdout.split()
		except (OSError, subprocess.SubprocessError):
			ids = []
		lista = []
		for z in ids:
			region, _, ciudad = z.partition('/')
			if region not in REGIONES and z != 'UTC':
				continue
			try:
				desfase = GLib.DateTime.new_now(GLib.TimeZone.new_identifier(z)).get_utc_offset() // 1000000
			except (TypeError, GLib.Error):
				continue
			h, m = divmod(abs(desfase) // 60, 60)
			nombre = 'Hora universal coordinada' if z == 'UTC' else f"{ciudad.split('/')[-1].replace('_', ' ')} · {REGIONES[region]}"
			lista.append((desfase, z, f"(UTC{'+' if desfase >= 0 else '-'}{h:02d}:{m:02d}) {nombre}"))
		return sorted(lista)

	def hora_orden(self, *orden, despues=None):
		"""timedatectl en segundo plano (la contraseña la pide la ventana de administrador); si falla, lo dice."""
		def trabajo():
			asegurar_agente()   # la ventana que pide la contraseña
			try:
				r = subprocess.run(['timedatectl', *orden], capture_output=True, text=True, timeout=180)
				ok, error = r.returncode == 0, r.stderr.strip()
			except (OSError, subprocess.SubprocessError) as e:
				ok, error = False, str(e)
			GLib.idle_add(fin, ok, error)

		def fin(ok, error):
			cancelado = any(x in error.lower() for x in ('authentication', 'access denied', 'not authorized', 'dismissed'))
			if not ok and not cancelado:
				if 'ntp not supported' in error.lower():
					error = 'Falta el servicio de hora automática (systemd-timesyncd). Busca actualizaciones para instalarlo.'
				self.aviso('No se ha podido cambiar la hora.', error)
			if getattr(self, 'actual', None) == 'hora':
				self.ir('hora', guardar=False)   # se vuelve a pintar con el estado de verdad
			if despues:
				despues(ok)
			return False
		threading.Thread(target=trabajo, daemon=True).start()

	def pagina_hora(self):
		caja = self.pagina_base('Fecha y hora')
		estado = self.estado_hora()
		zona = estado.get('Timezone', 'UTC') or 'UTC'
		automatica = estado.get('NTP') == 'yes'
		puede_auto = estado.get('CanNTP', 'yes') == 'yes'

		# la hora en grande, en directo (con la zona elegida aunque el proceso tenga guardada la de antes)
		l_hora = clase(etiqueta(''), 'm-titulo1')
		l_fecha = etiqueta('', 'm-tenue')
		caja.pack_start(l_hora, False, False, 0)
		caja.pack_start(l_fecha, False, False, 0)
		tz = GLib.TimeZone.new_identifier(zona) or GLib.TimeZone.new_local()
		viva = [True]
		l_hora.connect('destroy', lambda *a: viva.__setitem__(0, False))

		def tic():
			if not viva[0]:
				return False
			ahora = GLib.DateTime.new_now(tz)
			l_hora.set_text(ahora.format('%H:%M:%S'))
			l_fecha.set_text(f'{DIAS_SEMANA[ahora.get_day_of_week() - 1]}, {ahora.get_day_of_month()} de '
							 f'{MESES[ahora.get_month() - 1]} de {ahora.get_year()}')
			return True
		tic()
		GLib.timeout_add(500, tic)

		def fila(titulo, nota, control):
			f = Gtk.Box(spacing=24, margin_top=16)
			textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
			textos.pack_start(etiqueta(titulo, 'm-titulo3'), False, False, 0)
			if nota:
				n = etiqueta(nota, 'm-tenue', 'm-pie')
				n.set_line_wrap(True)
				n.set_max_width_chars(60)
				textos.pack_start(n, False, False, 0)
			f.pack_start(textos, True, True, 0)
			control.set_valign(Gtk.Align.CENTER)
			f.pack_end(control, False, False, 0)
			caja.pack_start(f, False, False, 0)

		if not puede_auto:
			nota = 'Falta el servicio de hora automática: busca actualizaciones para instalarlo.'
		elif automatica and estado.get('NTPSynchronized') == 'yes':
			nota = 'Sincronizada con la hora de internet.'
		elif automatica:
			nota = 'Se pondrá en hora en cuanto haya conexión a internet.'
		else:
			nota = 'Desactivada: el equipo usa la hora que pongas tú.'
		auto = Gtk.Switch(active=automatica, sensitive=puede_auto)
		auto.connect('state-set', lambda _s, valor: self.hora_orden('set-ntp', 'true' if valor else 'false') or True)
		fila('Establecer la hora automáticamente', nota, auto)

		manual = Gtk.Button(label='Cambiar…', sensitive=not automatica)
		manual.connect('clicked', lambda *a: self.cambiar_hora(tz))
		fila('Establecer la fecha y la hora manualmente',
			 'Quita antes la hora automática.' if automatica else None, manual)

		sincronizar = Gtk.Button(label='Sincronizar ahora', sensitive=puede_auto)
		sincronizar.connect('clicked', lambda *a: self.hora_orden(
			'set-ntp', 'false', despues=lambda ok: ok and self.hora_orden('set-ntp', 'true')))
		fila('Sincronizar el reloj', 'Pide la hora exacta a los servidores de internet.', sincronizar)

		zonas = Gtk.ComboBoxText()
		for _desfase, ident, texto in self.zonas_horarias():
			zonas.append(ident, texto)
		if not zonas.set_active_id(zona):
			zonas.append(zona, zona)
			zonas.set_active_id(zona)
		zonas.set_size_request(320, -1)
		zonas.connect('changed', lambda c: c.get_active_id() != zona and self.hora_orden('set-timezone', c.get_active_id()))
		fila('Zona horaria', None, zonas)

		rtc = Gtk.Switch(active=estado.get('LocalRTC') == 'yes')
		rtc.connect('state-set', lambda _s, valor: self.hora_orden('set-local-rtc', '1' if valor else '0') or True)
		fila('Este equipo también tiene Windows',
			 'Actívalo si arrancas también Windows en este equipo: así la hora no se descuadra al pasar de uno a otro.', rtc)
		return caja

	def cambiar_hora(self, tz):
		d = Gtk.Dialog(title='Cambiar fecha y hora', transient_for=self, modal=True)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Cambiar', Gtk.ResponseType.OK)
		d.set_default_response(Gtk.ResponseType.OK)
		ahora = GLib.DateTime.new_now(tz)
		cuerpo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=16)
		calendario = Gtk.Calendar()
		calendario.select_month(ahora.get_month() - 1, ahora.get_year())
		calendario.select_day(ahora.get_day_of_month())
		cuerpo.pack_start(calendario, False, False, 0)
		fila = Gtk.Box(spacing=6, halign=Gtk.Align.CENTER)
		horas = Gtk.SpinButton.new_with_range(0, 23, 1)
		minutos = Gtk.SpinButton.new_with_range(0, 59, 1)
		for s, v in ((horas, ahora.get_hour()), (minutos, ahora.get_minute())):
			s.set_value(v)
			s.set_wrap(True)
			s.set_numeric(True)
			s.connect('output', lambda b: b.set_text(f'{int(b.get_value()):02d}') or True)
		fila.pack_start(etiqueta('Hora:'), False, False, 6)
		fila.pack_start(horas, False, False, 0)
		fila.pack_start(etiqueta(':'), False, False, 0)
		fila.pack_start(minutos, False, False, 0)
		cuerpo.pack_start(fila, False, False, 0)
		d.get_content_area().add(cuerpo)
		d.show_all()
		if d.run() == Gtk.ResponseType.OK:
			anio, mes, dia = calendario.get_date()
			momento = f'{anio:04d}-{mes + 1:02d}-{dia:02d} {int(horas.get_value()):02d}:{int(minutos.get_value()):02d}:00'
			self.hora_orden('set-time', momento)
		d.destroy()

	def pagina_usuario(self):
		caja = self.pagina_base('Cuentas de usuario', 'Tu imagen de cuenta aparece en el menú de inicio y en la pantalla de acceso.')
		fila = Gtk.Box(spacing=18, margin_top=12)
		marco = clase(Gtk.Box(), 'm-avatar')
		marco.set_size_request(96, 96)
		cara = os.path.expanduser('~/.face')
		if os.path.exists(cara):
			img = Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(cara, 96, 96, False))
		else:
			img = icono('avatar-default-symbolic', 56)
		img.set_hexpand(True)
		marco.pack_start(img, True, True, 0)
		fila.pack_start(marco, False, False, 0)
		datos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, valign=Gtk.Align.CENTER)
		datos.pack_start(etiqueta(usuario(), 'm-titulo2'), False, False, 0)
		datos.pack_start(etiqueta('Administrador', 'm-tenue'), False, False, 0)
		fila.pack_start(datos, True, True, 0)
		caja.pack_start(fila, False, False, 0)
		botones = Gtk.Box(spacing=8, margin_top=16)
		b1 = Gtk.Button(label='Cambiar la imagen de la cuenta')
		b1.connect('clicked', lambda *a: self.elegir_imagen())
		b2 = Gtk.Button(label='Cambiar la contraseña')
		b2.connect('clicked', lambda *a: terminal('passwd'))
		botones.pack_start(b1, False, False, 0)
		botones.pack_start(b2, False, False, 0)
		caja.pack_start(botones, False, False, 0)
		return caja

	def elegir_imagen(self):
		d = Gtk.FileChooserDialog(title='Elegir imagen de la cuenta', transient_for=self, action=Gtk.FileChooserAction.OPEN)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Usar esta imagen', Gtk.ResponseType.OK)
		filtro = Gtk.FileFilter()
		filtro.set_name('Imágenes')
		filtro.add_mime_type('image/*')
		d.add_filter(filtro)
		d.set_current_folder(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or GLib.get_home_dir())
		if d.run() == Gtk.ResponseType.OK and d.get_filename():
			try:
				pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(d.get_filename(), 256, 256, True)
				pb.savev(os.path.expanduser('~/.face'), 'png', [], [])
			except GLib.Error as e:
				self.aviso('No se ha podido usar esa imagen.', e.message)
		d.destroy()
		self.ir('usuario', guardar=False)


class AppPanel(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Panel', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)

	def do_command_line(self, linea):
		args = [a for a in linea.get_arguments()[1:] if not a.startswith('--')]
		pagina = args[0] if args else 'inicio'
		ventana = self.get_active_window()
		if ventana:
			ventana.ir(pagina)
			ventana.present()
		else:
			Panel(self, pagina).present()
		return 0


if __name__ == '__main__':
	sys.exit(AppPanel().run(sys.argv))
