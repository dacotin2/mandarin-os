#!/usr/bin/env python3
"""Mandarin OS · los paneles de la bandeja (abajo a la derecha), como los de Windows 10, en vez de los de Debian.

  mandarin-bandeja red | bluetooth | volumen | bateria | calendario    abre (o cierra) ese panel
  mandarin-bandeja --fondo                                              se queda cargado con los iconos de red y Bluetooth

- Red y Bluetooth: iconos propios en la bandeja. Los de nm-applet y blueman se esconden (gschema override
  90_mandarin-bandeja), pero esos dos siguen funcionando por debajo: piden las contraseñas y emparejan.
- Volumen, batería y reloj: los botones de la barra siguen siendo los de XFCE, pero el módulo mandarin-barra (dentro
  de la barra) cambia lo que hace el clic: en vez de su menú, llama a «mandarin-bandeja volumen» (etc.).
- Se queda cargado (--fondo, al entrar): así cada clic solo es un aviso por D-Bus (mandarin-bandeja lo hace con gdbus).
- Se cierran al tocar o hacer clic fuera, con Esc o al volver a pulsar su botón.
"""
import calendar
import datetime
import glob
import os
import re
import subprocess
import sys
import threading
import time
import warnings

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, Gio, GLib, Gtk, cargar_css, clase, ejecutar, etiqueta, existe  # noqa: E402
import actividades as act  # noqa: E402  (Wi-Fi, Bluetooth, brillo, volumen y batería: las mismas funciones)

warnings.filterwarnings('ignore', category=DeprecationWarning)   # Gtk.StatusIcon

DIAS = ('lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo')
MESES = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre',
		 'noviembre', 'diciembre')

CSS = b"""
window.b-panel { background-color: @theme_base_color; border: 1px solid @borders; }
window.b-panel.b-cristal { background-color: alpha(@theme_base_color, 0.9); }
.b-titulo { font-size: 15px; font-weight: 600; }
.b-grande { font-family: "Inter Display"; font-weight: 200; font-size: 44px; }
.b-mediano { font-family: "Inter Display"; font-weight: 300; font-size: 30px; }
.b-tenue { opacity: 0.68; }
.b-pie { border-top: 1px solid @borders; background-color: alpha(@theme_fg_color, 0.03); }
.b-enlace { color: #b3460b; padding: 4px 2px; }
.b-enlace:hover { text-decoration: underline; }
button.b-fila { padding: 9px 12px; border-radius: 2px; border: none; background: none; box-shadow: none; }
button.b-fila:hover { background-color: alpha(@theme_fg_color, 0.06); }
.b-elegida { background-color: alpha(#f26b1d, 0.10); }
button.b-tile { padding: 10px 12px; border-radius: 2px; min-width: 96px; min-height: 52px; }
button.b-tile.b-encendido { background-color: #b3460b; color: #ffffff; border-color: #b3460b; }
button.b-dia { padding: 0; min-width: 40px; min-height: 36px; border-radius: 2px; border: none; background: none; box-shadow: none; }
button.b-dia:hover { background-color: alpha(@theme_fg_color, 0.08); }
button.b-dia.b-hoy { background-color: #b3460b; color: #ffffff; }
.b-fuera-mes { opacity: 0.38; }
.b-semana { font-size: 12px; opacity: 0.6; }
button.b-segmento { border-radius: 0; padding: 6px 10px; }
button.b-segmento.b-encendido { background-color: #b3460b; color: #ffffff; border-color: #b3460b; }
"""


def icono(nombres, px=20):
	tema = Gtk.IconTheme.get_default()
	nombre = next((n for n in nombres if tema.has_icon(n)), nombres[-1])
	img = Gtk.Image.new_from_icon_name(nombre, Gtk.IconSize.LARGE_TOOLBAR)
	img.set_pixel_size(px)
	return img


def en_hilo(trabajo, al_acabar=None):
	"""trabajo() en segundo plano; al_acabar(resultado) luego, en la interfaz."""
	def correr():
		resultado = trabajo()
		if al_acabar:
			GLib.idle_add(lambda: al_acabar(resultado) and False)
	threading.Thread(target=correr, daemon=True).start()


def campos(linea):
	"""Separa una línea de «nmcli -t» por los «:» que no van escapados."""
	return [c.replace('\\:', ':').replace('\\\\', '\\') for c in re.split(r'(?<!\\):', linea)]


def nivel_senal(senal):
	return 100 if senal >= 80 else 75 if senal >= 60 else 50 if senal >= 40 else 25 if senal >= 20 else 0


def icono_senal(senal):
	n = nivel_senal(senal)
	return 'nm-signal-00' if n == 0 else f'nm-signal-{n}'


# ─── La ventana común: abajo a la derecha, encima de la barra, se cierra al tocar fuera ──────────────────────────

class Panel(Gtk.Window):
	ANCHO = 360

	def __init__(self, app, nombre):
		super().__init__(type=Gtk.WindowType.TOPLEVEL, title=f'mandarin-bandeja-{nombre}', decorated=False, resizable=False)
		self.app, self.nombre = app, nombre
		self.set_application(app)
		self.set_keep_above(True)
		self.set_skip_taskbar_hint(True)
		self.set_skip_pager_hint(True)
		self.set_type_hint(Gdk.WindowTypeHint.POPUP_MENU)
		clase(self, 'b-panel')
		self.cerrando = False
		self.agarre = False
		self.temporizadores = []
		self.caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.add(self.caja)
		self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.TOUCH_MASK)
		self.connect('button-press-event', lambda _w, e: self.quizas_fuera(e.x_root, e.y_root))
		self.connect('touch-event', lambda _w, e: e.type == Gdk.EventType.TOUCH_BEGIN and self.quizas_fuera(e.touch.x_root, e.touch.y_root))
		self.connect('key-press-event', lambda _w, e: self.cerrar() if e.keyval == Gdk.KEY_Escape else False)
		self.connect('map-event', lambda *_: GLib.timeout_add(120, self.agarrar))
		self.connect('size-allocate', lambda *_: self.colocar())

	def pie(self, enlaces):
		"""La franja de abajo con enlaces («Configuración de red», «Mezclador de volumen»…)."""
		franja = clase(Gtk.Box(spacing=14, margin_start=0), 'b-pie')
		for texto, orden in enlaces:
			if not existe(orden[0]):
				continue
			b = clase(Gtk.Button(relief=Gtk.ReliefStyle.NONE), 'b-enlace', 'm-plano')
			b.add(etiqueta(texto))
			b.connect('clicked', lambda _b, o=orden: self.abrir(*o))
			franja.pack_start(b, False, False, 8)
		self.caja.pack_end(franja, False, False, 0)

	def mostrar(self):
		self.caja.show_all()
		self.colocar()
		self.show()
		self.present_with_time(Gtk.get_current_event_time() or int(GLib.get_monotonic_time() / 1000))

	def colocar(self):
		monitor = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
		area = monitor.get_workarea()
		_m, natural = self.get_preferred_size()
		ancho = max(natural.width, self.ANCHO)
		self.set_size_request(ancho, -1)
		self.move(area.x + area.width - ancho - 8, area.y + area.height - natural.height - 8)

	def agarrar(self):
		ventana = self.get_window()
		if ventana is None or self.cerrando:
			return False
		asiento = Gdk.Display.get_default().get_default_seat()
		for _ in range(10):
			if asiento.grab(ventana, Gdk.SeatCapabilities.ALL_POINTING | Gdk.SeatCapabilities.KEYBOARD, True,
							None, None, None) == Gdk.GrabStatus.SUCCESS:
				self.agarre = True
				break
			time.sleep(0.03)
		return False

	def quizas_fuera(self, x, y):
		ventana = self.get_window()
		if ventana is None:
			return False
		ox, oy = ventana.get_origin()[1:]
		if not (ox <= x < ox + self.get_allocated_width() and oy <= y < oy + self.get_allocated_height()):
			self.cerrar()
			return True
		return False

	def cerrar(self):
		if self.cerrando:
			return True
		self.cerrando = True
		if self.agarre:
			Gdk.Display.get_default().get_default_seat().ungrab()
		for t in self.temporizadores:
			GLib.source_remove(t)
		self.app.cerrado(self)
		self.destroy()
		return True

	def abrir(self, *orden):
		self.cerrar()
		ejecutar(*orden)

	def cada(self, segundos, funcion):
		self.temporizadores.append(GLib.timeout_add(int(segundos * 1000), funcion))


# ─── Calendario ──────────────────────────────────────────────────────────────────────────────────────────────────

class Calendario(Panel):
	def __init__(self, app):
		super().__init__(app, 'calendario')
		arriba = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin=18, margin_bottom=10, spacing=2)
		self.hora = etiqueta('', 'b-grande')
		self.fecha = etiqueta('', 'm-acento')
		arriba.pack_start(self.hora, False, False, 0)
		arriba.pack_start(self.fecha, False, False, 0)
		self.caja.pack_start(arriba, False, False, 0)
		self.caja.pack_start(Gtk.Separator(), False, False, 0)
		cabecera = Gtk.Box(margin_start=18, margin_end=12, margin_top=10)
		self.titulo_mes = etiqueta('', 'b-titulo')
		cabecera.pack_start(self.titulo_mes, True, True, 0)
		for icono_, paso in (('go-up-symbolic', -1), ('go-down-symbolic', 1)):
			b = Gtk.Button.new_from_icon_name(icono_, Gtk.IconSize.BUTTON)
			b.set_relief(Gtk.ReliefStyle.NONE)
			b.connect('clicked', lambda _b, p=paso: self.mover_mes(p))
			cabecera.pack_start(b, False, False, 0)
		self.caja.pack_start(cabecera, False, False, 0)
		self.rejilla = Gtk.Grid(column_homogeneous=True, row_spacing=2, column_spacing=2, margin=14, margin_top=6)
		self.caja.pack_start(self.rejilla, False, False, 0)
		self.pie([('Ajustar fecha y hora', ['mandarin-panel', 'hora'])])
		hoy = datetime.date.today()
		self.anio, self.mes = hoy.year, hoy.month
		self.tic()
		self.pintar_mes()
		self.cada(1, self.tic)

	def tic(self):
		ahora = datetime.datetime.now()
		self.hora.set_text(ahora.strftime('%H:%M:%S'))
		self.fecha.set_text(f'{DIAS[ahora.weekday()]}, {ahora.day} de {MESES[ahora.month - 1]} de {ahora.year}')
		return True

	def mover_mes(self, paso):
		self.mes += paso
		if self.mes == 0:
			self.anio, self.mes = self.anio - 1, 12
		elif self.mes == 13:
			self.anio, self.mes = self.anio + 1, 1
		self.pintar_mes()

	def pintar_mes(self):
		for hijo in self.rejilla.get_children():
			self.rejilla.remove(hijo)
		self.titulo_mes.set_text(f'{MESES[self.mes - 1]} de {self.anio}')
		for i, letra in enumerate('LMXJVSD'):
			self.rejilla.attach(etiqueta(letra, 'b-semana', xalign=0.5), i, 0, 1, 1)
		hoy = datetime.date.today()
		semanas = calendar.Calendar(firstweekday=0).monthdatescalendar(self.anio, self.mes)
		while len(semanas) < 6:   # siempre seis filas: el panel no cambia de alto al pasar de mes
			ultimo = semanas[-1][-1]
			semanas.append([ultimo + datetime.timedelta(days=i + 1) for i in range(7)])
		for fila, semana in enumerate(semanas, 1):
			for col, dia in enumerate(semana):
				b = clase(Gtk.Button(label=str(dia.day)), 'b-dia')
				if dia.month != self.mes:
					clase(b, 'b-fuera-mes')
				if dia == hoy:
					clase(b, 'b-hoy')
				self.rejilla.attach(b, col, fila, 1, 1)
		self.rejilla.show_all()


# ─── Volumen ─────────────────────────────────────────────────────────────────────────────────────────────────────

def salidas_sonido():
	"""[(id, nombre, por_defecto)] de los altavoces/auriculares según «wpctl status»."""
	texto = act.salida('wpctl', 'status')
	salidas, dentro = [], False
	for linea in texto.splitlines():
		if 'Sinks:' in linea:
			dentro = True
			continue
		if dentro:
			m = re.match(r'^[\s│├└─]*(\*)?\s*(\d+)\.\s+(.+?)(\s+\[vol:.*\])?\s*$', linea)
			if not m:
				break
			salidas.append((m.group(2), m.group(3).strip(), bool(m.group(1))))
	return salidas


class Volumen(Panel):
	def __init__(self, app):
		super().__init__(app, 'volumen')
		cuerpo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=18)
		self.caja.pack_start(cuerpo, False, False, 0)
		self.salidas = salidas_sonido()
		cuerpo.pack_start(etiqueta('Altavoces', 'b-titulo'), False, False, 0)
		if len(self.salidas) > 1:
			combo = Gtk.ComboBoxText()
			for i, (ident, nombre, defecto) in enumerate(self.salidas):
				combo.append(ident, nombre)
				if defecto:
					combo.set_active(i)
			combo.connect('changed', lambda c: c.get_active_id() and ejecutar('wpctl', 'set-default', c.get_active_id()))
			cuerpo.pack_start(combo, False, False, 0)
		elif self.salidas:
			cuerpo.pack_start(etiqueta(self.salidas[0][1], 'b-tenue', elipsis=True), False, False, 0)
		vol = act.volumen()
		fila = Gtk.Box(spacing=8)
		self.b_mudo = Gtk.Button(relief=Gtk.ReliefStyle.NONE)
		self.b_mudo.connect('clicked', self.pulsar_mudo)
		fila.pack_start(self.b_mudo, False, False, 0)
		self.escala = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
		self.escala.set_draw_value(False)
		self.porcentaje = etiqueta('', 'b-titulo', xalign=1)
		self.porcentaje.set_width_chars(4)
		fila.pack_start(self.escala, True, True, 0)
		fila.pack_start(self.porcentaje, False, False, 0)
		cuerpo.pack_start(fila, False, False, 0)
		if vol is None:
			cuerpo.pack_start(etiqueta('No se encuentra ningún dispositivo de sonido.', 'b-tenue'), False, False, 0)
			self.mudo = False
			self.escala.set_sensitive(False)
		else:
			self.mudo = vol[1]
			self.escala.set_value(round(vol[0] * 100))
		self.escala.connect('value-changed', self.cambiar)
		self.pintar()
		self.pie([('Mezclador de volumen', ['pavucontrol'])])

	def cambiar(self, escala):
		if self.mudo:
			self.mudo = False
			ejecutar('wpctl', 'set-mute', '@DEFAULT_AUDIO_SINK@', '0')
		ejecutar('wpctl', 'set-volume', '-l', '1.0', '@DEFAULT_AUDIO_SINK@', f'{escala.get_value() / 100:.2f}')
		self.pintar()

	def pulsar_mudo(self, _b):
		self.mudo = not self.mudo
		ejecutar('wpctl', 'set-mute', '@DEFAULT_AUDIO_SINK@', '1' if self.mudo else '0')
		self.pintar()

	def pintar(self):
		v = self.escala.get_value()
		nivel = 'muted' if self.mudo or v == 0 else 'low' if v < 34 else 'medium' if v < 67 else 'high'
		if self.b_mudo.get_child():
			self.b_mudo.remove(self.b_mudo.get_child())
		self.b_mudo.add(icono([f'audio-volume-{nivel}-symbolic'], 24))
		self.b_mudo.set_tooltip_text('Activar el sonido' if self.mudo else 'Silenciar')
		self.b_mudo.show_all()
		self.porcentaje.set_text('—' if self.mudo else f'{int(v)}')


# ─── Batería ─────────────────────────────────────────────────────────────────────────────────────────────────────

def tiempo_bateria():
	"""(estado, minutos que quedan para vaciarse o llenarse, o None)."""
	for d in sorted(glob.glob('/sys/class/power_supply/*')):
		try:
			if open(d + '/type').read().strip() != 'Battery':
				continue
			estado = open(d + '/status').read().strip()
		except OSError:
			continue

		def leer(*nombres):
			for n in nombres:
				try:
					return int(open(f'{d}/{n}').read())
				except (OSError, ValueError):
					pass
			return None
		ahora, lleno, ritmo = leer('energy_now', 'charge_now'), leer('energy_full', 'charge_full'), leer('power_now', 'current_now')
		if not ahora or not ritmo:
			return estado, None
		if estado == 'Discharging':
			return estado, int(ahora / ritmo * 60)
		if estado == 'Charging' and lleno:
			return estado, int((lleno - ahora) / ritmo * 60)
		return estado, None
	return None, None


def texto_minutos(m):
	h, m = divmod(m, 60)
	return f'{h} h {m:02d} min' if h else f'{m} min'


class Bateria(Panel):
	def __init__(self, app):
		super().__init__(app, 'bateria')
		cuerpo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=18)
		self.caja.pack_start(cuerpo, False, False, 0)
		bat = act.bateria()
		if bat is not None:
			nivel, estado = bat
			fila = Gtk.Box(spacing=12)
			decena = min(100, round(nivel / 10) * 10)
			fila.pack_start(icono([f'battery-level-{decena}{"-charging" if estado == "Charging" else ""}-symbolic',
								   'battery-good-symbolic'], 40), False, False, 0)
			textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
			textos.pack_start(etiqueta(f'{nivel} %', 'b-mediano'), False, False, 0)
			_e, minutos = tiempo_bateria()
			if estado == 'Charging':
				detalle = f'Cargando · llena en {texto_minutos(minutos)}' if minutos else 'Cargando'
			elif estado == 'Full' or estado == 'Not charging':
				detalle = 'Enchufado · completamente cargada' if estado == 'Full' else 'Enchufado'
			else:
				detalle = f'Quedan {texto_minutos(minutos)}' if minutos else 'Con batería'
			textos.pack_start(etiqueta(detalle, 'b-tenue'), False, False, 0)
			fila.pack_start(textos, False, False, 0)
			cuerpo.pack_start(fila, False, False, 0)
		else:
			cuerpo.pack_start(etiqueta('Este equipo funciona enchufado: no tiene batería.', 'b-tenue'), False, False, 0)
		# modo de energía (si el sistema tiene power-profiles-daemon)
		if existe('powerprofilesctl'):
			actual = act.salida('powerprofilesctl', 'get')
			if actual:
				cuerpo.pack_start(etiqueta('Modo de energía', 'b-titulo'), False, False, 4)
				segmentos = clase(Gtk.Box(homogeneous=True), 'linked')
				botones = {}

				def elegir(clave):
					subprocess.run(['powerprofilesctl', 'set', clave], check=False, capture_output=True)
					for k, boton in botones.items():
						(boton.get_style_context().add_class if k == clave else boton.get_style_context().remove_class)('b-encendido')
				for clave, texto in (('power-saver', 'Ahorro'), ('balanced', 'Equilibrado'), ('performance', 'Rendimiento')):
					b = clase(Gtk.Button(label=texto), 'b-segmento', *(['b-encendido'] if clave == actual else []))
					b.connect('clicked', lambda _b, k=clave: elegir(k))
					botones[clave] = b
					segmentos.pack_start(b, True, True, 0)
				cuerpo.pack_start(segmentos, False, False, 0)
		luz = act.luz_pantalla()
		if luz is not None:
			nombre, actual_, maximo = luz
			cuerpo.pack_start(etiqueta('Brillo de la pantalla', 'b-titulo'), False, False, 4)
			fila = Gtk.Box(spacing=8)
			fila.pack_start(icono(['display-brightness-symbolic', 'weather-clear-symbolic'], 22), False, False, 0)
			escala = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 1, 100, 1)
			escala.set_draw_value(False)
			escala.set_value(round(actual_ * 100 / maximo))
			escala.connect('value-changed', lambda e: threading.Thread(
				target=act.poner_luz_pantalla, args=(nombre, max(1, round(e.get_value() * maximo / 100))), daemon=True).start())
			fila.pack_start(escala, True, True, 0)
			cuerpo.pack_start(fila, False, False, 0)
		self.pie([('Opciones de energía', ['xfce4-power-manager-settings'])])


# ─── Red ─────────────────────────────────────────────────────────────────────────────────────────────────────────

def redes_wifi(buscar=True):
	"""[(en_uso, ssid, señal, protegida)] sin repetir nombres, la conectada primero y luego por señal."""
	if not existe('nmcli'):
		return []
	texto = act.salida('nmcli', '-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'device', 'wifi', 'list',
					   '--rescan', 'yes' if buscar else 'no')
	vistas = {}
	for linea in texto.splitlines():
		c = campos(linea)
		if len(c) < 4 or not c[1]:
			continue
		red = (c[0] == '*', c[1], int(c[2] or 0), c[3] not in ('', '--'))
		if c[1] not in vistas or red[0] or red[2] > vistas[c[1]][2]:
			vistas[c[1]] = red
	return sorted(vistas.values(), key=lambda r: (not r[0], -r[2]))


def conexion_cable():
	for linea in act.salida('nmcli', '-t', '-f', 'TYPE,STATE,CONNECTION', 'device').splitlines():
		c = campos(linea)
		if len(c) >= 3 and c[0] == 'ethernet' and c[1] == 'connected':
			return c[2]
	return None


class Red(Panel):
	def __init__(self, app):
		super().__init__(app, 'red')
		self.abierta = None
		cable = conexion_cable()
		if cable:
			fila = Gtk.Box(spacing=12, margin=14, margin_bottom=4)
			fila.pack_start(icono(['nm-device-wired', 'network-wired-symbolic'], 24), False, False, 0)
			t = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
			t.pack_start(etiqueta(cable, 'b-titulo', elipsis=True), False, False, 0)
			t.pack_start(etiqueta('Conectado por cable', 'b-tenue'), False, False, 0)
			fila.pack_start(t, True, True, 0)
			self.caja.pack_start(fila, False, False, 0)
		self.lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1, margin=6)
		desplazable = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, propagate_natural_height=True,
										 max_content_height=330)
		desplazable.add(self.lista)
		self.caja.pack_start(desplazable, False, False, 0)
		self.aviso = etiqueta('Buscando redes Wi-Fi…', 'b-tenue', xalign=0.5)
		self.aviso.set_margin_top(14)
		self.aviso.set_margin_bottom(14)
		self.lista.pack_start(self.aviso, False, False, 0)
		# Wi-Fi y modo avión, como en el Centro de actividades
		tiles = Gtk.Box(spacing=8, margin=12, margin_top=6)
		w = act.wifi()
		self.t_wifi = self.tile('Wi-Fi', ['network-wireless-symbolic'], bool(w and w[0]), lambda si: act.poner_wifi(si))
		self.t_avion = self.tile('Modo avión', ['airplane-mode-symbolic', 'network-wireless-disabled-symbolic'], act.avion(),
								 lambda si: act.poner_avion(si))
		if w is not None:
			tiles.pack_start(self.t_wifi, False, False, 0)
		tiles.pack_start(self.t_avion, False, False, 0)
		self.caja.pack_start(tiles, False, False, 0)
		self.pie([('Configuración de red', ['nm-connection-editor'])])
		self.cargar(buscar=False)            # lo que ya se conoce, enseguida
		GLib.timeout_add(300, lambda: self.cargar(buscar=True) and False)   # y luego una búsqueda nueva

	def tile(self, texto, iconos, encendido, accion):
		b = clase(Gtk.Button(), 'b-tile')
		v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
		v.pack_start(icono(iconos, 18), False, False, 0)
		v.get_children()[0].set_halign(Gtk.Align.START)
		v.pack_start(etiqueta(texto), False, False, 0)
		b.add(v)
		b.encendido = encendido
		if encendido:
			clase(b, 'b-encendido')

		def pulsar(_b):
			b.encendido = not b.encendido
			(b.get_style_context().add_class if b.encendido else b.get_style_context().remove_class)('b-encendido')
			accion(b.encendido)
			GLib.timeout_add(3000, lambda: self.cargar(buscar=False) and False)
		b.connect('clicked', pulsar)
		return b

	def cargar(self, buscar):
		if self.cerrando:
			return False
		en_hilo(lambda: (redes_wifi(buscar), {c[0] for c in map(campos, act.salida(
			'nmcli', '-t', '-f', 'NAME,TYPE', 'connection', 'show').splitlines()) if len(c) > 1 and 'wireless' in c[1]}),
			self.pintar)
		return False

	def pintar(self, datos):
		if self.cerrando:
			return
		redes, conocidas = datos
		self.conocidas = conocidas
		for hijo in self.lista.get_children():
			self.lista.remove(hijo)
		if not redes:
			self.aviso.set_text('No se ven redes Wi-Fi.' if act.wifi() and act.wifi()[0] else 'El Wi-Fi está apagado.')
			self.lista.pack_start(self.aviso, False, False, 0)
		for red in redes:
			self.lista.pack_start(self.fila_red(red), False, False, 0)
		self.lista.show_all()
		self.colocar()

	def fila_red(self, red):
		en_uso, ssid, senal, protegida = red
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		b = clase(Gtk.Button(), 'b-fila')
		fila = Gtk.Box(spacing=12)
		fila.pack_start(icono([icono_senal(senal), 'network-wireless-symbolic'], 24), False, False, 0)
		t = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		t.pack_start(etiqueta(ssid, 'b-titulo', elipsis=True) if en_uso else etiqueta(ssid, elipsis=True), False, False, 0)
		detalle = ('Conectado, ' if en_uso else '') + ('protegida' if protegida else 'abierta')
		t.pack_start(etiqueta(detalle[0].upper() + detalle[1:], 'b-tenue'), False, False, 0)
		fila.pack_start(t, True, True, 0)
		b.add(fila)
		caja.pack_start(b, False, False, 0)
		if en_uso:
			clase(caja, 'b-elegida')
		extra = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=48, margin_end=12, margin_bottom=10)
		extra.set_no_show_all(True)
		caja.pack_start(extra, False, False, 0)
		b.connect('clicked', lambda *_: self.desplegar(red, extra))
		return caja

	def desplegar(self, red, extra):
		if self.abierta is not None and self.abierta is not extra:
			self.abierta.hide()
		self.abierta = extra
		for h in extra.get_children():
			extra.remove(h)
		en_uso, ssid, _s, protegida = red
		mensaje = etiqueta('', 'b-tenue')
		if en_uso:
			boton = Gtk.Button(label='Desconectar', halign=Gtk.Align.END)
			boton.connect('clicked', lambda *_: self.ejecutar_nmcli(['nmcli', 'connection', 'down', 'id', ssid], mensaje))
			extra.pack_start(boton, False, False, 0)
		else:
			clave = None
			if protegida and ssid not in self.conocidas:
				clave = Gtk.Entry(placeholder_text='Contraseña de la red', visibility=False)
				clave.set_input_purpose(Gtk.InputPurpose.PASSWORD)
				extra.pack_start(clave, False, False, 0)
			boton = Gtk.Button(label='Conectar', halign=Gtk.Align.END)
			clase(boton, 'suggested-action')

			def conectar(*_):
				if ssid in self.conocidas and not clave:
					orden = ['nmcli', 'connection', 'up', 'id', ssid]
				else:
					orden = ['nmcli', 'device', 'wifi', 'connect', ssid]
					if clave is not None and clave.get_text():
						orden += ['password', clave.get_text()]
				self.ejecutar_nmcli(orden, mensaje)
			boton.connect('clicked', conectar)
			if clave is not None:
				clave.connect('activate', conectar)
			extra.pack_start(boton, False, False, 0)
		extra.pack_start(mensaje, False, False, 0)
		extra.show_all()
		extra.show()
		self.colocar()

	def ejecutar_nmcli(self, orden, mensaje):
		mensaje.set_text('Un momento…')

		def trabajo():
			try:
				r = subprocess.run(orden, capture_output=True, text=True, timeout=45, env=dict(os.environ, LC_ALL='C.UTF-8'))
				return r.returncode, r.stderr
			except (OSError, subprocess.SubprocessError) as e:
				return 1, str(e)

		def acabado(res):
			codigo, error = res
			if codigo == 0:
				self.cargar(buscar=False)
			elif 'Secrets were required' in error or 'password' in error.lower():
				mensaje.set_text('La contraseña no es correcta.')
			else:
				mensaje.set_text('No se ha podido conectar.')
		en_hilo(trabajo, acabado)


# ─── Bluetooth ───────────────────────────────────────────────────────────────────────────────────────────────────

def aparatos_bluetooth():
	"""[(mac, nombre, icono, conectado, batería o None)] de los aparatos emparejados."""
	aparatos = []
	for linea in act.salida('bluetoothctl', 'devices', 'Paired').splitlines():
		m = re.match(r'^Device (\S+) (.+)$', linea)
		if not m:
			continue
		info = act.salida('bluetoothctl', 'info', m.group(1))
		icono_ = re.search(r'^\s*Icon: (\S+)', info, re.M)
		bat = re.search(r'^\s*Battery Percentage: \S+ \((\d+)\)', info, re.M)
		aparatos.append((m.group(1), m.group(2).strip(), icono_.group(1) if icono_ else 'bluetooth',
						 bool(re.search(r'^\s*Connected: yes', info, re.M)), int(bat.group(1)) if bat else None))
	return sorted(aparatos, key=lambda a: (not a[3], a[1].lower()))


class Bluetooth(Panel):
	def __init__(self, app):
		super().__init__(app, 'bluetooth')
		arriba = Gtk.Box(spacing=12, margin=16, margin_bottom=8)
		arriba.pack_start(etiqueta('Bluetooth', 'b-titulo'), True, True, 0)
		bt = act.bluetooth()
		self.interruptor = Gtk.Switch(active=bool(bt and bt[0]), valign=Gtk.Align.CENTER)
		self.interruptor.connect('notify::active', lambda s, _p: (act.poner_bluetooth(s.get_active()),
																  GLib.timeout_add(2500, lambda: self.cargar() and False)))
		arriba.pack_end(self.interruptor, False, False, 0)
		self.caja.pack_start(arriba, False, False, 0)
		self.lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1, margin=6)
		self.caja.pack_start(self.lista, False, False, 0)
		anadir = Gtk.Button(label='Añadir un dispositivo', halign=Gtk.Align.START, margin_start=16, margin_bottom=14, margin_top=4)
		anadir.connect('clicked', lambda *_: self.abrir('sh', '-c', act.ENCENDER_BT + '; exec blueman-manager'))
		self.caja.pack_start(anadir, False, False, 0)
		self.pie([('Más opciones de Bluetooth', ['blueman-manager'])])
		if bt is None:
			self.lista.pack_start(etiqueta('Este equipo no tiene Bluetooth (o está desactivado en la BIOS).', 'b-tenue',
										   xalign=0.5), False, False, 14)
			self.interruptor.set_sensitive(False)
		else:
			self.cargar()

	def cargar(self):
		if not self.cerrando:
			en_hilo(aparatos_bluetooth, self.pintar)
		return False

	def pintar(self, aparatos):
		if self.cerrando:
			return
		for h in self.lista.get_children():
			self.lista.remove(h)
		if not self.interruptor.get_active():
			self.lista.pack_start(etiqueta('El Bluetooth está apagado.', 'b-tenue', xalign=0.5), False, False, 12)
		elif not aparatos:
			self.lista.pack_start(etiqueta('Aún no has emparejado ningún aparato.', 'b-tenue', xalign=0.5), False, False, 12)
		for mac, nombre, icono_, conectado, bat in aparatos:
			b = clase(Gtk.Button(), 'b-fila')
			fila = Gtk.Box(spacing=12)
			fila.pack_start(icono([f'{icono_}-symbolic', icono_, 'bluetooth-symbolic'], 24), False, False, 0)
			t = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
			t.pack_start(etiqueta(nombre, elipsis=True), False, False, 0)
			detalle = ('Conectado' if conectado else 'Emparejado') + (f' · batería {bat} %' if bat is not None else '')
			t.pack_start(etiqueta(detalle, 'b-tenue'), False, False, 0)
			fila.pack_start(t, True, True, 0)
			fila.pack_end(etiqueta('Desconectar' if conectado else 'Conectar', 'm-acento'), False, False, 0)
			b.add(fila)
			b.connect('clicked', lambda _b, m=mac, c=conectado: self.alternar(_b, m, c))
			self.lista.pack_start(b, False, False, 0)
		self.lista.show_all()
		self.colocar()

	def alternar(self, boton, mac, conectado):
		boton.set_sensitive(False)
		en_hilo(lambda: subprocess.run(['bluetoothctl', 'disconnect' if conectado else 'connect', mac],
									   capture_output=True, timeout=25), lambda _r: self.cargar())


# ─── Iconos de red y Bluetooth en la bandeja ─────────────────────────────────────────────────────────────────────

class Iconos:
	def __init__(self, app):
		self.app = app
		self.red = Gtk.StatusIcon.new_from_icon_name('nm-no-connection')
		self.red.set_title('Red')
		self.red.connect('activate', lambda *_: app.alternar('red'))
		self.red.connect('popup-menu', lambda *_: app.alternar('red'))
		self.bt = Gtk.StatusIcon.new_from_icon_name('mandarin-bluetooth')
		self.bt.set_title('Bluetooth')
		self.bt.set_visible(False)
		self.bt.connect('activate', lambda *_: app.alternar('bluetooth'))
		self.bt.connect('popup-menu', lambda *_: app.alternar('bluetooth'))
		self.actualizar()
		GLib.timeout_add_seconds(4, self.actualizar)

	def actualizar(self):
		en_hilo(self.leer, self.pintar)
		return True

	@staticmethod
	def leer():
		cable = conexion_cable() if existe('nmcli') else None
		w = act.wifi()
		senal = None
		if w and w[1]:
			for en_uso, _ssid, s, _p in redes_wifi(buscar=False):
				if en_uso:
					senal = s
		return cable, w, senal, act.bluetooth()

	def pintar(self, datos):
		cable, w, senal, bt = datos
		if cable:
			nombre, texto = 'nm-device-wired', f'{cable}\nConectado por cable'
		elif w and w[1]:
			nombre, texto = icono_senal(senal or 0),f'{w[1]}\nConectado a Internet'
		elif w and w[0]:
			nombre, texto = 'nm-no-connection', 'Sin conexión\nToca para ver las redes Wi-Fi'
		else:
			nombre, texto = 'nm-no-connection', 'Sin conexión'
		self.red.set_from_icon_name(nombre)
		self.red.set_tooltip_text(texto)
		# Bluetooth: como en Windows, el icono solo está con el Bluetooth encendido
		self.bt.set_visible(bool(bt and bt[0]))
		if bt and bt[0]:
			self.bt.set_from_icon_name('mandarin-bluetooth-conectado' if bt[1] else 'mandarin-bluetooth')
			self.bt.set_tooltip_text(f'Bluetooth · {bt[1]}' if bt[1] else 'Bluetooth')


# ─── Aplicación ──────────────────────────────────────────────────────────────────────────────────────────────────

PANELES = {'calendario': Calendario, 'volumen': Volumen, 'bateria': Bateria, 'red': Red, 'bluetooth': Bluetooth}


class AppBandeja(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Bandeja', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
		self.abierto = None
		self.cerrado_en = {}
		self.fondo = False
		self.iconos = None

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)
		accion = Gio.SimpleAction.new('mostrar', GLib.VariantType.new('s'))   # mandarin-bandeja NOMBRE, por gdbus
		accion.connect('activate', lambda _a, v: self.alternar(v.get_string()))
		self.add_action(accion)

	def do_command_line(self, linea):
		args = linea.get_arguments()[1:]
		if '--fondo' in args:
			if not self.fondo:
				self.fondo = True
				self.hold()
				if 'XFCE' in os.environ.get('XDG_CURRENT_DESKTOP', '').upper() or os.environ.get('MANDARIN_BANDEJA'):
					self.iconos = Iconos(self)
		for nombre in args:
			if nombre in PANELES:
				self.alternar(nombre)
		return 0

	def alternar(self, nombre):
		if nombre not in PANELES:
			return
		if self.abierto is not None:
			mismo = self.abierto.nombre == nombre
			self.abierto.cerrar()
			if mismo:
				return
		elif time.monotonic() - self.cerrado_en.get(nombre, 0) < 0.5:
			return   # el mismo clic que lo ha cerrado (al tocar su botón fuera del panel)
		self.mostrar(nombre)

	def mostrar(self, nombre):
		self.abierto = PANELES[nombre](self)
		self.abierto.mostrar()

	def cerrado(self, panel):
		self.cerrado_en[panel.nombre] = time.monotonic()
		if self.abierto is panel:
			self.abierto = None
		if not self.fondo:
			GLib.timeout_add(300, lambda: self.abierto is None and self.quit() or False)


if __name__ == '__main__':
	sys.exit(AppBandeja().run(sys.argv))
