#!/usr/bin/env python3
"""Mandarin OS · al entrar en la sesión, lleva a la configuración del usuario lo nuevo de las actualizaciones.

La barra de tareas y los atajos de teclado se copian a la carpeta del usuario la primera vez que entra, así que
lo que cambia después en /etc/xdg no le llega. Cada paso se hace una sola vez (~/.config/mandarin/migrado).
Además, en cada entrada vuelve a poner la luz nocturna si estaba encendida.
"""
import glob
import os
import re
import subprocess
import sys
import time

HECHO = os.path.expanduser('~/.config/mandarin/migrado')
ACTIVIDADES = '/usr/share/applications/mandarin-actividades.desktop'
ATAJOS = {'<Super>x': 'mandarin-menu --rapido', '<Shift><Super>s': 'mandarin-recortes', '<Super>a': 'mandarin-actividades',
		  'Print': 'mandarin-recortes', '<Alt>Print': 'mandarin-recortes --ventana', '<Shift>Print': 'mandarin-recortes'}


# en inglés: con el sistema en español, xfconf-query dice «El valor es una matriz…» y la lista no se reconocía
# (la 1.0.202611151616 dejó así la barra con solo el botón nuevo)
EN_INGLES = dict(os.environ, LC_ALL='C.UTF-8', LANGUAGE='')


def xfconf(*args):
	r = subprocess.run(['xfconf-query', *args], capture_output=True, text=True, env=EN_INGLES)
	return r.returncode == 0, r.stdout


def valores(canal, propiedad):
	ok, texto = xfconf('-c', canal, '-p', propiedad)
	if not ok:
		return None
	lineas = [l.strip() for l in texto.splitlines()]
	if lineas and lineas[0].startswith('Value is an array'):
		return [l for l in lineas[1:] if l]
	return lineas[:1]


def atajos():
	# solo si el usuario ya tiene su copia de los atajos; si no, se usan los del sistema, que ya los llevan
	if valores('xfce4-keyboard-shortcuts', '/commands/custom/override') is None:
		return
	for tecla, orden in ATAJOS.items():
		xfconf('-c', 'xfce4-keyboard-shortcuts', '-p', f'/commands/custom/{tecla}', '-n', '-t', 'string', '-s', orden)


def reiniciar_barra():
	if subprocess.run(['pgrep', '-u', str(os.getuid()), '-x', 'xfce4-panel'], capture_output=True).returncode == 0:
		subprocess.Popen(['xfce4-panel', '--restart'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
	else:
		subprocess.Popen(['xfce4-panel'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def leer_barra():
	"""(ids de los elementos en orden, {id: tipo}) de la barra del usuario."""
	ids = [int(i) for i in (valores('xfce4-panel', '/panels/panel-1/plugin-ids') or []) if i.isdigit()]
	return ids, {i: (valores('xfce4-panel', f'/plugins/plugin-{i}') or [''])[0] for i in ids}


def es_actividades(i):
	"""¿El lanzador i abre el Centro de actividades? La barra copia el .desktop a launcher-i/ y cambia el nombre."""
	if any('mandarin-actividades' in x for x in valores('xfce4-panel', f'/plugins/plugin-{i}/items') or []):
		return True
	for f in glob.glob(os.path.expanduser(f'~/.config/xfce4/panel/launcher-{i}/*.desktop')):
		try:
			if 'mandarin-actividades' in open(f, errors='ignore').read():
				return True
		except OSError:
			pass
	return False


def reparar_barra():
	"""Si la barra se ha quedado sin la lista de programas (sin docklike), vuelve a la barra de Mandarin.
	Los programas anclados se conservan: están en ~/.config/xfce4/panel/docklike-2.rc."""
	ids, tipos = leer_barra()
	if len(ids) >= 4 and any(t in ('docklike', 'tasklist') for t in tipos.values()):
		return
	xfconf('-c', 'xfce4-panel', '-p', '/', '-R', '-r')   # vuelve a la configuración del sistema (ya trae el botón)
	reiniciar_barra()
	time.sleep(4)


def barra():
	ids, tipos = leer_barra()
	if len(ids) < 4:
		return   # barra rara: mejor no tocarla
	ok, lista = xfconf('-c', 'xfce4-panel', '-l')
	todos = [int(n) for n in re.findall(r'^/plugins/plugin-(\d+)$', lista, re.M)]
	for i in ids:
		if tipos[i] == 'launcher' and es_actividades(i):
			return   # ya está
	nuevo = max(todos + ids) + 1
	xfconf('-c', 'xfce4-panel', '-p', f'/plugins/plugin-{nuevo}', '-n', '-t', 'string', '-s', 'launcher')
	xfconf('-c', 'xfce4-panel', '-p', f'/plugins/plugin-{nuevo}/items', '-n', '-a', '-t', 'string', '-s', ACTIVIDADES)
	xfconf('-c', 'xfce4-panel', '-p', f'/plugins/plugin-{nuevo}/show-label', '-n', '-t', 'bool', '-s', 'false')
	# justo antes de «Mostrar el escritorio» (al final si no lo hay)
	pos = next((n for n, i in enumerate(ids) if tipos[i] == 'showdesktop'), len(ids))
	ids.insert(pos, nuevo)
	orden = ['-c', 'xfce4-panel', '-p', '/panels/panel-1/plugin-ids', '--force-array']
	for i in ids:
		orden += ['-t', 'int', '-s', str(i)]
	xfconf(*orden)
	reiniciar_barra()


PASOS = [('barra-reparada', reparar_barra), ('atajos-recortes-actividades', atajos), ('barra-actividades', barra)]

if __name__ == '__main__':
	# el color de acento: los temas personales se rehacen desde los del sistema (por si se han actualizado)
	try:
		sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
		import aspecto
		aspecto.aplicar(recargar=False)
	except Exception as e:   # noqa: BLE001
		print('migrar: color de acento:', e, file=sys.stderr)
	time.sleep(6 if '--ya' not in sys.argv else 0)   # que la barra y xfsettingsd hayan arrancado
	try:
		hechos = set(open(HECHO).read().split())
	except OSError:
		hechos = set()
	for nombre, paso in PASOS:
		if nombre in hechos:
			continue
		try:
			paso()
			hechos.add(nombre)
		except Exception as e:  # noqa: BLE001 — un paso roto no debe impedir los demás
			print(f'mandarin-migrar: {nombre}: {e}', file=sys.stderr)
	os.makedirs(os.path.dirname(HECHO), exist_ok=True)
	with open(HECHO, 'w') as f:
		f.write('\n'.join(sorted(hechos)) + '\n')
	subprocess.run(['python3', '/usr/lib/mandarin/actividades.py', '--aplicar'], check=False)   # luz nocturna
