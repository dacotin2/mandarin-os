#!/usr/bin/env python3
"""Mandarin OS · Menú de inicio (dos columnas, como Windows 7).

Izquierda: programas anclados, usados hace poco, «Todos los programas» y el buscador de programas
y archivos. Derecha: el usuario, sus carpetas, Este equipo, Panel de control y Apagar.
Se queda cargado en segundo plano (mandarin-menu --fondo al entrar) y cada «mandarin-menu»
lo abre o lo cierra: así aparece al instante con el botón de inicio o la tecla Windows.
"""
import json
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import (Gdk, GdkPixbuf, Gio, GLib, Gtk, abrir_archivo, cargar_css, carpeta, clase, ejecutar, etiqueta,  # noqa: E402
				   existe, icono, modo, recargar_css, usuario)
import aspecto  # noqa: E402

GLib.set_prgname('mandarin-menu')

try:
	import gi
	gi.require_version('GdkX11', '3.0')
	from gi.repository import GdkX11
except (ImportError, ValueError):
	GdkX11 = None

DEPURAR = os.environ.get('MANDARIN_DEPURAR')


def depurar(texto):
	if DEPURAR:
		print(f'{time.monotonic():.3f} {texto}', file=sys.stderr, flush=True)

ANCLADOS = ['firefox-esr.desktop', 'mandarin-explorador.desktop']
RECIENTES_INICIALES = ['org.xfce.mousepad.desktop', 'mandarin-tareas.desktop', 'mate-calc.desktop', 'org.gnome.Software.desktop',
					   'xfce4-terminal.desktop', 'mandarin-panel.desktop']
SUBTITULOS = {}  # como en Windows: solo el nombre del programa, sin «Internet» ni «Correo» debajo
FICHERO_RECIENTES = os.path.join(GLib.get_user_data_dir(), 'mandarin', 'recientes.json')
ANCHO, ALTO = 470, 500

CSS = b"""
menu.m-rapido menuitem { padding: 8px 22px 8px 14px; min-height: 22px; }
menu.m-rapido { padding: 4px 0; }
window.m-menu { background-color: @theme_base_color; border: 1px solid @borders; }
window.m-menu.m-cristal { background-color: alpha(@theme_base_color, 0.66); border-color: rgba(255, 255, 255, 0.6); }
.m-menu-der { background-color: alpha(@theme_base_color, 0.5); border-left: 1px solid alpha(@theme_fg_color, 0.08); }
button.m-fila { padding: 4px 8px; border-radius: 2px; }
button.m-fila:focus { background-color: alpha(@theme_selected_bg_color, 0.12); }
button.m-todos label { color: @theme_selected_bg_color; font-weight: 500; }
.m-menu-der button.m-plano label { font-weight: normal; }
"""


class Menu(Gtk.Window):
	def __init__(self, app):
		super().__init__(title='Menú de inicio')
		self.app = app
		self.set_application(app)
		self.set_decorated(False)
		self.set_resizable(False)
		self.set_skip_taskbar_hint(True)
		self.set_skip_pager_hint(True)
		self.set_keep_above(True)
		self.set_type_hint(Gdk.WindowTypeHint.UTILITY)
		self.set_size_request(ANCHO, ALTO)
		clase(self, 'm-menu')
		self.preparar_cristal()
		self.oculto_en = 0.0
		self.mostrado_en = 0.0
		self.archivos = None  # caché de archivos del usuario para la búsqueda
		self.ver_todos = False
		self.connect('focus-out-event', self.al_perder_foco)
		self.connect('focus-in-event', lambda *a: depurar('foco dentro'))
		self.connect('key-press-event', self.tecla)
		self.connect('delete-event', lambda *a: self.ocultar() or True)

		caja = Gtk.Box()
		self.add(caja)
		caja.pack_start(self.columna_izquierda(), False, False, 0)
		caja.pack_start(self.columna_derecha(), True, True, 0)
		caja.show_all()

	# ---------- columnas ----------
	def columna_izquierda(self):
		col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin=8)
		col.set_size_request(262, -1)
		desplaza = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
		self.lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
		desplaza.add(self.lista)
		col.pack_start(desplaza, True, True, 0)
		self.b_todos = clase(Gtk.Button(), 'm-plano', 'm-todos')
		self.b_todos.connect('clicked', lambda *a: self.alternar_todos())
		col.pack_start(self.b_todos, False, False, 0)
		self.buscador = Gtk.SearchEntry(placeholder_text='Buscar programas y archivos')
		self.buscador.connect('search-changed', lambda *a: self.pintar_lista())
		self.buscador.connect('activate', lambda *a: self.activar_primero())
		col.pack_start(self.buscador, False, False, 0)
		return col

	def columna_derecha(self):
		col = clase(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0), 'm-menu-der')
		interior = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin=10, margin_top=16)
		col.pack_start(interior, True, True, 0)
		avatar = clase(Gtk.Box(halign=Gtk.Align.CENTER), 'm-avatar')
		avatar.set_size_request(56, 56)
		cara = os.path.expanduser('~/.face')
		if os.path.exists(cara):
			try:
				img = Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(cara, 56, 56, False))
			except GLib.Error:
				img = icono('avatar-default-symbolic', 32)
		else:
			img = icono('avatar-default-symbolic', 32)
		img.set_hexpand(True)
		img.set_vexpand(True)
		avatar.pack_start(img, True, True, 0)
		interior.pack_start(avatar, False, False, 6)
		nombre = clase(Gtk.Button(label=usuario()), 'm-plano')
		clase(nombre.get_child(), 'm-usuario')
		nombre.get_child().set_xalign(0)
		nombre.connect('clicked', lambda *a: self.explorar(GLib.get_home_dir()))
		interior.pack_start(nombre, False, False, 4)
		for texto, f in (('Documentos', lambda: self.explorar(carpeta('documentos'))), ('Imágenes', lambda: self.explorar(carpeta('imagenes'))),
						 ('Música', lambda: self.explorar(carpeta('musica'))), ('Descargas', lambda: self.explorar(carpeta('descargas'))),
						 (None, None),
						 ('Este equipo', lambda: self.explorar('equipo')), ('Panel de control', lambda: self.orden('mandarin-panel')),
						 ('Dispositivos', lambda: self.orden('mandarin-panel', 'dispositivos')),
						 ('Programas predeterminados', lambda: self.orden('xfce4-mime-settings'))):
			if texto is None:
				interior.pack_start(Gtk.Separator(margin_top=4, margin_bottom=4), False, False, 0)
				continue
			b = clase(Gtk.Button(label=texto), 'm-plano')
			b.get_child().set_xalign(0)
			b.connect('clicked', lambda _b, f=f: f())
			interior.pack_start(b, False, False, 0)
		# Apagar y sus opciones
		apagar = Gtk.Box(spacing=2, halign=Gtk.Align.END)
		b_apagar = Gtk.Button(label='Apagar')
		b_apagar.set_image(Gtk.Image.new_from_icon_name('system-shutdown-symbolic', Gtk.IconSize.BUTTON))
		b_apagar.set_always_show_image(True)
		b_apagar.connect('clicked', lambda *a: self.orden('xfce4-session-logout', '--halt', '--fast'))
		apagar.pack_start(b_apagar, False, False, 0)
		mas = Gtk.MenuButton()
		mas.set_image(Gtk.Image.new_from_icon_name('pan-end-symbolic', Gtk.IconSize.BUTTON))
		mas.set_tooltip_text('Más opciones de apagado')
		menu = Gtk.Menu()
		for texto, orden in (('Bloquear', ['xflock4']), ('Cerrar sesión', ['xfce4-session-logout', '--logout', '--fast']),
							 ('Reiniciar', ['xfce4-session-logout', '--reboot', '--fast']), ('Suspender', ['xfce4-session-logout', '--suspend']),
							 ('Apagar', ['xfce4-session-logout', '--halt', '--fast'])):
			item = Gtk.MenuItem(label=texto)
			item.connect('activate', lambda _i, o=orden: self.orden(*o))
			menu.append(item)
		menu.show_all()
		# Mientras estas opciones están abiertas el menú de inicio sigue a la vista, como en Windows: el desplegable
		# se queda con el ratón y el menú lo tomaría por un «he perdido el foco» y se cerraría
		self.submenu_abierto = False
		menu.connect('show', lambda *a: setattr(self, 'submenu_abierto', True))
		menu.connect('deactivate', lambda *a: GLib.timeout_add(200, self.fin_submenu))
		mas.set_popup(menu)
		apagar.pack_start(mas, False, False, 0)
		col.pack_end(Gtk.Box(margin=10, margin_top=0), False, False, 0)
		col.pack_end(apagar, False, False, 0)
		apagar.set_margin_end(10)
		apagar.set_margin_bottom(10)
		return col

	# ---------- programas ----------
	def programas(self):
		# los ajustes sueltos de XFCE no salen: están dentro del Panel de control, como en Windows
		return [a for a in Gio.AppInfo.get_all()
				if a.should_show() and 'X-XFCE-SettingsDialog' not in (getattr(a, 'get_categories', lambda: '')() or '')]

	def por_id(self, ident):
		try:
			return Gio.DesktopAppInfo.new(ident)
		except TypeError:
			return None

	def recientes(self):
		try:
			with open(FICHERO_RECIENTES) as f:
				ids = json.load(f)
		except (OSError, ValueError):
			ids = list(RECIENTES_INICIALES)
		return [a for a in (self.por_id(i) for i in ids if i not in ANCLADOS) if a][:7]

	def apuntar_reciente(self, app):
		ident = app.get_id()
		if not ident or ident in ANCLADOS:
			return
		try:
			with open(FICHERO_RECIENTES) as f:
				ids = json.load(f)
		except (OSError, ValueError):
			ids = list(RECIENTES_INICIALES)
		ids = [ident] + [i for i in ids if i != ident]
		os.makedirs(os.path.dirname(FICHERO_RECIENTES), exist_ok=True)
		with open(FICHERO_RECIENTES, 'w') as f:
			json.dump(ids[:12], f)

	def fila(self, titulo, gicon, al_pulsar, subtitulo=None, tam_icono=32):
		b = clase(Gtk.Button(), 'm-plano', 'm-fila')
		caja = Gtk.Box(spacing=12)
		img = Gtk.Image.new_from_gicon(gicon, Gtk.IconSize.DND) if gicon else Gtk.Image.new_from_icon_name('application-x-executable', Gtk.IconSize.DND)
		img.set_pixel_size(tam_icono)
		caja.pack_start(img, False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
		textos.pack_start(etiqueta(titulo, elipsis=True), False, False, 0)
		if subtitulo:
			textos.pack_start(etiqueta(subtitulo, 'm-pie', 'm-tenue', elipsis=True), False, False, 0)
		caja.pack_start(textos, True, True, 0)
		b.add(caja)
		b.connect('clicked', lambda *a: al_pulsar())
		return b

	def fila_app(self, app):
		return self.fila(app.get_display_name(), app.get_icon(), lambda: self.lanzar(app), SUBTITULOS.get(app.get_id()))

	def titulo(self, texto):
		return etiqueta(texto, 'm-seccion', 'm-tenue', xalign=0.0)

	def pintar_lista(self):
		for hijo in self.lista.get_children():
			self.lista.remove(hijo)
		self.primero = None
		texto = self.buscador.get_text().strip().lower()
		if texto:
			apps = [a for a in self.programas() if self.coincide(a, texto)][:8]
			self.lista.pack_start(self.titulo('PROGRAMAS'), False, False, 4)
			for a in apps:
				self.lista.pack_start(self.fila_app(a), False, False, 0)
			if not apps:
				self.lista.pack_start(etiqueta('Ningún programa se llama así.', 'm-tenue'), False, False, 4)
			self.primero = (lambda a=apps[0]: self.lanzar(a)) if apps else None
			encontrados = self.buscar_archivos(texto)
			if encontrados:
				self.lista.pack_start(self.titulo('ARCHIVOS'), False, False, 6)
				for ruta in encontrados:
					f = Gio.File.new_for_path(ruta)
					tipo = Gio.content_type_guess(ruta, None)[0]
					self.lista.pack_start(self.fila(os.path.basename(ruta), Gio.content_type_get_icon(tipo), lambda f=f: self.abrir(f),
													os.path.basename(os.path.dirname(ruta)), 24), False, False, 0)
				if not self.primero:
					self.primero = lambda r=encontrados[0]: self.abrir(Gio.File.new_for_path(r))
		elif self.ver_todos:
			for a in sorted(self.programas(), key=lambda a: GLib.utf8_collate_key(a.get_display_name().lower(), -1)):
				self.lista.pack_start(self.fila_app(a), False, False, 0)
		else:
			for ident in ANCLADOS:
				a = self.por_id(ident)
				if a:
					self.lista.pack_start(self.fila_app(a), False, False, 0)
			self.lista.pack_start(Gtk.Separator(margin_top=4, margin_bottom=4, margin_start=8, margin_end=8), False, False, 0)
			for a in self.recientes():
				self.lista.pack_start(self.fila_app(a), False, False, 0)
		self.b_todos.set_label('‹  Atrás' if self.ver_todos and not texto else '›  Todos los programas')
		self.b_todos.get_child().set_xalign(0)
		self.lista.show_all()

	def coincide(self, app, texto):
		campos = [app.get_display_name(), app.get_name(), app.get_executable() or '']
		if isinstance(app, Gio.DesktopAppInfo):
			campos += [app.get_generic_name() or ''] + list(app.get_keywords() or [])
		return any(texto in (c or '').lower() for c in campos)

	def buscar_archivos(self, texto):
		if self.archivos is None:
			self.archivos = []
			threading.Thread(target=self.indexar, daemon=True).start()
			return []
		return [r for r in self.archivos if texto in os.path.basename(r).lower()][:5]

	def indexar(self):
		casa = GLib.get_home_dir()
		encontrados = []
		for dirpath, dirnames, ficheros in os.walk(casa):
			profundidad = dirpath[len(casa):].count(os.sep)
			dirnames[:] = [d for d in dirnames if not d.startswith('.')] if profundidad < 4 else []
			encontrados += [os.path.join(dirpath, f) for f in ficheros if not f.startswith('.')]
			if len(encontrados) > 8000:
				break
		self.archivos = encontrados
		GLib.idle_add(lambda: self.buscador.get_text() and self.pintar_lista())

	# ---------- acciones ----------
	def lanzar(self, app):
		contexto = Gdk.Display.get_default().get_app_launch_context()
		try:
			app.launch([], contexto)
			self.apuntar_reciente(app)
		except GLib.Error:
			pass
		self.ocultar()

	def abrir(self, gfile):
		abrir_archivo(gfile)
		self.ocultar()

	def explorar(self, lugar):
		self.orden('mandarin-explorador', lugar)

	def orden(self, *orden):
		ejecutar(*orden)
		self.ocultar()

	def activar_primero(self):
		if self.primero:
			self.primero()

	def alternar_todos(self):
		self.ver_todos = not self.ver_todos
		self.buscador.set_text('')
		self.pintar_lista()

	def tecla(self, _v, ev):
		k = Gdk.keyval_name(ev.keyval)
		if k == 'Escape':
			if self.buscador.get_text():
				self.buscador.set_text('')
			else:
				self.ocultar()
			return True
		if k in ('Super_L', 'Super_R'):
			depurar('tecla Windows dentro del menú')
			if time.monotonic() - self.mostrado_en > 0.6:  # la misma pulsación que lo ha abierto no lo cierra
				self.ocultar()
			return True
		if not self.buscador.has_focus() and ev.string and ev.string.isprintable() and not (ev.state & Gdk.ModifierType.CONTROL_MASK):
			self.buscador.grab_focus_without_selecting()
			self.buscador.set_text(self.buscador.get_text() + ev.string)
			self.buscador.set_position(-1)
			return True
		return False

	# ---------- mostrar y ocultar ----------
	def mostrar(self):
		self.preparar_cristal()
		self.ver_todos = False
		self.buscador.set_text('')
		self.pintar_lista()
		pantalla = Gdk.Display.get_default()
		monitor = pantalla.get_primary_monitor() or pantalla.get_monitor(0)
		area = monitor.get_workarea()
		self.move(area.x + 6, max(area.y, area.y + area.height - ALTO - 6))  # en pantallas bajas no se sale por arriba
		self.mostrado_en = time.monotonic()
		self.show()
		self.present_with_time(self.hora_x())
		self.buscador.grab_focus()
		depurar('mostrado')
		# con la tecla Windows el atajo de XFCE aún tiene el teclado al abrirse el menú: se asegura el foco
		GLib.timeout_add(250, self.recuperar_foco)

	def preparar_cristal(self):
		"""Cristal solo con compositor (modo completo). El menú arranca con la sesión, a veces antes que picom,
		así que se vuelve a mirar antes de cada apertura; el visual solo se puede cambiar con la ventana sin realizar."""
		pantalla = self.get_screen()
		rgba = pantalla.get_rgba_visual()
		quiere = rgba is not None and pantalla.is_composited() and modo() == 'completo'
		visual = rgba if quiere else pantalla.get_system_visual()
		if self.get_visual() is not visual and not self.get_visible():
			if self.get_realized():
				self.unrealize()
			self.set_visual(visual)
			depurar(f'cristal: {quiere}')
		ctx = self.get_style_context()
		(ctx.add_class if quiere else ctx.remove_class)('m-cristal')

	def precalentar(self):
		"""Al entrar deja el menú medido y con sus iconos y letras cargados, para que la primera vez
		que se abre no tarde (sin esto, casi 2 s en una máquina rápida y bastante más en el Amilo)."""
		inicio = time.monotonic()
		self.preparar_cristal()
		self.pintar_lista()
		self.realize()
		self.get_preferred_size()
		tema = Gtk.IconTheme.get_default()
		for app in self.programas():  # índice de programas de GIO e iconos a la caché del tema
			gicon = app.get_icon()
			info = tema.lookup_by_gicon(gicon, 32, 0) if gicon else None
			if info:
				try:
					info.load_icon()
				except GLib.Error:
					pass
		depurar(f'precalentado en {time.monotonic() - inicio:.2f} s')
		return False

	def hora_x(self):
		"""Hora del servidor X (la que el gestor de ventanas usa para decidir a quién da el foco)."""
		ventana = self.get_window()
		if GdkX11 is not None and ventana is not None and isinstance(ventana, GdkX11.X11Window):
			return GdkX11.x11_get_server_time(ventana)
		return Gtk.get_current_event_time() or Gdk.CURRENT_TIME

	def recuperar_foco(self):
		if self.get_visible() and not self.is_active():
			depurar('recupero el foco')
			self.present_with_time(self.hora_x())
			self.buscador.grab_focus()
		return False

	def fin_submenu(self):
		"""Se cerró el desplegable de apagado: si fue con un clic fuera del menú de inicio, se cierra también."""
		self.submenu_abierto = False
		if self.get_visible() and not self.is_active():
			self.ocultar()
		return False

	def al_perder_foco(self, *_):
		depurar('foco fuera')
		if getattr(self, 'submenu_abierto', False):
			return False   # es el desplegable de «Más opciones de apagado»: el menú sigue abierto
		if time.monotonic() - self.mostrado_en < 0.6:
			GLib.timeout_add(120, self.recuperar_foco)  # foco que va y vuelve justo al abrirse: no se cierra
		else:
			self.ocultar()
		return False

	def ocultar(self):
		if self.get_visible():
			depurar('oculto')
			self.hide()
			self.oculto_en = time.monotonic()
		return False

	def alternar(self):
		depurar(f'alternar (visible={self.get_visible()})')
		# un clic en el botón de inicio con el menú abierto lo cierra primero por perder el foco:
		# si acaba de cerrarse, ese mismo clic no debe volver a abrirlo
		if self.get_visible():
			if time.monotonic() - self.mostrado_en > 0.3:  # dos avisos seguidos de la misma pulsación: el segundo no cuenta
				self.ocultar()
		elif time.monotonic() - self.oculto_en > 0.35:
			self.mostrar()


def menu_rapido(evento=None, anclaje=None):
	"""El menú rápido de Windows+X: clic derecho en el botón de inicio, dejarlo pulsado con el dedo o Windows+X.
	Sale encima del botón de inicio, con filas altas para poder tocarlas."""
	m = Gtk.Menu()
	clase(m, 'm-rapido')

	def entrada(texto, *orden):
		if not existe(orden[0]):
			return
		e = Gtk.MenuItem(label=texto)
		e.connect('activate', lambda *a: ejecutar(*orden))
		m.append(e)

	entrada('Aplicaciones y características', 'mandarin-panel', 'programas')
	entrada('Opciones de energía', 'xfce4-power-manager-settings')
	entrada('Sistema', 'mandarin-panel', 'sistema')
	entrada('Dispositivos', 'mandarin-panel', 'dispositivos')
	entrada('Conexiones de red', 'nm-connection-editor')
	entrada('Salud del equipo', 'mandarin-salud')
	entrada('Mandarin Update', 'mandarin-update')
	m.append(Gtk.SeparatorMenuItem())
	entrada('Terminal', 'xfce4-terminal')
	entrada('Administrador de tareas', 'mandarin-tareas')
	entrada('Panel de control', 'mandarin-panel')
	entrada('Personalización', 'mandarin-panel', 'apariencia')
	entrada('Explorador de archivos', 'mandarin-explorador')
	entrada('Buscar', 'mandarin-menu')
	m.append(Gtk.SeparatorMenuItem())
	apagar = Gtk.MenuItem(label='Apagar o cerrar sesión')
	sub = Gtk.Menu()
	for texto, orden in (('Bloquear', ['xflock4']), ('Cerrar sesión', ['xfce4-session-logout', '--logout', '--fast']),
						 ('Suspender', ['xfce4-session-logout', '--suspend']),
						 ('Reiniciar', ['xfce4-session-logout', '--reboot', '--fast']),
						 ('Apagar', ['xfce4-session-logout', '--halt', '--fast'])):
		e = Gtk.MenuItem(label=texto)
		e.connect('activate', lambda _e, o=orden: ejecutar(*o))
		sub.append(e)
	apagar.set_submenu(sub)
	m.append(apagar)
	entrada('Escritorio', 'mandarin-mostrar-escritorio')
	m.show_all()
	if anclaje is not None:   # encima del botón de inicio, como en Windows
		m.popup_at_widget(anclaje, Gdk.Gravity.NORTH_WEST, Gdk.Gravity.SOUTH_WEST, None)
	elif evento is not None:
		m.popup_at_pointer(evento)
	else:
		m.popup(None, None, None, None, 0, Gtk.get_current_event_time())
	_menus_vivos.append(m)
	m.connect('deactivate', lambda *a: _menus_vivos.remove(m) if m in _menus_vivos else None)


_menus_vivos = []  # que Python no se lleve el menú mientras está abierto


class Orbe(Gtk.Window):
	"""El botón de inicio: un orbe de 42 px que sobresale de la barra, como el de Windows 7, encima del lanzador del
	panel (que queda debajo por si esto no arranca). Reflejo de cristal arriba; al pasar el ratón se ilumina con un
	halo naranja, crece un poco y lo cruza un destello; al pulsar se hunde. Abre y cierra el menú."""
	TAM = 48       # ventana
	DIAM = 42      # orbe
	CENTRO_X = 22  # sobre el lanzador del panel (el primero de la barra)

	def __init__(self, app, menu):
		super().__init__(type=Gtk.WindowType.TOPLEVEL)
		self.menu = menu
		self.set_application(app)
		self.set_decorated(False)
		self.set_resizable(False)
		self.set_skip_taskbar_hint(True)
		self.set_skip_pager_hint(True)
		self.set_keep_above(True)
		self.set_accept_focus(False)   # así pulsarlo no le quita el foco al menú (y el menú se cierra al volver a pulsar)
		self.set_type_hint(Gdk.WindowTypeHint.DOCK)
		self.set_title('mandarin-orbe')   # picom la saca del desenfoque por este nombre (si no, se ve un recuadro)
		self.set_app_paintable(True)
		self.set_size_request(self.TAM, self.TAM)
		pantalla = self.get_screen()
		if pantalla.get_rgba_visual() is not None:
			self.set_visual(pantalla.get_rgba_visual())
		self.encima = 0.0    # 0..1, animado
		self.hundido = 0.0
		self.destello = -1.0  # posición del destello (-1 = ninguno)
		self.objetivo_encima = 0.0
		self.pulsado = False
		# icono y color: se vuelven a leer en cuanto se cambian en el Panel de control
		self.aspecto = aspecto.orbe()
		self.vigilantes = []
		for ruta in (aspecto.ARCHIVO_ORBE, aspecto.ARCHIVO_ACENTO, aspecto.IMAGEN_ORBE):
			vigilante = Gio.File.new_for_path(ruta).monitor_file(Gio.FileMonitorFlags.NONE, None)
			vigilante.connect('changed', lambda *a: self.releer_aspecto())
			self.vigilantes.append(vigilante)
		self.largo = None   # pulsación larga (con el dedo): el menú rápido, como el clic derecho
		self.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK |
						Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK)
		self.connect('draw', self.dibujar)
		self.connect('enter-notify-event', lambda *a: self.hacia(1.0, destello=True))
		self.connect('leave-notify-event', lambda *a: self.hacia(0.0))
		self.connect('button-press-event', self.pulsar)
		self.connect('button-release-event', self.soltar)
		pantalla.connect('size-changed', lambda *a: self.colocar())
		pantalla.connect('monitors-changed', lambda *a: self.colocar())
		self.animando = False
		self.colocar()
		self.permitida = True   # el instalador la quita mientras está abierto (acción «orbe»)
		self.vigilada = None
		self.wnck = None
		GLib.idle_add(self.vigilar_pantalla_completa)

	# ---------- fuera de la vista con los juegos y vídeos a pantalla completa ----------
	def vigilar_pantalla_completa(self):
		"""Va «siempre encima» para quedar sobre la barra, así que taparía también los juegos a pantalla completa:
		se esconde mientras la ventana activa ocupa todo el monitor, como la barra de tareas."""
		try:
			gi.require_version('Wnck', '3.0')
			from gi.repository import Wnck
		except (ImportError, ValueError, NameError):
			return False
		self.Wnck = Wnck
		self.wnck = Wnck.Screen.get_default()
		if self.wnck is None:
			return False
		self.wnck.force_update()
		self.wnck.connect('active-window-changed', lambda *a: self.cambio_activa())
		self.cambio_activa()
		return False

	def cambio_activa(self):
		if self.vigilada is not None:
			ventana, ids = self.vigilada
			for i in ids:
				ventana.disconnect(i)
			self.vigilada = None
		activa = self.wnck.get_active_window()
		if activa is not None:
			self.vigilada = (activa, [activa.connect('state-changed', lambda *a: self.aplicar_visibilidad()),
									  activa.connect('geometry-changed', lambda *a: self.aplicar_visibilidad())])
		self.aplicar_visibilidad()

	def tapada(self):
		activa = self.wnck.get_active_window() if self.wnck is not None else None
		if activa is None or activa.get_window_type() in (self.Wnck.WindowType.DESKTOP, self.Wnck.WindowType.DOCK):
			return False
		if activa.is_fullscreen():
			return True
		# juegos (Wine, Proton…) que se ponen del tamaño de la pantalla sin pedir «pantalla completa»
		x, y, ancho, alto = activa.get_geometry()
		pantalla = Gdk.Display.get_default()
		monitor = pantalla.get_primary_monitor() or pantalla.get_monitor(0)
		g = monitor.get_geometry()
		return x <= g.x and y <= g.y and x + ancho >= g.x + g.width and y + alto >= g.y + g.height

	def aplicar_visibilidad(self):
		ver = self.permitida and not self.tapada()
		if ver and not self.get_visible():
			self.show_all()
			self.colocar()
		elif not ver and self.get_visible():
			self.hide()
		return False

	def permitir(self, valor):
		self.permitida = valor
		if self.wnck is None:
			(self.show_all if valor else self.hide)()
		else:
			self.aplicar_visibilidad()

	def colocar(self):
		pantalla = Gdk.Display.get_default()
		monitor = pantalla.get_primary_monitor() or pantalla.get_monitor(0)
		g = monitor.get_geometry()
		# el centro, a media altura de la barra de 40 px de abajo
		self.move(g.x + self.CENTRO_X - self.TAM // 2 + 2, g.y + g.height - 20 - self.TAM // 2)
		return False

	def hacia(self, valor, destello=False):
		self.objetivo_encima = valor
		if destello:
			self.destello = 0.0
		self.animar()

	def releer_aspecto(self):
		self.aspecto = aspecto.orbe()
		recargar_css()   # el menú se quedó cargado desde que entraste: sus estilos, con el color de acento nuevo
		self.queue_draw()

	def pulsar(self, _w, ev):
		if ev.button == 1:
			self.pulsado = True
			self.animar()
			if self.largo:
				GLib.source_remove(self.largo)
			self.largo = GLib.timeout_add(600, self.pulsacion_larga)
		elif ev.button == 3:
			menu_rapido(anclaje=self)
		return True

	def pulsacion_larga(self):
		self.largo = None
		if self.pulsado:
			self.pulsado = False
			self.animar()
			menu_rapido(anclaje=self)
		return False

	def soltar(self, _w, ev):
		if self.largo:
			GLib.source_remove(self.largo)
			self.largo = None
		if ev.button == 1 and self.pulsado:
			self.pulsado = False
			self.animar()
			self.menu.alternar()
		return True

	def animar(self):
		if not self.animando:
			self.animando = True
			GLib.timeout_add(16, self.paso)

	def paso(self):
		def acercar(actual, objetivo, v):
			return objetivo if abs(objetivo - actual) < v else actual + v * (1 if objetivo > actual else -1)
		# rápido, como Windows: el brillo aparece en ~60 ms y el destello cruza en ~140 ms
		self.encima = acercar(self.encima, self.objetivo_encima, 0.28)
		self.hundido = acercar(self.hundido, 1.0 if self.pulsado else 0.0, 0.5)
		if self.destello >= 0:
			self.destello += 0.12
			if self.destello > 1:
				self.destello = -1.0
		self.queue_draw()
		quieto = (self.encima == self.objetivo_encima and self.hundido == (1.0 if self.pulsado else 0.0)
				  and self.destello < 0)
		if quieto:
			self.animando = False
		return not quieto

	def dibujar(self, _w, cr):
		import cairo
		import math
		cr.set_operator(cairo.OPERATOR_SOURCE)
		cr.set_source_rgba(0, 0, 0, 0)
		cr.paint()
		cr.set_operator(cairo.OPERATOR_OVER)
		c = self.TAM / 2
		escala = 1.0 + 0.05 * self.encima - 0.06 * self.hundido
		r = self.DIAM / 2 * escala
		color = aspecto.rgb(aspecto.color_orbe(self.aspecto))
		# halo del color del orbe al pasar el ratón
		if self.encima > 0:
			halo = cairo.RadialGradient(c, c, r * 0.6, c, c, self.TAM / 2)
			halo.add_color_stop_rgba(0, *color, 0.55 * self.encima)
			halo.add_color_stop_rgba(1, *color, 0)
			cr.set_source(halo)
			cr.arc(c, c, self.TAM / 2, 0, 2 * math.pi)
			cr.fill()
		# el orbe: color e icono elegidos en Panel de control › Personalización
		aspecto.pintar_orbe(cr, c, c, r, self.aspecto)
		cr.save()
		cr.arc(c, c, r, 0, 2 * math.pi)
		cr.clip()
		# más luz al pasar, más sombra al pulsar
		if self.encima > 0:
			cr.set_source_rgba(1, 1, 1, 0.12 * self.encima)
			cr.paint()
		if self.hundido > 0:
			cr.set_source_rgba(0, 0, 0, 0.18 * self.hundido)
			cr.paint()
		# reflejo de cristal en la mitad de arriba (el del Aero de Windows 7)
		brillo = cairo.LinearGradient(0, c - r, 0, c)
		brillo.add_color_stop_rgba(0, 1, 1, 1, 0.55)
		brillo.add_color_stop_rgba(1, 1, 1, 1, 0.05)
		cr.set_source(brillo)
		cr.save()
		cr.translate(c, c - r * 0.42)
		cr.scale(r * 0.78, r * 0.5)
		cr.arc(0, 0, 1, 0, 2 * math.pi)
		cr.restore()
		cr.fill()
		# destello que cruza en diagonal
		if self.destello >= 0:
			x = c - r * 1.6 + self.destello * r * 3.2
			luz = cairo.LinearGradient(x - r * 0.35, c - r, x + r * 0.35, c + r)
			luz.add_color_stop_rgba(0, 1, 1, 1, 0)
			luz.add_color_stop_rgba(0.5, 1, 1, 1, 0.6)
			luz.add_color_stop_rgba(1, 1, 1, 1, 0)
			cr.set_source(luz)
			cr.paint()
		cr.restore()
		# borde fino
		cr.arc(c, c, r - 0.5, 0, 2 * math.pi)
		cr.set_source_rgba(*aspecto.mezclar(color, (0, 0, 0), 0.45), 0.45)
		cr.set_line_width(1)
		cr.stroke()
		return True


class AppMenu(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Menu', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
		self.menu = None

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)
		self.hold()  # se queda cargado aunque no haya ventana visible
		self.menu = Menu(self)
		# «mandarin-menu» sin argumentos llama a esta acción por D-Bus (gdbus): no hace falta arrancar Python cada vez
		accion = Gio.SimpleAction.new('alternar', None)
		accion.connect('activate', lambda *a: self.menu.alternar())
		self.add_action(accion)
		GLib.timeout_add_seconds(2, self.menu.precalentar)  # cuando la sesión ya ha terminado de arrancar
		GLib.timeout_add_seconds(3, self.mostrar_orbe)       # cuando ya está la barra
		# «orbe» con true/false: mostrarlo o esconderlo (lo esconde mandarin-instalar mientras el instalador está abierto)
		self.orbe = None
		rapido = Gio.SimpleAction.new('rapido', None)  # Windows+X: el menú del clic derecho del orbe
		rapido.connect('activate', lambda *a: menu_rapido(anclaje=self.orbe if self.orbe and self.orbe.get_visible() else None))
		self.add_action(rapido)
		accion = Gio.SimpleAction.new('orbe', GLib.VariantType.new('b'))
		accion.connect('activate', lambda _a, v: self.orbe and self.orbe.permitir(v.get_boolean()))
		self.add_action(accion)

	def mostrar_orbe(self):
		# solo en el escritorio de Mandarin (XFCE); MANDARIN_ORBE=1 para verlo en pruebas
		if 'XFCE' in os.environ.get('XDG_CURRENT_DESKTOP', '').upper() or os.environ.get('MANDARIN_ORBE'):
			self.orbe = Orbe(self, self.menu)
			self.orbe.show_all()
		return False

	def do_command_line(self, linea):
		args = linea.get_arguments()[1:]
		if '--fondo' not in args:
			self.menu.alternar()
		return 0


if __name__ == '__main__':
	sys.exit(AppMenu().run(sys.argv))
