"""Mandarin OS · personalización: el color de acento (el naranja del tema) y el botón de inicio (el orbe).

Color de acento (~/.config/mandarin/acento, «#rrggbb»): se generan en ~/.local/share/themes copias de los temas
Mandarin con el naranja cambiado por ese color (y sus tonos derivados: el oscuro para texto y botones, con contraste
suficiente sobre blanco; el suave para fondos; los del tema oscuro, aclarados). GTK busca antes los temas de la carpeta
personal, así que el nombre del tema no cambia. Se rehacen en cada inicio de sesión (migrar.py) para que sigan a las
actualizaciones del tema del sistema. Con el color de siempre, las copias se borran.

Botón de inicio (~/.config/mandarin/orbe, líneas «clave=valor»): icono = mandarin | cuadricula | estrella | inicial |
imagen; color = acento | #rrggbb; imagen = ruta de la imagen propia.

  python3 aspecto.py --aplicar     rehace los temas personales (lo que hace migrar.py al entrar)
"""
import math
import os
import re
import shutil
import subprocess
import sys
import time

CONFIG = os.path.expanduser('~/.config/mandarin')
ARCHIVO_ACENTO = os.path.join(CONFIG, 'acento')
ARCHIVO_ORBE = os.path.join(CONFIG, 'orbe')
IMAGEN_ORBE = os.path.expanduser('~/.local/share/mandarin/orbe-imagen')
POR_DEFECTO = '#f26b1d'
TEMAS = ('Mandarin', 'Mandarin-Oscuro', 'Mandarin-Ligero')
SISTEMA = '/usr/share/themes'
PERSONALES = os.path.expanduser('~/.local/share/themes')
MARCA = '.mandarin-acento'   # así se sabe que la copia es nuestra (nunca se toca un tema propio del usuario)

COLORES = (('Mandarina', '#f26b1d'), ('Rojo', '#d13438'), ('Frambuesa', '#e3008c'), ('Morado', '#8764b8'),
		   ('Azul', '#0078d4'), ('Turquesa', '#038387'), ('Verde', '#107c10'), ('Oro', '#c48a00'), ('Grafito', '#68768a'))
ICONOS_ORBE = (('mandarin', 'Mandarin'), ('cuadricula', 'Cuadrícula'), ('estrella', 'Estrella'), ('inicial', 'Tu inicial'),
			   ('imagen', 'Imagen propia'))


# ─── Colores ─────────────────────────────────────────────────────────────────────────────────────────────────────

def rgb(hexa):
	hexa = hexa.lstrip('#')
	return tuple(int(hexa[i:i + 2], 16) / 255 for i in (0, 2, 4))


def a_hex(c):
	return '#' + ''.join(f'{round(min(max(v, 0), 1) * 255):02x}' for v in c)


def mezclar(a, b, t):
	return tuple(x * (1 - t) + y * t for x, y in zip(a, b))


def luminancia(c):
	def canal(v):
		return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
	r, g, b = (canal(v) for v in c)
	return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contraste(a, b):
	la, lb = sorted((luminancia(a), luminancia(b)), reverse=True)
	return (la + 0.05) / (lb + 0.05)


def hasta_contraste(c, fondo, minimo, hacia):
	for _ in range(40):
		if contraste(c, fondo) >= minimo:
			break
		c = mezclar(c, hacia, 0.06)
	return c


def valido(hexa):
	return bool(re.fullmatch(r'#[0-9a-fA-F]{6}', hexa or ''))


def acento():
	try:
		with open(ARCHIVO_ACENTO) as f:
			valor = f.read().strip()
	except OSError:
		return POR_DEFECTO
	return valor.lower() if valido(valor) else POR_DEFECTO


def guardar_acento(hexa):
	os.makedirs(CONFIG, exist_ok=True)
	if hexa.lower() == POR_DEFECTO:
		if os.path.exists(ARCHIVO_ACENTO):
			os.remove(ARCHIVO_ACENTO)
	else:
		with open(ARCHIVO_ACENTO, 'w') as f:
			f.write(hexa.lower() + '\n')


def paleta(color):
	"""Qué color del tema original pasa a cuál: {'claro': {...}, 'oscuro': {...}}."""
	c, blanco, negro = rgb(color), (1, 1, 1), (0, 0, 0)
	fuerte = hasta_contraste(c, blanco, 4.6, negro)            # botones, selección y texto naranja sobre claro
	medio = mezclar(fuerte, negro, 0.23)
	suave = mezclar(c, blanco, 0.93)
	sombra = mezclar(c, negro, 0.12)
	vivo = hasta_contraste(c, rgb('#140f0c'), 5.5, blanco)    # tema oscuro: rellenos con texto oscuro encima
	texto_oscuro = hasta_contraste(vivo, rgb('#251e19'), 7, blanco)
	return {
		'claro': {'#f26b1d': color, '#b3460b': a_hex(fuerte), '#8a360a': a_hex(medio), '#fff4ec': a_hex(suave),
				  '212, 86, 15': ', '.join(str(round(v * 255)) for v in sombra)},
		'oscuro': {'#ff8a3d': a_hex(vivo), '#ffa568': a_hex(texto_oscuro), '#3a2416': a_hex(mezclar(rgb('#251e19'), c, 0.2)),
				   '#8a360a': a_hex(mezclar(c, negro, 0.45)), '#f26b1d': color},
	}


def recolorear(texto, oscuro=False, color=None):
	"""El CSS con el naranja de Mandarin cambiado por el color de acento (tal cual si es el de siempre)."""
	color = color or acento()
	if color == POR_DEFECTO:
		return texto
	cambios = paleta(color)['oscuro' if oscuro else 'claro']
	if oscuro:   # las apps propias usan también los naranjas del tema claro
		cambios = {**paleta(color)['claro'], **cambios}
	patron = re.compile('|'.join(re.escape(k) for k in cambios), re.I)
	return patron.sub(lambda m: cambios[m.group(0).lower()], texto)


# ─── Temas personales ────────────────────────────────────────────────────────────────────────────────────────────

def _copiar_tema(origen, destino, oscuro, color):
	os.makedirs(destino, exist_ok=True)
	for entrada in os.listdir(origen):
		ruta = os.path.join(origen, entrada)
		if entrada in ('gtk-3.0', 'xfce-notify-4.0') and os.path.isdir(ruta):
			carpeta = os.path.join(destino, entrada)
			os.makedirs(carpeta, exist_ok=True)
			for archivo in os.listdir(ruta):
				if archivo.endswith('.css'):
					with open(os.path.join(ruta, archivo), encoding='utf-8') as f:
						css = f.read()
					with open(os.path.join(carpeta, archivo), 'w', encoding='utf-8') as f:
						f.write(recolorear(css, oscuro, color))
				else:
					os.symlink(os.path.join(ruta, archivo), os.path.join(carpeta, archivo))
		else:
			os.symlink(ruta, os.path.join(destino, entrada))   # xfwm4, index.theme…: los del sistema
	with open(os.path.join(destino, MARCA), 'w') as f:
		f.write(color + '\n')


def aplicar(recargar=True):
	color = acento()
	for tema in TEMAS:
		origen, destino = os.path.join(SISTEMA, tema), os.path.join(PERSONALES, tema)
		if os.path.lexists(destino):
			if not os.path.exists(os.path.join(destino, MARCA)):
				continue   # un tema del usuario que se llama igual: no es nuestro
			shutil.rmtree(destino, ignore_errors=True)
		if color != POR_DEFECTO and os.path.isdir(origen):
			_copiar_tema(origen, destino, tema.endswith('Oscuro'), color)
	if recargar:
		recargar_tema()


def recargar_tema():
	"""GTK solo vuelve a leer el tema cuando cambia de nombre: se pasa un instante por Adwaita y se vuelve."""
	def xfconf(*args):
		return subprocess.run(['xfconf-query', '-c', 'xsettings', '-p', '/Net/ThemeName', *args], capture_output=True,
							  text=True, env=dict(os.environ, LC_ALL='C.UTF-8')).stdout.strip()
	actual = xfconf() or 'Mandarin'
	xfconf('-s', 'Adwaita')
	time.sleep(0.6)
	xfconf('-s', actual)


# ─── Botón de inicio ─────────────────────────────────────────────────────────────────────────────────────────────

def orbe():
	conf = {'icono': 'mandarin', 'color': 'acento', 'imagen': ''}
	try:
		with open(ARCHIVO_ORBE, encoding='utf-8') as f:
			for linea in f:
				clave, _, valor = linea.strip().partition('=')
				if clave in conf:
					conf[clave] = valor
	except OSError:
		pass
	if conf['icono'] not in dict(ICONOS_ORBE):
		conf['icono'] = 'mandarin'
	return conf


def guardar_orbe(**cambios):
	conf = orbe()
	conf.update(cambios)
	os.makedirs(CONFIG, exist_ok=True)
	with open(ARCHIVO_ORBE, 'w', encoding='utf-8') as f:
		f.write(''.join(f'{k}={v}\n' for k, v in conf.items()))


def guardar_imagen_orbe(ruta):
	"""Copia la imagen elegida (si luego se borra o se mueve, el orbe la sigue teniendo)."""
	os.makedirs(os.path.dirname(IMAGEN_ORBE), exist_ok=True)
	shutil.copyfile(ruta, IMAGEN_ORBE)
	guardar_orbe(icono='imagen', imagen=IMAGEN_ORBE)


def color_orbe(conf=None):
	conf = conf or orbe()
	return conf['color'].lower() if valido(conf['color']) else acento()


_simbolos = {}


def pintar_orbe(cr, cx, cy, r, conf=None):
	"""El orbe sin efectos: el círculo de color (o la imagen propia) con su icono en blanco."""
	import cairo
	import gi
	try:
		gi.require_version('PangoCairo', '1.0')
	except ValueError:
		pass
	from gi.repository import Gdk, GdkPixbuf, GLib, Pango, PangoCairo
	conf = conf or orbe()
	cr.save()
	cr.arc(cx, cy, r, 0, 2 * math.pi)
	cr.clip()
	if conf['icono'] == 'imagen' and conf['imagen']:
		try:
			lado = max(1, int(2 * r))
			imagen = GdkPixbuf.Pixbuf.new_from_file_at_scale(conf['imagen'], lado, lado, False)
			Gdk.cairo_set_source_pixbuf(cr, imagen, cx - r, cy - r)
			cr.paint()
			cr.restore()
			return
		except GLib.Error:
			pass
	c = rgb(color_orbe(conf))
	degradado = cairo.LinearGradient(0, cy - r, 0, cy + r)
	degradado.add_color_stop_rgb(0, *mezclar(c, (1, 1, 1), 0.16))
	degradado.add_color_stop_rgb(1, *mezclar(c, (0, 0, 0), 0.12))
	cr.set_source(degradado)
	cr.paint()
	cr.set_source_rgb(1, 1, 1)
	icono = conf['icono']
	if icono == 'cuadricula':
		lado, hueco = r * 0.4, r * 0.1
		for i in (-1, 1):
			for j in (-1, 1):
				x = cx + (hueco / 2 if i > 0 else -hueco / 2 - lado)
				y = cy + (hueco / 2 if j > 0 else -hueco / 2 - lado)
				cr.rectangle(x, y, lado, lado)
		cr.fill()
	elif icono == 'estrella':
		for k in range(10):
			radio = r * (0.56 if k % 2 == 0 else 0.23)
			a = -math.pi / 2 + k * math.pi / 5
			(cr.move_to if k == 0 else cr.line_to)(cx + radio * math.cos(a), cy + radio * math.sin(a) + r * 0.04)
		cr.close_path()
		cr.fill()
	elif icono == 'inicial':
		nombre = GLib.get_real_name()
		if not nombre or nombre == 'Unknown':
			nombre = GLib.get_user_name()
		letra = next((ch for ch in nombre if ch.isalpha()), 'M').upper()
		capa = PangoCairo.create_layout(cr)
		fuente = Pango.FontDescription.from_string('Inter Display Light')
		fuente.set_absolute_size(r * 1.15 * Pango.SCALE)
		capa.set_font_description(fuente)
		capa.set_text(letra, -1)
		tinta, _logico = capa.get_pixel_extents()
		cr.move_to(cx - tinta.x - tinta.width / 2, cy - tinta.y - tinta.height / 2)
		PangoCairo.show_layout(cr, capa)
	else:   # el logo de Mandarin
		lado = max(8, int(r * 1.2))
		if lado not in _simbolos:
			try:
				_simbolos[lado] = GdkPixbuf.Pixbuf.new_from_file_at_size('/usr/share/mandarin/simbolo-blanco.svg', lado, lado)
			except GLib.Error:
				_simbolos[lado] = None
		if _simbolos[lado] is not None:
			Gdk.cairo_set_source_pixbuf(cr, _simbolos[lado], cx - lado / 2, cy - lado / 2)
			cr.paint()
	cr.restore()


if __name__ == '__main__':
	if '--aplicar' in sys.argv:
		aplicar(recargar='--recargar' in sys.argv)
