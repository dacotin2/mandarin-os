#!/usr/bin/env python3
"""Mandarin OS · Mandarin Update, como el Windows Update de Windows 7.

Un recuadro con el escudo de color dice cómo está el equipo (al día, hay actualizaciones, error) y el botón para
instalarlas; debajo, cuándo se buscaron e instalaron por última vez. A la izquierda: buscar, cambiar la
configuración y el historial. Se puede elegir qué actualizaciones instalar.

Por dentro usa apt con pkexec: buscar (apt-get update) no pide contraseña (regla de polkit
org.mandarinos.update.buscar); instalar sí, una vez.

Uso: mandarin-update [historial | configuracion]
     mandarin-update --aviso    al entrar en la sesión: busca una vez al día y avisa si hay actualizaciones
"""
import datetime
import glob
import gzip
import os
import re
import subprocess
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, Gio, GLib, Gtk, asegurar_agente, cargar_css, clase, cristal, ejecutar, etiqueta, existe, tam  # noqa: E402,F401

GLib.set_prgname('mandarin-update')
GLib.set_application_name('Mandarin Update')

BUSCAR = '/usr/lib/mandarin/update-buscar'
INSTALAR = '/usr/lib/mandarin/update-instalar'
CONFIG = os.path.expanduser('~/.config/mandarin/update')
ULTIMA = os.path.expanduser('~/.cache/mandarin/update-ultima')
COLORES = {'bien': (0.20, 0.62, 0.30), 'aviso': (0.96, 0.66, 0.10), 'mal': (0.78, 0.18, 0.24), 'trabajando': (0.95, 0.42, 0.11)}
CSS = b"""
.u-recuadro { border: 1px solid alpha(@theme_fg_color, 0.18); background-color: @theme_base_color; }
.u-clave { opacity: 0.72; }
.u-nota { background-color: alpha(#f26b1d, 0.08); padding: 6px 10px; }
"""
TITULOS = {'mandarin-escritorio': 'Mandarin OS: novedades y arreglos del escritorio', 'firefox-esr': 'Firefox, el navegador',
		   'linux-image-amd64': 'Núcleo del sistema (Linux)', 'xfce4-panel': 'Barra de tareas'}
MESES = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre')


def leer(ruta, defecto=''):
	try:
		with open(ruta) as f:
			return f.read().strip()
	except OSError:
		return defecto


def guardar(ruta, texto):
	os.makedirs(os.path.dirname(ruta), exist_ok=True)
	with open(ruta, 'w') as f:
		f.write(texto)


def cuando(segundos):
	"""«Hoy a las 10:32», «Ayer a las 18:05», «3 de noviembre a las 9:10»."""
	if not segundos:
		return 'Nunca'
	f = datetime.datetime.fromtimestamp(segundos)
	hoy = datetime.date.today()
	hora = f'{f.hour}:{f.minute:02d}'
	if f.date() == hoy:
		return f'Hoy a las {hora}'
	if f.date() == hoy - datetime.timedelta(days=1):
		return f'Ayer a las {hora}'
	anio = '' if f.year == hoy.year else f' de {f.year}'
	return f'{f.day} de {MESES[f.month - 1]}{anio} a las {hora}'


def ultima_busqueda():
	marcas = [os.path.getmtime(f) for f in glob.glob('/var/lib/apt/lists/*Release')]
	try:
		marcas.append(float(leer(ULTIMA, '0')))
	except ValueError:
		pass
	return max(marcas, default=0)


class Actualizacion:
	def __init__(self, nombre, nueva, vieja, rama):
		self.nombre, self.nueva, self.vieja = nombre, nueva, vieja
		self.seguridad = 'security' in rama
		self.titulo, self.descripcion, self.tamano = nombre, '', 0
		self.marcada = True


def listar():
	"""Las actualizaciones que hay (de las listas que apt ya tiene descargadas; no hace falta ser administrador)."""
	entorno = dict(os.environ, LC_ALL='C.UTF-8')
	texto = subprocess.run(['apt', 'list', '--upgradable'], capture_output=True, text=True, env=entorno).stdout
	lista = []
	for linea in texto.splitlines():
		m = re.match(r'^([^/\s]+)/(\S+)\s+(\S+)\s+\S+\s+\[[^:]+:\s*([^\]]+)\]', linea)
		if m:
			lista.append(Actualizacion(m.group(1), m.group(3), m.group(4).strip(), m.group(2)))
	if lista:
		# descripción (en español si apt la tiene traducida) y tamaño de descarga
		datos = subprocess.run(['apt-cache', 'show', '--no-all-versions'] + [f'{a.nombre}={a.nueva}' for a in lista],
							   capture_output=True, text=True).stdout
		por_nombre = {a.nombre: a for a in lista}
		for estrofa in datos.split('\n\n'):
			campos = dict(re.findall(r'^([\w-]+): (.*)$', estrofa, re.M))
			a = por_nombre.get(campos.get('Package'))
			if a is None:
				continue
			descripcion = next((v for k, v in campos.items() if k.startswith('Description-') and k != 'Description-md5'), '') \
				or campos.get('Description', '')
			a.descripcion = descripcion
			a.tamano = int(campos.get('Size', '0') or 0)
			if a.nombre in TITULOS:
				a.titulo = TITULOS[a.nombre]
			elif a.nombre.startswith('linux-image-'):
				a.titulo = 'Núcleo del sistema (Linux)'
			elif a.nombre.startswith('firmware-'):
				a.titulo = 'Controladores de hardware (firmware)'
			elif descripcion:
				a.titulo = descripcion[:1].upper() + descripcion[1:]
	importancia = lambda a: (a.nombre != 'mandarin-escritorio', not a.seguridad, a.titulo.lower())  # noqa: E731
	return sorted(lista, key=importancia)


def historial():
	"""Lo instalado y actualizado, del registro de apt (el más reciente primero)."""
	filas = []
	for ruta in glob.glob('/var/log/apt/history.log*'):
		try:
			abrir = gzip.open if ruta.endswith('.gz') else open
			with abrir(ruta, 'rt', errors='replace') as f:
				texto = f.read()
		except OSError:
			continue
		for bloque in texto.split('\n\n'):
			m = re.search(r'^Start-Date: (\S+)\s+(\S+)$', bloque, re.M)
			if not m:
				continue
			try:
				fecha = datetime.datetime.strptime(f'{m.group(1)} {m.group(2)}', '%Y-%m-%d %H:%M:%S')
			except ValueError:
				continue
			estado = 'Con errores' if re.search(r'^Error:', bloque, re.M) else 'Correcta'
			for clave, que in (('Upgrade', 'Actualización'), ('Install', 'Instalación'), ('Remove', 'Desinstalación')):
				linea = re.search(rf'^{clave}: (.+)$', bloque, re.M)
				if not linea:
					continue
				for nombre, versiones in re.findall(r'([^\s:,]+)(?::\S+)? \(([^)]*)\)', linea.group(1)):
					if 'automatic' in versiones:
						continue
					version = versiones.split(', ')[-1]
					titulo = f'Mandarin OS {version}' if nombre == 'mandarin-escritorio' else f'{que} de {nombre} ({version})'
					filas.append((fecha, titulo, estado))
	filas.sort(key=lambda f: f[0], reverse=True)
	return filas[:800]


def reinicio_necesario(nombres):
	return any(re.match(r'^(linux-image|linux-firmware|firmware-|libc6$|systemd$|dbus$|nvidia)', n) for n in nombres)


# ─── Ventana ─────────────────────────────────────────────────────────────────────────────────────────────────────

class Escudo(Gtk.DrawingArea):
	"""El escudo de Windows Update en el color del estado, con un signo blanco."""

	def __init__(self, estado, signo):
		super().__init__(valign=Gtk.Align.START)
		self.color, self.signo = COLORES[estado], signo
		self.set_size_request(56, 62)
		self.connect('draw', self.pintar)

	def pintar(self, _a, cr):
		cr.translate((self.get_allocated_width() - 48) / 2, 3)
		cr.move_to(24, 1)
		cr.curve_to(31, 6, 38, 7.5, 46, 7.5)
		cr.line_to(46, 26)
		cr.curve_to(46, 40, 37, 49.5, 24, 55)
		cr.curve_to(11, 49.5, 2, 40, 2, 26)
		cr.line_to(2, 7.5)
		cr.curve_to(10, 7.5, 17, 6, 24, 1)
		cr.close_path()
		cr.set_source_rgb(*self.color)
		cr.fill_preserve()
		cr.save()
		cr.clip()
		cr.rectangle(0, 0, 24, 56)   # la mitad izquierda más clara, como el escudo de Windows 7
		cr.set_source_rgba(1, 1, 1, 0.16)
		cr.fill()
		cr.restore()
		cr.set_source_rgb(1, 1, 1)
		cr.set_line_width(4.6)
		cr.set_line_cap(1)
		cr.set_line_join(1)
		if self.signo == 'bien':
			cr.move_to(14, 28)
			cr.line_to(21, 35)
			cr.line_to(34, 19)
			cr.stroke()
		elif self.signo == 'aviso':
			cr.move_to(24, 14)
			cr.line_to(24, 30)
			cr.stroke()
			cr.arc(24, 39, 2.8, 0, 6.3)
			cr.fill()
		elif self.signo == 'mal':
			cr.move_to(16.5, 19.5)
			cr.line_to(31.5, 34.5)
			cr.move_to(31.5, 19.5)
			cr.line_to(16.5, 34.5)
			cr.stroke()
		else:   # flechas dando la vuelta
			cr.set_line_width(4)
			cr.arc(24, 27, 10, 3.6, 7.4)
			cr.stroke()
			cr.move_to(27.5, 12.5)
			cr.line_to(34.5, 17.5)
			cr.line_to(27, 22.5)
			cr.close_path()
			cr.fill()


def raya(color):
	a = Gtk.DrawingArea()
	a.set_size_request(7, -1)
	a.connect('draw', lambda _a, cr: (cr.set_source_rgb(*color), cr.paint()))
	return a


class Update(Gtk.ApplicationWindow):
	def __init__(self, app, pagina='inicio'):
		super().__init__(application=app, title='Mandarin Update')
		self.set_default_size(860, 580)
		self.set_icon_name('mandarin-update')
		cristal(self)
		self.actualizaciones = []
		self.estado = 'inicial'
		self.detalle = ''
		self.progreso = None
		self.proceso = None
		todo = Gtk.Box()
		self.add(todo)
		todo.pack_start(self.lateral(), False, False, 0)
		self.pila = clase(Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=120), 'm-contenido')
		todo.pack_start(self.pila, True, True, 0)
		for nombre in ('inicio', 'seleccionar', 'historial', 'configuracion'):
			desliza = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
			caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=24)
			desliza.add(caja)
			self.pila.add_named(desliza, nombre)
			setattr(self, 'caja_' + nombre, caja)
		self.show_all()
		self.ir(pagina)
		self.listar_sin_buscar()

	# ── lateral ──
	def lateral(self):
		fuera = clase(Gtk.Box(width_request=230), 'm-lateral')
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin=14)
		fuera.pack_start(caja, True, True, 0)

		def enlace(texto, funcion, *clases):
			b = clase(Gtk.Button(relief=Gtk.ReliefStyle.NONE), 'm-enlace', *clases)
			lbl = etiqueta(texto)
			lbl.set_line_wrap(True)
			b.add(lbl)
			b.connect('clicked', lambda *_: funcion())
			return b
		caja.pack_start(enlace('Inicio del Panel de control', lambda: ejecutar('mandarin-panel')), False, False, 4)
		caja.pack_start(Gtk.Box(height_request=10), False, False, 0)
		caja.pack_start(enlace('Buscar actualizaciones', self.buscar), False, False, 0)
		caja.pack_start(enlace('Cambiar configuración', lambda: self.ir('configuracion')), False, False, 0)
		caja.pack_start(enlace('Ver historial de actualizaciones', lambda: self.ir('historial')), False, False, 0)
		pie = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
		pie.pack_start(etiqueta('Vea también', 'm-seccion', 'm-tenue'), False, False, 4)
		pie.pack_start(enlace('Programas instalados', lambda: ejecutar('mandarin-panel', 'programas')), False, False, 0)
		pie.pack_start(enlace('Salud del equipo', lambda: ejecutar('mandarin-salud')), False, False, 0)
		caja.pack_end(pie, False, False, 0)
		return fuera

	def ir(self, pagina):
		getattr(self, 'pagina_' + pagina)()
		self.pila.set_visible_child_name(pagina)

	@staticmethod
	def vaciar(caja):
		for hijo in caja.get_children():
			caja.remove(hijo)

	# ── página principal ──
	def pagina_inicio(self):
		c = self.caja_inicio
		self.vaciar(c)
		c.pack_start(etiqueta('Mandarin Update', 'm-titulo1'), False, False, 0)
		seleccion = [a for a in self.actualizaciones if a.marcada]
		e = self.estado
		if e in ('inicial', 'buscando'):
			color, signo, titulo = 'trabajando', 'trabajando', 'Buscando actualizaciones…'
			texto = 'Puede tardar unos minutos.' if e == 'buscando' else ''
		elif e == 'hay':
			color, signo, titulo = 'aviso', 'aviso', 'Descargar e instalar actualizaciones para el equipo'
			texto = ''
		elif e == 'aldia':
			color, signo, titulo = 'bien', 'bien', 'Mandarin OS está al día'
			texto = 'No hay actualizaciones disponibles para el equipo.'
		elif e == 'instalando':
			color, signo, titulo = 'trabajando', 'trabajando', 'Instalando actualizaciones…'
			texto = self.detalle or 'Preparando…'
		elif e == 'instalado':
			color, signo, titulo = 'bien', 'bien', 'Las actualizaciones se han instalado correctamente'
			texto = self.detalle
		elif e == 'reiniciar':
			color, signo, titulo = 'aviso', 'aviso', 'Reinicia el equipo para terminar de instalar las actualizaciones'
			texto = 'Guarda lo que tengas abierto antes de reiniciar.'
		else:   # 'error' o 'fallo'
			color, signo = 'mal', 'mal'
			titulo = 'No se han podido buscar actualizaciones' if e == 'error' else 'No se han podido instalar las actualizaciones'
			texto = self.detalle

		recuadro = clase(Gtk.Box(), 'u-recuadro')
		recuadro.pack_start(raya(COLORES[color]), False, False, 0)
		dentro = Gtk.Box(spacing=14, margin=16)
		recuadro.pack_start(dentro, True, True, 0)
		dentro.pack_start(Escudo(color, signo), False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
		dentro.pack_start(textos, True, True, 0)
		t = etiqueta(titulo, 'm-titulo2')
		t.set_line_wrap(True)
		textos.pack_start(t, False, False, 0)
		if texto:
			lbl = etiqueta(texto, 'm-tenue')
			lbl.set_line_wrap(True)
			lbl.set_selectable(e in ('error', 'fallo'))
			textos.pack_start(lbl, False, False, 0)
		if e == 'hay':
			fila = Gtk.Box(spacing=24)
			enlace = clase(Gtk.Button(relief=Gtk.ReliefStyle.NONE, halign=Gtk.Align.START), 'm-enlace')
			n = len(self.actualizaciones)
			enlace.add(etiqueta(f'{n} actualizaci{"ones" if n > 1 else "ón"} importante{"s" if n > 1 else ""} disponible{"s" if n > 1 else ""}', 'm-fuerte'))
			enlace.connect('clicked', lambda *_: self.ir('seleccionar'))
			fila.pack_start(enlace, False, False, 0)
			total = sum(a.tamano for a in seleccion)
			fila.pack_end(etiqueta(f'{len(seleccion)} seleccionada{"s" if len(seleccion) != 1 else ""}' +
								   (f', {tam(total)}' if total else ''), 'm-tenue'), False, False, 0)
			textos.pack_start(fila, False, False, 0)
		if e in ('buscando', 'instalando', 'inicial'):
			self.barra = Gtk.ProgressBar(margin_top=4)
			if self.progreso is None:
				self.barra.pulse()
			else:
				self.barra.set_fraction(self.progreso)
			textos.pack_start(self.barra, False, False, 0)
		botones = Gtk.Box(spacing=8, halign=Gtk.Align.END, margin_top=6)
		if e == 'hay':
			b = Gtk.Button(label='Instalar actualizaciones')
			b.set_sensitive(bool(seleccion))
			b.connect('clicked', lambda *_: self.instalar())
			botones.pack_end(b, False, False, 0)
		elif e in ('aldia', 'instalado'):
			b = Gtk.Button(label='Buscar actualizaciones')
			b.connect('clicked', lambda *_: self.buscar())
			botones.pack_end(b, False, False, 0)
		elif e == 'reiniciar':
			b = Gtk.Button(label='Reiniciar ahora')
			b.connect('clicked', lambda *_: ejecutar('systemctl', 'reboot'))
			botones.pack_end(b, False, False, 0)
		elif e in ('error', 'fallo'):
			b = Gtk.Button(label='Intentar de nuevo')
			b.connect('clicked', lambda *_: self.buscar() if e == 'error' else self.instalar())
			botones.pack_end(b, False, False, 0)
			if 'hora' in self.detalle:
				h = Gtk.Button(label='Fecha y hora')
				h.connect('clicked', lambda *_: ejecutar('mandarin-panel', 'hora'))
				botones.pack_end(h, False, False, 0)
		textos.pack_start(botones, False, False, 0)
		c.pack_start(recuadro, False, False, 8)

		# debajo, como en Windows 7
		rejilla = Gtk.Grid(column_spacing=18, row_spacing=6, margin_top=6)
		instalada = historial()
		filas = [('Búsqueda más reciente de actualizaciones:', cuando(ultima_busqueda())),
				 ('Actualizaciones instaladas:', cuando(instalada[0][0].timestamp()) if instalada else 'Nunca'),
				 ('Recibe actualizaciones:', 'De Mandarin OS y de Debian'),
				 ('Versión de Mandarin OS:', self.version())]
		for i, (k, v) in enumerate(filas):
			rejilla.attach(etiqueta(k, 'u-clave'), 0, i, 1, 1)
			rejilla.attach(etiqueta(v), 1, i, 1, 1)
		historia = clase(Gtk.Button(relief=Gtk.ReliefStyle.NONE), 'm-enlace')
		historia.add(etiqueta('Ver historial de actualizaciones'))
		historia.connect('clicked', lambda *_: self.ir('historial'))
		rejilla.attach(historia, 2, 1, 1, 1)
		c.pack_start(rejilla, False, False, 0)
		if leer(CONFIG) == 'nunca':
			nota = clase(etiqueta('Las actualizaciones automáticas están desactivadas: Mandarin OS no avisará de las nuevas. '
								  'Puedes cambiarlo en «Cambiar configuración».'), 'u-nota')
			nota.set_line_wrap(True)
			c.pack_start(nota, False, False, 12)
		c.show_all()

	@staticmethod
	def version():
		v = subprocess.run(['dpkg-query', '-W', '-f=${Version}', 'mandarin-escritorio'], capture_output=True, text=True).stdout
		return v.strip() or 'desconocida'

	def repintar(self):
		if self.pila.get_visible_child_name() == 'inicio':
			self.pagina_inicio()
		return False

	# ── buscar ──
	def listar_sin_buscar(self):
		"""Al abrir: si se buscó hace poco, enseña lo que ya se sabe; si no, busca."""
		if time.time() - ultima_busqueda() > 6 * 3600:
			self.buscar()
			return

		def trabajo():
			lista = listar()
			GLib.idle_add(self.fin_listar, lista)
		threading.Thread(target=trabajo, daemon=True).start()

	def fin_listar(self, lista):
		self.actualizaciones = lista
		self.estado = 'hay' if lista else 'aldia'
		self.repintar()
		return False

	def ocupado(self):
		return self.proceso is not None

	def buscar(self):
		if self.ocupado():
			return
		self.estado, self.progreso, self.detalle = 'buscando', None, ''
		self.ir('inicio')
		GLib.timeout_add(120, self.latido)

		def trabajo():
			try:
				self.proceso = subprocess.Popen(['pkexec', BUSCAR], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
				salida, errores = self.proceso.communicate()
				codigo = self.proceso.returncode
			except OSError as e:
				salida, errores, codigo = '', str(e), 1
			self.proceso = None
			if codigo == 0:
				guardar(ULTIMA, str(time.time()))
				GLib.idle_add(self.fin_listar, listar())
			else:
				GLib.idle_add(self.fallo_busqueda, codigo, errores + salida)
		threading.Thread(target=trabajo, daemon=True).start()

	def latido(self):
		if self.estado in ('buscando', 'inicial') or (self.estado == 'instalando' and self.progreso is None):
			barra = getattr(self, 'barra', None)
			if barra is not None:
				barra.pulse()
			return True
		return False

	def fallo_busqueda(self, codigo, texto):
		self.estado = 'error'
		if codigo in (126, 127):
			self.detalle = 'No se ha dado permiso para buscar actualizaciones.'
		elif re.search(r'not valid yet|no es válido todavía|invalid for another|expired|ha caducado', texto, re.I):
			self.detalle = ('La hora del equipo está mal y por eso no se fía de los servidores. Pon bien la fecha y '
							'la hora (mejor en automático) y vuelve a intentarlo.')
		elif re.search(r'resolv|Could not connect|No se pudo conectar|Network is unreachable|Temporary failure', texto, re.I):
			self.detalle = 'No hay conexión a internet. Conéctate a una red y vuelve a intentarlo.'
		else:
			ultimas = [l for l in texto.strip().splitlines() if l.startswith(('E:', 'W:', 'Err'))][-3:]
			self.detalle = 'Ha fallado la búsqueda.\n' + '\n'.join(ultimas or texto.strip().splitlines()[-3:])
		self.repintar()
		return False

	# ── instalar ──
	def instalar(self):
		seleccion = [a for a in self.actualizaciones if a.marcada]
		if self.ocupado() or not seleccion:
			return
		todas = len(seleccion) == len(self.actualizaciones)
		nombres = [a.nombre for a in seleccion]
		self.estado, self.progreso, self.detalle = 'instalando', None, 'Esperando la contraseña…'
		self.ir('inicio')
		GLib.timeout_add(120, self.latido)

		def trabajo():
			orden = ['pkexec', INSTALAR] + ([] if todas else nombres)
			errores = []
			asegurar_agente()   # sin la ventana de la contraseña, pkexec falla sin decir nada
			try:
				self.proceso = subprocess.Popen(orden, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
				hilo = threading.Thread(target=lambda: errores.extend(self.proceso.stderr.readlines()), daemon=True)
				hilo.start()
				for linea in self.proceso.stdout:
					self.leer_estado(linea, len(nombres))
				codigo = self.proceso.wait()
				hilo.join(2)
			except OSError as e:
				codigo, errores = 1, [str(e)]
			self.proceso = None
			GLib.idle_add(self.fin_instalar, codigo, ''.join(errores), nombres)
		threading.Thread(target=trabajo, daemon=True).start()

	def leer_estado(self, linea, total):
		# APT::Status-Fd: «dlstatus:3:42.5:Descargando…» y «pmstatus:paquete:67.1:Configurando paquete»
		partes = linea.rstrip('\n').split(':', 3)
		if len(partes) < 4 or partes[0] not in ('dlstatus', 'pmstatus'):
			return
		try:
			por = float(partes[2]) / 100
		except ValueError:
			return
		if partes[0] == 'dlstatus':
			progreso, detalle = 0.35 * por, f'Descargando actualizaciones… {round(por * 100)} %'
		else:
			progreso, detalle = 0.35 + 0.65 * por, f'Instalando: {partes[1]} ({round(por * 100)} %)'
		GLib.idle_add(self.avance, progreso, detalle)

	def avance(self, progreso, detalle):
		self.progreso, self.detalle = progreso, detalle
		barra = getattr(self, 'barra', None)
		if barra is not None and self.estado == 'instalando':
			barra.set_fraction(progreso)
			# el texto de debajo del título
			for hijo in barra.get_parent().get_children():
				if isinstance(hijo, Gtk.Label) and 'm-tenue' in hijo.get_style_context().list_classes():
					hijo.set_text(detalle)
		return False

	def fin_instalar(self, codigo, errores, nombres):
		if codigo in (126, 127):
			self.estado = 'hay'
			self.detalle = ''
			self.repintar()
			if 'agent' in errores.lower():
				texto = ('No se ha podido abrir la ventana que pide la contraseña. Cierra la sesión, vuelve a entrar '
						 'y prueba otra vez.')
			elif codigo == 127:
				texto = 'La contraseña no era correcta. Es la misma con la que entras en el equipo.'
			else:
				texto = 'Para instalar actualizaciones hace falta escribir la contraseña del equipo en la ventana que sale.'
			self.mensaje('No se ha instalado nada', texto)
			return False
		if codigo != 0:
			self.estado = 'fallo'
			lineas = [l for l in errores.strip().splitlines() if l.startswith('E:')][-3:] or errores.strip().splitlines()[-3:]
			self.detalle = 'Algo ha fallado al instalar:\n' + '\n'.join(lineas)
			if re.search(r'Could not get lock|bloqueo', errores):
				self.detalle = 'Otro programa está instalando cosas ahora mismo (quizá la Tienda). Espera a que acabe y vuelve a intentarlo.'
			self.repintar()
			return False
		n = len(nombres)
		self.detalle = f'Se ha{"n" if n > 1 else ""} instalado {n} actualizaci{"ones" if n > 1 else "ón"}.'
		if 'mandarin-escritorio' in nombres:
			self.detalle += ' Las novedades del escritorio se ven al cerrar la sesión y volver a entrar.'
		self.estado = 'reiniciar' if reinicio_necesario(nombres) else 'instalado'
		self.actualizaciones = []
		self.repintar()

		def trabajo():
			lista = listar()
			if lista:
				GLib.idle_add(self.quedan, lista)
		threading.Thread(target=trabajo, daemon=True).start()
		return False

	def quedan(self, lista):
		if self.estado == 'instalado':
			self.fin_listar(lista)
		return False

	def mensaje(self, titulo, texto):
		d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
							  buttons=Gtk.ButtonsType.OK, text=titulo)
		d.format_secondary_text(texto)
		d.run()
		d.destroy()

	# ── elegir actualizaciones ──
	def pagina_seleccionar(self):
		c = self.caja_seleccionar
		self.vaciar(c)
		c.pack_start(etiqueta('Selecciona las actualizaciones que quieres instalar', 'm-titulo2'), False, False, 0)
		modelo = Gtk.ListStore(bool, str, str, str, int)
		for i, a in enumerate(self.actualizaciones):
			modelo.append([a.marcada, a.titulo, tam(a.tamano) if a.tamano else '', a.nombre, i])
		vista = Gtk.TreeView(model=modelo, headers_visible=True)
		marca = Gtk.CellRendererToggle()

		def cambiar(_r, ruta):
			modelo[ruta][0] = not modelo[ruta][0]
			self.actualizaciones[modelo[ruta][4]].marcada = modelo[ruta][0]
			resumen.set_text(texto_resumen())
		marca.connect('toggled', cambiar)
		vista.append_column(Gtk.TreeViewColumn('', marca, active=0))
		celda = Gtk.CellRendererText(ellipsize=3)
		col = Gtk.TreeViewColumn('Nombre', celda, text=1)
		col.set_expand(True)
		vista.append_column(col)
		vista.append_column(Gtk.TreeViewColumn('Tamaño', Gtk.CellRendererText(xalign=1.0), text=2))
		desliza = Gtk.ScrolledWindow(shadow_type=Gtk.ShadowType.IN, min_content_height=280)
		desliza.add(vista)
		juntos = Gtk.Box(spacing=14)
		juntos.pack_start(desliza, True, True, 0)
		ficha = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, width_request=240)
		ficha_titulo = etiqueta('', 'm-titulo3')
		ficha_titulo.set_line_wrap(True)
		ficha_texto = etiqueta('Elige una actualización para ver de qué es.', 'm-tenue')
		ficha_texto.set_line_wrap(True)
		ficha_texto.set_selectable(True)
		ficha.pack_start(ficha_titulo, False, False, 0)
		ficha.pack_start(ficha_texto, False, False, 0)
		juntos.pack_start(ficha, False, False, 0)
		c.pack_start(juntos, True, True, 0)

		def elegida(seleccion):
			m, it = seleccion.get_selected()
			if it is None:
				return
			a = self.actualizaciones[m[it][4]]
			ficha_titulo.set_text(a.titulo)
			partes = [a.descripcion if a.descripcion.lower() != a.titulo.lower() else '', f'Paquete: {a.nombre}', f'Versión instalada: {a.vieja}', f'Versión nueva: {a.nueva}']
			if a.tamano:
				partes.append(f'Descarga: {tam(a.tamano)}')
			if a.seguridad:
				partes.append('Es una actualización de seguridad: conviene instalarla.')
			ficha_texto.set_text('\n'.join(p for p in partes if p))
		vista.get_selection().connect('changed', elegida)

		def texto_resumen():
			sel = [a for a in self.actualizaciones if a.marcada]
			total = sum(a.tamano for a in sel)
			return f'Total seleccionado: {len(sel)} de {len(self.actualizaciones)}' + (f', {tam(total)}' if total else '')
		pie = Gtk.Box(spacing=8)
		resumen = etiqueta(texto_resumen(), 'm-tenue')
		pie.pack_start(resumen, True, True, 0)
		aceptar = Gtk.Button(label='Aceptar')
		aceptar.connect('clicked', lambda *_: self.ir('inicio'))
		pie.pack_end(aceptar, False, False, 0)
		c.pack_start(pie, False, False, 0)
		c.show_all()

	# ── historial ──
	def pagina_historial(self):
		c = self.caja_historial
		self.vaciar(c)
		c.pack_start(etiqueta('Historial de actualizaciones', 'm-titulo2'), False, False, 0)
		c.pack_start(etiqueta('Lo que se ha instalado y actualizado en este equipo, lo más reciente primero.', 'm-tenue'), False, False, 0)
		modelo = Gtk.ListStore(str, str, str)
		for fecha, titulo, estado in historial():
			modelo.append([titulo, estado, cuando(fecha.timestamp())])
		vista = Gtk.TreeView(model=modelo)
		for i, (titulo, expandir) in enumerate((('Nombre', True), ('Estado', False), ('Fecha de instalación', False))):
			col = Gtk.TreeViewColumn(titulo, Gtk.CellRendererText(ellipsize=3 if expandir else 0), text=i)
			col.set_expand(expandir)
			col.set_resizable(True)
			vista.append_column(col)
		desliza = Gtk.ScrolledWindow(shadow_type=Gtk.ShadowType.IN, min_content_height=360)
		desliza.add(vista)
		c.pack_start(desliza, True, True, 6)
		if not len(modelo):
			c.pack_start(etiqueta('Todavía no se ha instalado ninguna actualización.', 'm-tenue'), False, False, 0)
		volver = Gtk.Button(label='Aceptar', halign=Gtk.Align.END)
		volver.connect('clicked', lambda *_: self.ir('inicio'))
		c.pack_start(volver, False, False, 0)
		c.show_all()

	# ── configuración ──
	def pagina_configuracion(self):
		c = self.caja_configuracion
		self.vaciar(c)
		c.pack_start(etiqueta('Elige cómo quieres recibir las actualizaciones', 'm-titulo2'), False, False, 0)
		texto = etiqueta('Al entrar en la sesión, Mandarin Update busca actualizaciones de Mandarin OS y de Debian una vez '
						 'al día y te avisa con una notificación si hay alguna. Nunca instala nada sin preguntar: para '
						 'instalar hace falta la contraseña del equipo.', 'm-tenue')
		texto.set_line_wrap(True)
		texto.set_max_width_chars(80)
		c.pack_start(texto, False, False, 0)
		fila = Gtk.Box(spacing=12, margin_top=10)
		fila.pack_start(Escudo('aviso', 'aviso'), False, False, 0)
		dentro = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
		dentro.pack_start(etiqueta('Actualizaciones importantes', 'm-titulo3'), False, False, 0)
		combo = Gtk.ComboBoxText()
		combo.append('avisar', 'Buscar actualizaciones y avisarme si hay (recomendado)')
		combo.append('nunca', 'No buscar actualizaciones (no recomendado)')
		combo.set_active_id('nunca' if leer(CONFIG) == 'nunca' else 'avisar')
		dentro.pack_start(combo, False, False, 0)
		fila.pack_start(dentro, False, False, 0)
		c.pack_start(fila, False, False, 0)
		botones = Gtk.Box(spacing=8, halign=Gtk.Align.END, margin_top=20)
		cancelar = Gtk.Button(label='Cancelar')
		cancelar.connect('clicked', lambda *_: self.ir('inicio'))
		aceptar = Gtk.Button(label='Aceptar')

		def guardar_config(*_):
			guardar(CONFIG, combo.get_active_id())
			self.ir('inicio')
		aceptar.connect('clicked', guardar_config)
		botones.pack_end(aceptar, False, False, 0)
		botones.pack_end(cancelar, False, False, 0)
		c.pack_start(botones, False, False, 0)
		c.show_all()


class AppUpdate(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Update', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)

	def do_command_line(self, linea):
		args = [a for a in linea.get_arguments()[1:] if not a.startswith('--')]
		pagina = args[0] if args and args[0] in ('historial', 'configuracion') else 'inicio'
		ventana = self.get_active_window()
		if ventana:
			if not ventana.ocupado():
				ventana.ir(pagina)
			ventana.present()
		else:
			Update(self, pagina).present()
		return 0


def aviso():
	"""Al entrar en la sesión: una búsqueda al día como mucho y una notificación si hay algo."""
	time.sleep(120)
	if leer(CONFIG) == 'nunca' or time.time() - ultima_busqueda() < 20 * 3600:
		return
	r = subprocess.run(['pkexec', BUSCAR], capture_output=True, text=True)
	if r.returncode != 0:
		return
	guardar(ULTIMA, str(time.time()))
	n = len(listar())
	if not n or not existe('notify-send'):
		return
	titulo = f'Hay {n} actualizaci{"ones" if n > 1 else "ón"} para el equipo'
	base = ['notify-send', '-i', 'mandarin-update', '-a', 'Mandarin Update', titulo, 'Ábrelas en Mandarin Update para instalarlas.']
	r = subprocess.run(base[:1] + ['-A', 'abrir=Ver actualizaciones'] + base[1:], capture_output=True, text=True)
	if r.returncode != 0:
		subprocess.run(base, check=False)   # libnotify antigua: sin botón
	elif r.stdout.strip() == 'abrir':
		ejecutar('mandarin-update')


if __name__ == '__main__':
	if '--aviso' in sys.argv:
		aviso()
	else:
		sys.exit(AppUpdate().run(sys.argv))
