#!/usr/bin/env python3
"""Mandarin OS · Salud del equipo: cómo está el ordenador, explicado sin tecnicismos.

Pensado para equipos con años: cuánto conserva la batería de su capacidad original, si el disco avisa de fallos
(SMART, leído de udisks2 sin contraseña), la temperatura, la memoria y quién la gasta, el espacio libre, la red
(incluida la tarjeta que no tiene controlador o el cable que no da señal), la hora y las actualizaciones, y lo que
tarda en arrancar. Cada cosa sale en verde, naranja o rojo con un consejo y el botón que lo arregla.
«Guardar informe» deja un .txt en el Escritorio para pedir ayuda con él.

Uso: mandarin-salud            la ventana
     mandarin-salud --aviso    al entrar: solo avisa (notificación) si algo está mal de verdad
     mandarin-salud --texto    el informe por la salida estándar
"""
import glob
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, Gio, GLib, Gtk, cargar_css, carpeta, clase, cristal, ejecutar, etiqueta, existe, tam  # noqa: E402
import psutil  # noqa: E402

GLib.set_prgname('mandarin-salud')
GLib.set_application_name('Salud del equipo')

CSS = b"""
.s-tarjeta { background-color: @theme_base_color; border: 1px solid alpha(@theme_fg_color, 0.10); border-radius: 8px; padding: 14px 16px; }
.s-cabecera { padding: 18px 22px; }
.s-bien { color: #2e9d4f; }
.s-aviso { color: #e0600f; }
.s-mal { color: #c62f3e; }
.s-info { color: alpha(@theme_fg_color, 0.6); }
.s-punto { font-size: 15pt; }
.s-dato { opacity: 0.72; }
.s-consejo { background-color: alpha(#f26b1d, 0.08); border-radius: 6px; padding: 8px 10px; }
"""
ORDEN = {'mal': 0, 'aviso': 1, 'bien': 2, 'info': 3}
PALABRA = {'bien': 'Bien', 'aviso': 'Conviene mirarlo', 'mal': 'Necesita atención', 'info': ''}


def leer(ruta, defecto=''):
	try:
		with open(ruta, errors='replace') as f:
			return f.read().strip()
	except OSError:
		return defecto


def num(ruta):
	try:
		return int(leer(ruta))
	except ValueError:
		return 0


def salida(*orden, tiempo=5):
	try:
		return subprocess.run(list(orden), capture_output=True, text=True, env=dict(os.environ, LC_ALL='C.UTF-8', LANGUAGE=''), timeout=tiempo).stdout
	except (OSError, subprocess.SubprocessError):
		return ''


def duracion(segundos):
	segundos = int(segundos)
	if segundos < 60:
		return f'{segundos} s'
	minutos, segundos = divmod(segundos, 60)
	if minutos < 60:
		return f'{minutos} min' + (f' {segundos} s' if segundos and minutos < 5 else '')
	horas, minutos = divmod(minutos, 60)
	if horas < 48:
		return f'{horas} h {minutos} min' if minutos else f'{horas} h'
	return f'{horas // 24} días'


def hace(segundos):
	return 'hace ' + duracion(max(segundos, 0)) if segundos >= 60 else 'hace un momento'


def porcentaje(parte):
	return f'{round(parte * 100)} %'


class Tarjeta:
	def __init__(self, titulo, iconos, estado='info', resumen=''):
		self.titulo, self.iconos, self.estado, self.resumen = titulo, iconos, estado, resumen
		self.datos = []      # (clave, valor)
		self.barra = None    # (fracción, texto)
		self.consejo = ''
		self.acciones = []   # (texto, función)

	def dato(self, clave, valor):
		if valor not in (None, ''):
			self.datos.append((clave, str(valor)))

	def peor(self, estado, consejo=None):
		if ORDEN[estado] < ORDEN[self.estado] or self.estado == 'info':
			self.estado = estado
		if consejo:
			self.consejo = (self.consejo + '\n' if self.consejo else '') + consejo


# ─── Lo que se mira ──────────────────────────────────────────────────────────────────────────────────────────────

def equipo():
	"""Nombre del equipo, procesador, memoria y edad aproximada (por la fecha de la BIOS)."""
	malos = ('to be filled', 'system product', 'default string', 'not applicable', 'o.e.m', 'none', 'system manufacturer')
	partes = []
	for f in ('sys_vendor', 'product_name'):
		v = leer(f'/sys/class/dmi/id/{f}')
		if v and not any(m in v.lower() for m in malos) and v not in partes:
			partes.append(v)
	nombre = ' '.join(partes) or socket.gethostname()
	cpu = ''
	for linea in leer('/proc/cpuinfo').splitlines():
		if linea.startswith('model name'):
			cpu = re.sub(r'\s+', ' ', linea.split(':', 1)[1]).replace('(R)', '').replace('(TM)', '').replace(' CPU', '').strip()
			break
	edad = ''
	fecha = leer('/sys/class/dmi/id/bios_date')   # mm/dd/aaaa
	m = re.search(r'(\d{4})$', fecha)
	if m:
		anio = int(m.group(1))
		anos = time.localtime().tm_year - anio
		if 1990 < anio and anos >= 1:
			edad = f'BIOS de {anio}: tiene unos {anos} años'
	version = salida('dpkg-query', '-W', '-f=${Version}', 'mandarin-escritorio').strip()
	return {'nombre': nombre, 'cpu': cpu, 'nucleos': psutil.cpu_count() or 1,
			'memoria': psutil.virtual_memory().total, 'edad': edad, 'version': version}


def bateria():
	for d in sorted(glob.glob('/sys/class/power_supply/*')):
		if leer(d + '/type') != 'Battery' or leer(d + '/scope') == 'Device' or leer(d + '/present', '1') == '0':
			continue
		lleno = num(d + '/energy_full') or num(d + '/charge_full')
		diseno = num(d + '/energy_full_design') or num(d + '/charge_full_design')
		carga = num(d + '/capacity')
		estado = leer(d + '/status')
		t = Tarjeta('Batería', ['battery-good', 'battery', 'battery-full'])
		if diseno and lleno:
			salud = min(lleno / diseno, 1.0)
			t.barra = (salud, f'Conserva el {porcentaje(salud)} de su capacidad original')
			t.resumen = f'Conserva el {porcentaje(salud)} de lo que aguantaba nueva'
			if salud >= 0.8:
				t.peor('bien')
			elif salud >= 0.5:
				t.peor('aviso', f'Ha perdido el {porcentaje(1 - salud)}: es el desgaste normal de una batería con años. '
							'Durará menos de lo que marcaba nueva; para que se gaste más despacio, no la dejes al 100 % '
							'enchufada todo el día ni la vacíes del todo.')
			else:
				recambio = ' '.join(x for x in (leer(d + '/manufacturer'), leer(d + '/model_name')) if x)
				t.peor('mal', 'La batería está muy gastada y puede apagarse de golpe aunque marque carga. Conviene '
						   'cambiarla' + (f' (para buscar recambio: «{recambio}»).' if recambio else '.'))
		else:
			t.resumen = 'No dice cuánto aguantaba nueva'
		textos = {'Charging': 'cargando', 'Discharging': 'con batería', 'Full': 'llena', 'Not charging': 'enchufada, sin cargar'}
		t.dato('Carga ahora', f'{carga} % ({textos.get(estado, estado.lower())})' if carga else '')
		energia, potencia = num(d + '/energy_now'), num(d + '/power_now')
		if not potencia and num(d + '/current_now'):
			energia, potencia = num(d + '/charge_now'), num(d + '/current_now')
		if estado == 'Discharging' and potencia > 0 and energia:
			t.dato('Le queda', 'unas ' + duracion(energia / potencia * 3600))
		ciclos = num(d + '/cycle_count')
		t.dato('Ciclos de carga', ciclos if ciclos > 0 else '')
		t.dato('Modelo', ' '.join(x for x in (leer(d + '/manufacturer'), leer(d + '/model_name'), leer(d + '/technology')) if x))
		return t
	return None


def objetos_udisks():
	try:
		bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
		r = bus.call_sync('org.freedesktop.UDisks2', '/org/freedesktop/UDisks2', 'org.freedesktop.DBus.ObjectManager',
						  'GetManagedObjects', None, GLib.VariantType.new('(a{oa{sa{sv}}})'), Gio.DBusCallFlags.NONE, 4000, None)
		return r.unpack()[0]
	except GLib.Error:
		return {}


def texto_ay(v):
	try:
		return bytes(v).rstrip(b'\0').decode(errors='replace')
	except (TypeError, ValueError):
		return ''


def disco():
	t = Tarjeta('Disco', ['drive-harddisk', 'drive-harddisk-system'])
	# espacio
	uso = shutil.disk_usage('/')
	libre = uso.free / uso.total if uso.total else 1
	t.barra = (1 - libre, f'{tam(uso.free)} libres de {tam(uso.total)}')
	t.resumen = f'{tam(uso.free)} libres'
	if uso.free < 2 * 1024 ** 3 or libre < 0.05:
		t.peor('mal', 'Queda muy poco espacio: los programas y las actualizaciones pueden fallar. Vacía la papelera '
				   'y borra o pasa a un USB lo que no uses (vídeos y Descargas suelen ser lo que más ocupa).')
	elif libre < 0.15:
		t.peor('aviso', 'Empieza a faltar espacio. «Liberar espacio» vacía la papelera y las miniaturas guardadas.')
	else:
		t.peor('bien')
	t.acciones.append(('Liberar espacio', 'liberar'))
	# el disco del sistema en udisks2: modelo, si es SSD y lo que dice SMART
	objetos = objetos_udisks()
	raiz = next((p.device for p in psutil.disk_partitions() if p.mountpoint == '/'), '')
	unidad = None
	for _ruta, ifs in objetos.items():
		b = ifs.get('org.freedesktop.UDisks2.Block')
		if b and raiz and raiz in (texto_ay(b.get('Device', b'')), texto_ay(b.get('PreferredDevice', b''))):
			unidad = b.get('Drive')
	if unidad in (None, '/'):
		# sistema en vivo o raíz rara: el disco fijo más grande
		fijos = [(ifs['org.freedesktop.UDisks2.Drive'].get('Size', 0), r) for r, ifs in objetos.items()
				 if 'org.freedesktop.UDisks2.Drive' in ifs and not ifs['org.freedesktop.UDisks2.Drive'].get('Removable')]
		unidad = max(fijos)[1] if fijos else None
	ifs = objetos.get(unidad, {})
	d = ifs.get('org.freedesktop.UDisks2.Drive', {})
	if d:
		t.dato('Modelo', ' '.join(x for x in (d.get('Vendor', '').strip(), d.get('Model', '').strip()) if x))
		giro = d.get('RotationRate', -1)
		tipo = 'SSD (sin piezas que giren)' if giro == 0 else (f'Disco duro de {giro} rpm' if giro > 0 else '')
		t.dato('Tipo', tipo)
		if giro > 0:
			t.consejo_ssd = True
	ata = ifs.get('org.freedesktop.UDisks2.Drive.Ata', {})
	nvme = ifs.get('org.freedesktop.UDisks2.NVMe.Controller', {})
	if ata.get('SmartSupported') and ata.get('SmartUpdated'):
		if ata.get('SmartFailing'):
			t.peor('mal', 'EL DISCO AVISA DE QUE VA A FALLAR. Copia ya tus fotos y documentos a un USB o a la nube: '
					   'puede dejar de funcionar en cualquier momento.')
			t.dato('Estado SMART', 'avisa de fallo')
		else:
			t.dato('Estado SMART', 'sin avisos de fallo')
		malos = ata.get('SmartNumBadSectors', 0)
		if malos > 0:
			t.peor('aviso' if malos < 50 else 'mal', f'El disco tiene {malos} sectores dañados. Haz copia de lo importante: '
						'si el número sube, el disco se está estropeando.')
			t.dato('Sectores dañados', malos)
		horas = ata.get('SmartPowerOnSeconds', 0) // 3600
		t.dato('Horas encendido', f'{horas:,}'.replace(',', '.') + ' h' if horas else '')
		grados = ata.get('SmartTemperature', 0)
		t.dato('Temperatura', f'{grados - 273.15:.0f} °C' if grados > 250 else '')
	elif nvme.get('SmartUpdated'):
		critico = nvme.get('SmartCriticalWarning', [])
		t.dato('Estado SMART', 'avisa de fallo' if critico else 'sin avisos de fallo')
		if critico:
			t.peor('mal', 'El SSD avisa de un problema serio. Copia ya lo importante a un USB o a la nube.')
		horas = nvme.get('SmartPowerOnHours', 0)
		t.dato('Horas encendido', f'{horas:,}'.replace(',', '.') + ' h' if horas else '')
	elif d:
		t.dato('Estado SMART', 'este disco no lo informa')
	if getattr(t, 'consejo_ssd', False) and t.estado == 'bien':
		t.consejo = ('Es un disco duro mecánico. Si algún día quieres que el equipo vaya mucho más rápido, cambiarlo por '
					 'un SSD es la mejora que más se nota en un ordenador antiguo.')
	return t


def temperatura():
	try:
		sensores = psutil.sensors_temperatures()
	except (AttributeError, OSError):
		return None
	if not sensores:
		return None
	for clave in ('coretemp', 'k10temp', 'zenpower', 'cpu_thermal', 'cpu-thermal', 'acpitz'):
		if clave in sensores:
			lecturas = [s for s in sensores[clave] if s.current > 0]
			break
	else:
		lecturas = [s for v in sensores.values() for s in v if s.current > 0]
	if not lecturas:
		return None
	caliente = max(lecturas, key=lambda s: s.current)
	alta = caliente.high if caliente.high and 60 < caliente.high < 110 else 85
	t = Tarjeta('Temperatura', ['temperature-normal', 'sensors-temperature', 'cpu', 'utilities-system-monitor'])
	t.resumen = f'{caliente.current:.0f} °C en el procesador'
	t.barra = (min(caliente.current / 100, 1.0), f'{caliente.current:.0f} °C (alta a partir de {alta:.0f} °C)')
	if caliente.current >= alta:
		t.peor('mal', 'Está muy caliente. Si se apaga solo o va a tirones, limpia el polvo de las rejillas y del '
				   'ventilador y no lo uses encima de la cama o un cojín, que tapan la ventilación.')
	elif caliente.current >= alta - 15:
		t.peor('aviso', 'Está caliente. Con juegos o vídeos es normal; si pasa sin hacer nada, puede tener polvo dentro '
						'o algún programa gastando procesador (míralo en el Administrador de tareas).')
	else:
		t.peor('bien')
	try:
		ventiladores = [f.current for v in (psutil.sensors_fans() or {}).values() for f in v if f.current > 0]
	except (AttributeError, OSError):
		ventiladores = []
	t.dato('Ventilador', f'{max(ventiladores)} rpm' if ventiladores else '')
	t.dato('Uso del procesador', f'{psutil.cpu_percent(interval=0.5):.0f} %')
	return t


def memoria():
	m = psutil.virtual_memory()
	t = Tarjeta('Memoria', ['media-memory', 'memory', 'utilities-system-monitor'])
	usada = (m.total - m.available) / m.total
	t.barra = (usada, f'{tam(m.total - m.available)} en uso de {tam(m.total)}')
	t.resumen = f'{porcentaje(usada)} en uso'
	# quién gasta más (sumando todos los procesos de un mismo programa, como el navegador)
	por_nombre = {}
	for p in psutil.process_iter(['name', 'memory_info']):
		try:
			por_nombre[p.info['name']] = por_nombre.get(p.info['name'], 0) + p.info['memory_info'].rss
		except (TypeError, AttributeError, psutil.Error):
			pass
	if por_nombre:
		nombre, gasto = max(por_nombre.items(), key=lambda x: x[1])
		t.dato('Lo que más gasta', f'{nombre} ({tam(gasto)})')
	if os.path.exists('/sys/block/zram0'):
		comprimida = num('/sys/block/zram0/disksize')
		t.dato('Memoria comprimida (zram)', f'activa, hasta {tam(comprimida)}' if comprimida else 'activa')
	s = psutil.swap_memory()
	t.dato('Memoria de intercambio', f'{tam(s.used)} en uso de {tam(s.total)}' if s.total else 'no hay')
	if usada >= 0.92:
		t.peor('mal', 'La memoria está casi llena y el equipo irá a tirones. Cierra programas o pestañas del navegador '
				   'que no uses (en el Administrador de tareas ves cuáles gastan más).')
	elif usada >= 0.8:
		t.peor('aviso', 'Queda poca memoria libre. Cerrar pestañas del navegador es lo que más ayuda.')
	else:
		t.peor('bien')
	if m.total < 3 * 1024 ** 3 and t.estado == 'bien':
		t.consejo = ('Con menos de 3 GB, el navegador es lo que más memoria pide: mejor pocas pestañas a la vez. '
					 'Mandarin ya comprime la memoria (zram) para que dé más de sí.')
	t.acciones.append(('Administrador de tareas', 'tareas'))
	return t


def red():
	t = Tarjeta('Red e internet', ['network-wireless', 'network-workgroup', 'preferences-system-network'])
	direcciones = psutil.net_if_addrs()
	conectado = []
	for d in sorted(glob.glob('/sys/class/net/*')):
		nombre = os.path.basename(d)
		if nombre == 'lo' or not os.path.exists(d + '/device'):
			continue   # las virtuales (VPN, contenedores) no cuentan
		wifi = os.path.isdir(d + '/wireless') or os.path.exists(d + '/phy80211')
		tipo = 'Wi-Fi' if wifi else 'Cable (Ethernet)'
		controlador = os.path.basename(os.path.realpath(d + '/device/driver')) if os.path.exists(d + '/device/driver') else ''
		ip = next((a.address for a in direcciones.get(nombre, []) if a.family == socket.AF_INET), '')
		if ip:
			conectado.append(tipo)
			valor = f'conectado ({ip})'
		elif not wifi and leer(d + '/carrier', '0') != '1':
			valor = 'sin señal: cable desenchufado o el router no responde'
		else:
			valor = 'sin conectar'
		t.dato(tipo, valor + (f' · controlador {controlador}' if controlador else ''))
	# tarjetas que el sistema ve pero que no tienen controlador
	sin_controlador = []
	if existe('lspci'):
		for bloque in re.split(r'\n(?=\S)', salida('lspci', '-k')):
			cabeza = bloque.split('\n', 1)[0]
			if re.search(r'(Ethernet|Network) controller', cabeza) and 'Kernel driver in use' not in bloque:
				sin_controlador.append(cabeza.split(': ', 1)[-1])
	for tarjeta in sin_controlador:
		t.peor('aviso', f'Esta tarjeta de red no tiene controlador y no funcionará: {tarjeta}. '
						'Guarda el informe y pide ayuda con él: dice exactamente qué tarjeta es.')
	if rf := salida('rfkill', 'list', 'wifi'):
		if 'Hard blocked: yes' in rf:
			t.peor('aviso', 'El Wi-Fi está apagado con el interruptor o la tecla del portátil (suele ser Fn + una tecla '
							'con una antena dibujada).')
		elif 'Soft blocked: yes' in rf:
			t.peor('aviso', 'El Wi-Fi está desactivado (modo avión). Actívalo desde el icono de red de la barra de tareas.')
	conectividad = salida('nmcli', '-t', '-f', 'CONNECTIVITY', 'general').strip()
	if conectividad == 'full' or (not conectividad and conectado):
		t.resumen = 'Conectado a internet' + (f' por {conectado[0].split(" ")[0].lower()}' if conectado else '')
		t.peor('bien')
	elif conectividad == 'portal':
		t.resumen = 'La red pide iniciar sesión'
		t.peor('aviso', 'Estás en una red que pide entrar en una página (hoteles, bibliotecas): abre el navegador.')
	else:
		t.resumen = 'Sin internet'
		t.peor('aviso', 'No hay conexión a internet. Conéctate a una red Wi-Fi desde el icono de red de la barra de tareas.')
	return t


def hora_y_actualizaciones():
	t = Tarjeta('Hora y actualizaciones', ['system-software-update', 'software-update-available', 'preferences-system-time'])
	estado = dict(l.split('=', 1) for l in salida('timedatectl', 'show').splitlines() if '=' in l)
	if estado.get('NTPSynchronized') == 'yes':
		t.dato('Hora', 'en hora (se ajusta sola por internet)')
		t.peor('bien')
	else:
		t.dato('Hora', 'sin sincronizar')
		t.peor('aviso', 'La hora no está sincronizada. Si el reloj va mal, las páginas seguras y las actualizaciones '
						'fallan: revísalo en «Fecha y hora».')
		t.acciones.append(('Fecha y hora', 'hora'))
	version = salida('dpkg-query', '-W', '-f=${Version}', 'mandarin-escritorio').strip()
	t.dato('Mandarin OS', version)
	listas = [os.path.getmtime(f) for f in glob.glob('/var/lib/apt/lists/*Release')]
	if listas:
		dias = (time.time() - max(listas)) / 86400
		t.dato('Última búsqueda de actualizaciones', hace(time.time() - max(listas)))
		if dias > 14:
			t.peor('aviso', f'Hace {int(dias)} días que no se buscan actualizaciones.')
	t.resumen = 'Al día' if t.estado == 'bien' else 'Hay algo que revisar'
	t.acciones.append(('Buscar actualizaciones', 'actualizar'))
	return t


def arranque():
	t = Tarjeta('Arranque', ['system-run', 'system-reboot', 'applications-system'])
	linea = salida('systemd-analyze').split('\n', 1)[0]
	m = re.search(r'=\s*(.+?)\s*$', linea)
	segundos = 0
	if m:
		for valor, unidad in re.findall(r'([\d.]+)(min|ms|s|h)', m.group(1)):
			segundos += float(valor) * {'h': 3600, 'min': 60, 's': 1, 'ms': 0.001}[unidad]
	if segundos:
		t.resumen = f'Tarda {duracion(segundos)} en arrancar'
		t.peor('aviso' if segundos > 120 else 'bien',
			   'Arranca despacio. Quitar programas del inicio ayuda; con un disco duro mecánico, un SSD lo arreglaría.'
			   if segundos > 120 else None)
	encendido = duracion(time.time() - psutil.boot_time())
	t.dato('Encendido desde hace', encendido)
	if not t.resumen:
		t.resumen = f'Encendido desde hace {encendido}'
	# programas que se abren solos al entrar (los del usuario mandan sobre los del sistema)
	entradas = {}
	for carpeta_auto in ('/etc/xdg/autostart', os.path.expanduser('~/.config/autostart')):
		for f in glob.glob(carpeta_auto + '/*.desktop'):
			entradas[os.path.basename(f)] = f
	propios = 0
	for f in entradas.values():
		texto = leer(f)
		solo = re.search(r'^OnlyShowIn=(.*)$', texto, re.M)
		no = re.search(r'^NotShowIn=(.*)$', texto, re.M)
		if (re.search(r'^(Hidden=true|X-GNOME-Autostart-enabled=false)', texto, re.M)
				or (solo and 'XFCE' not in solo.group(1)) or (no and 'XFCE' in no.group(1))):
			continue
		if 'mandarin' not in os.path.basename(f) and 'Exec=mandarin' not in texto:
			propios += 1
	t.dato('Programas que se abren al entrar', propios)
	t.acciones.append(('Programas de inicio', 'inicio'))
	return t


def comprobar():
	tarjetas = []
	for f in (disco, bateria, temperatura, memoria, red, hora_y_actualizaciones, arranque):
		try:
			r = f()
		except Exception as e:  # noqa: BLE001 — una comprobación rota no debe tumbar las demás
			r = Tarjeta(f.__name__.replace('_', ' ').capitalize(), ['dialog-question'], 'info', f'No se ha podido comprobar ({e})')
		if r:
			tarjetas.append(r)
	return tarjetas


def resumen(tarjetas):
	malas = [t for t in tarjetas if t.estado == 'mal']
	avisos = [t for t in tarjetas if t.estado == 'aviso']
	if malas:
		return 'mal', 'Hay algo que necesita atención', ', '.join(t.titulo for t in malas + avisos)
	if avisos:
		n = len(avisos)
		return 'aviso', f'Hay {n} cosa{"s" if n > 1 else ""} que conviene mirar', ', '.join(t.titulo for t in avisos)
	return 'bien', 'Tu equipo está en buena forma', 'No hay nada de lo que preocuparse'


def informe(info, tarjetas):
	estado, titulo, sub = resumen(tarjetas)
	l = ['Mandarin OS · Salud del equipo', time.strftime('%d/%m/%Y %H:%M'), '',
		 f'Equipo: {info["nombre"]}', f'Procesador: {info["cpu"]} ({info["nucleos"]} hilos)',
		 f'Memoria: {tam(info["memoria"])}', f'Mandarin OS: {info["version"] or "?"} · Linux {platform.release()}']
	if info['edad']:
		l.append(info['edad'].capitalize())
	l += ['', f'RESUMEN: {titulo}' + (f' ({sub})' if estado != 'bien' else ''), '']
	for t in tarjetas:
		l.append(f'■ {t.titulo}: {t.resumen}' + (f'  [{PALABRA[t.estado]}]' if PALABRA[t.estado] else ''))
		if t.barra:
			l.append(f'    {t.barra[1]}')
		l += [f'    {c}: {v}' for c, v in t.datos]
		if t.consejo:
			l += ['    → ' + c for c in t.consejo.split('\n')]
		l.append('')
	# para quien ayude con un problema de red o de hardware
	l += ['── Detalles técnicos ──', '$ lspci -k (red)']
	l += [b for b in re.split(r'\n(?=\S)', salida('lspci', '-k')) if re.search(r'(Ethernet|Network) controller', b.split('\n')[0])]
	l += ['', '$ nmcli device', salida('nmcli', 'device').rstrip(), '', '$ rfkill list', salida('rfkill', 'list').rstrip()]
	return '\n'.join(l) + '\n'


# ─── Ventana ─────────────────────────────────────────────────────────────────────────────────────────────────────

def icono_tema(nombres, px):
	tema = Gtk.IconTheme.get_default()
	nombre = next((n for n in nombres if tema.has_icon(n)), 'dialog-information')
	imagen = Gtk.Image.new_from_icon_name(nombre, Gtk.IconSize.DIALOG)
	imagen.set_pixel_size(px)
	return imagen


class Salud(Gtk.ApplicationWindow):
	def __init__(self, app):
		super().__init__(application=app, title='Salud del equipo')
		self.set_default_size(720, 640)
		self.set_icon_name('mandarin-salud')
		cristal(self)
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.add(caja)
		# cabecera: el equipo y el resumen
		cab = clase(Gtk.Box(spacing=18), 's-cabecera', 'm-barra', 'm-borde-abajo')
		self.icono_estado = Gtk.Image()
		cab.pack_start(icono_tema(['computer', 'computer-laptop'], 72), False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER)
		self.titulo = etiqueta('Comprobando el equipo…', 'm-titulo1')
		self.subtitulo = etiqueta('', 'm-tenue')
		self.subtitulo.set_line_wrap(True)
		self.ficha = etiqueta('', 'm-pie', 'm-tenue')
		self.ficha.set_line_wrap(True)
		for w in (self.titulo, self.subtitulo, self.ficha):
			textos.pack_start(w, False, False, 0)
		cab.pack_start(textos, True, True, 0)
		caja.pack_start(cab, False, False, 0)
		# tarjetas
		desliza = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
		clase(desliza, 'm-contenido')
		self.lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=18)
		self.espera = Gtk.Spinner(active=True, halign=Gtk.Align.CENTER, margin_top=60)
		self.espera.set_size_request(32, 32)
		self.lista.pack_start(self.espera, False, False, 0)
		desliza.add(self.lista)
		caja.pack_start(desliza, True, True, 0)
		# pie
		pie = clase(Gtk.Box(spacing=8, margin=10), 'm-barra')
		self.repetir = Gtk.Button(label='Volver a comprobar')
		self.repetir.connect('clicked', lambda *_: self.comprobar())
		guardar = Gtk.Button(label='Guardar informe en el Escritorio')
		guardar.connect('clicked', self.guardar)
		self.nota = etiqueta('', 'm-pie', 'm-tenue', elipsis=True)
		pie.pack_start(self.nota, True, True, 4)
		pie.pack_end(self.repetir, False, False, 0)
		pie.pack_end(guardar, False, False, 0)
		caja.pack_start(clase(Gtk.Separator(), 'm-borde-arriba'), False, False, 0)
		caja.pack_start(pie, False, False, 0)
		self.info, self.tarjetas = None, []
		self.show_all()
		self.comprobar()

	def comprobar(self):
		self.repetir.set_sensitive(False)
		self.titulo.set_text('Comprobando el equipo…')

		def trabajo():
			info, tarjetas = equipo(), comprobar()
			GLib.idle_add(self.pintar, info, tarjetas)
		threading.Thread(target=trabajo, daemon=True).start()

	def pintar(self, info, tarjetas):
		self.info, self.tarjetas = info, tarjetas
		estado, titulo, sub = resumen(tarjetas)
		self.titulo.set_text(titulo)
		color = {'bien': '#2e9d4f', 'aviso': '#e0600f', 'mal': '#c62f3e'}[estado]
		self.subtitulo.set_markup(f'<span foreground="{color}">{GLib.markup_escape_text(sub)}</span>')
		ficha = [info['nombre'], info['cpu'], f'{tam(info["memoria"])} de memoria']
		if info['edad']:
			ficha.append(info['edad'])
		self.ficha.set_text(' · '.join(x for x in ficha if x))
		for hijo in self.lista.get_children():
			self.lista.remove(hijo)
		for t in sorted(tarjetas, key=lambda t: ORDEN[t.estado]):
			self.lista.pack_start(self.tarjeta(t), False, False, 0)
		self.lista.show_all()
		self.repetir.set_sensitive(True)
		self.nota.set_text('Comprobado a las ' + time.strftime('%H:%M'))
		return False

	def tarjeta(self, t):
		marco = clase(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8), 's-tarjeta')
		arriba = Gtk.Box(spacing=12)
		arriba.pack_start(icono_tema(t.iconos, 36), False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
		textos.pack_start(etiqueta(t.titulo, 'm-titulo3'), False, False, 0)
		textos.pack_start(etiqueta(t.resumen, 'm-tenue', elipsis=True), False, False, 0)
		arriba.pack_start(textos, True, True, 0)
		if PALABRA[t.estado]:
			marca = Gtk.Box(spacing=5, valign=Gtk.Align.CENTER)
			marca.pack_start(etiqueta('●', 's-punto', f's-{t.estado}'), False, False, 0)
			marca.pack_start(etiqueta(PALABRA[t.estado], 'm-fuerte', f's-{t.estado}'), False, False, 0)
			arriba.pack_end(marca, False, False, 0)
		marco.pack_start(arriba, False, False, 0)
		if t.barra:
			barra = clase(Gtk.LevelBar(min_value=0, max_value=1, value=max(0.0, min(t.barra[0], 1.0))), 'm-uso')
			if t.titulo != 'Batería' and t.barra[0] > 0.9:
				clase(barra, 'm-lleno')
			if t.titulo == 'Batería' and t.barra[0] < 0.5:
				clase(barra, 'm-lleno')
			marco.pack_start(barra, False, False, 0)
			marco.pack_start(etiqueta(t.barra[1], 'm-pie', 'm-tenue'), False, False, 0)
		if t.datos:
			rejilla = Gtk.Grid(column_spacing=16, row_spacing=3, margin_top=2)
			for i, (c, v) in enumerate(t.datos):
				rejilla.attach(etiqueta(c, 's-dato'), 0, i, 1, 1)
				valor = etiqueta(v)
				valor.set_line_wrap(True)
				valor.set_selectable(True)
				rejilla.attach(valor, 1, i, 1, 1)
			marco.pack_start(rejilla, False, False, 0)
		if t.consejo:
			consejo = clase(etiqueta(t.consejo), 's-consejo')
			consejo.set_line_wrap(True)
			consejo.set_max_width_chars(80)
			marco.pack_start(consejo, False, False, 2)
		if t.acciones:
			botones = Gtk.Box(spacing=8)
			for texto, accion in t.acciones:
				b = Gtk.Button(label=texto)
				b.connect('clicked', self.accion, accion)
				botones.pack_start(b, False, False, 0)
			marco.pack_start(botones, False, False, 2)
		return marco

	def accion(self, boton, accion):
		if accion == 'tareas':
			ejecutar('mandarin-tareas', 'procesos')
		elif accion == 'inicio':
			ejecutar('mandarin-tareas', 'inicio')
		elif accion == 'hora':
			ejecutar('mandarin-panel', 'hora')
		elif accion == 'actualizar':
			ejecutar('mandarin-update')
		elif accion == 'liberar':
			self.liberar(boton)

	def liberar(self, boton):
		boton.set_sensitive(False)
		boton.set_label('Liberando…')

		def peso(ruta):
			total = 0
			for raiz, _d, archivos in os.walk(ruta):
				for a in archivos:
					try:
						total += os.lstat(os.path.join(raiz, a)).st_size
					except OSError:
						pass
			return total

		def trabajo():
			total = 0
			for ruta in (os.path.join(GLib.get_user_data_dir(), 'Trash'), os.path.join(GLib.get_user_cache_dir(), 'thumbnails')):
				if os.path.isdir(ruta):
					total += peso(ruta)
					for hijo in os.listdir(ruta):
						p = os.path.join(ruta, hijo)
						try:
							if os.path.isdir(p) and not os.path.islink(p):
								shutil.rmtree(p, ignore_errors=True)
							else:
								os.remove(p)
						except OSError:
							pass
			GLib.idle_add(fin, total)

		def fin(total):
			self.nota.set_text(f'Se han liberado {tam(total)}' if total >= 1024 else 'No había nada que liberar')
			self.comprobar()
			return False
		threading.Thread(target=trabajo, daemon=True).start()

	def guardar(self, _b):
		if not self.info:
			return
		ruta = os.path.join(carpeta('escritorio'), 'Salud del equipo.txt')
		try:
			with open(ruta, 'w') as f:
				f.write(informe(self.info, self.tarjetas))
			self.nota.set_text('Informe guardado en el Escritorio: «Salud del equipo.txt»')
		except OSError as e:
			self.nota.set_text(f'No se ha podido guardar el informe: {e.strerror}')


class AppSalud(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Salud')

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)

	def do_activate(self):
		(self.get_active_window() or Salud(self)).present()


def aviso():
	"""Al entrar en la sesión: notificación solo si hay algo grave (disco que falla, sin espacio, batería muerta)."""
	time.sleep(90)
	graves = [t for t in (disco(), bateria(), temperatura()) if t and t.estado == 'mal']
	if not graves:
		return
	marca = os.path.expanduser('~/.cache/mandarin/salud-avisado')
	clave = ','.join(sorted(t.titulo for t in graves)) + time.strftime('%Y%W')   # como mucho un aviso por semana
	if leer(marca) == clave and 'Disco' not in clave:
		return
	os.makedirs(os.path.dirname(marca), exist_ok=True)
	with open(marca, 'w') as f:
		f.write(clave)
	t = graves[0]
	cuerpo = t.consejo.split('\n')[0] if t.consejo else t.resumen
	subprocess.run(['notify-send', '-u', 'critical' if t.titulo == 'Disco' else 'normal', '-i', 'mandarin-salud',
					'-a', 'Salud del equipo', f'{t.titulo}: {PALABRA[t.estado].lower()}', cuerpo], check=False)


if __name__ == '__main__':
	if '--aviso' in sys.argv:
		aviso()
	elif '--texto' in sys.argv:
		print(informe(equipo(), comprobar()), end='')
	else:
		sys.exit(AppSalud().run([sys.argv[0]]))
