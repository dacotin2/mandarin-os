#!/usr/bin/env python3
"""Mandarin OS · Recortes, como la herramienta de recortes de Windows (Win+Mayús+S o Impr Pant).

Lo primero que hace es la foto de la pantalla, y la enseña congelada y oscurecida: lo que se mueva detrás (vídeos,
juegos, menús) ya no cambia mientras eliges. Se elige una zona arrastrando (con el ratón o con el dedo), una
ventana o la pantalla entera. El recorte se copia solo (para pegarlo con Ctrl+V), se guarda en
Imágenes/Capturas de pantalla y se abre para marcar encima con el bolígrafo o el subrayador.

Uso: mandarin-recortes [--ventana | --pantalla]
"""
import math
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, GdkPixbuf, Gio, GLib, Gtk, cargar_css, carpeta, clase, etiqueta  # noqa: E402,F401
import cairo  # noqa: E402

try:
	import gi
	gi.require_version('Wnck', '3.0')
	from gi.repository import Wnck
except (ImportError, ValueError):
	Wnck = None

GLib.set_prgname('mandarin-recortes')
GLib.set_application_name('Recortes')

NARANJA = (0xf2 / 255, 0x6b / 255, 0x1d / 255)
COLORES = {'negro': (0.10, 0.09, 0.08), 'rojo': (0.85, 0.15, 0.18), 'naranja': NARANJA, 'azul': (0.12, 0.42, 0.85)}
CSS = b"""
.r-barra { background-color: rgba(250, 248, 245, 0.97); border: 1px solid rgba(0, 0, 0, 0.18); border-radius: 8px;
           padding: 4px; box-shadow: 0 6px 22px rgba(0, 0, 0, 0.35); }
.r-barra button { padding: 6px 12px; border-radius: 5px; border: none; background: none; box-shadow: none; color: #241c17; }
.r-barra button:hover { background-color: rgba(242, 107, 29, 0.12); }
.r-barra button:checked { background-color: rgba(242, 107, 29, 0.22); }
.r-pista { background-color: rgba(20, 16, 14, 0.72); color: #ffffff; border-radius: 6px; padding: 5px 12px; font-size: 9.5pt; }
.r-herramientas button.r-color { min-width: 18px; min-height: 18px; padding: 3px; border-radius: 12px; }
.r-lienzo { background-color: alpha(@theme_fg_color, 0.06); }
"""


def icono(nombres, px=16):
	tema = Gtk.IconTheme.get_default()
	nombre = next((n for n in nombres if tema.has_icon(n)), None)
	if nombre is None:
		return None
	img = Gtk.Image.new_from_icon_name(nombre, Gtk.IconSize.BUTTON)
	img.set_pixel_size(px)
	return img


def boton(texto, iconos=(), clase_=Gtk.Button, tooltip=None):
	b = clase_()
	caja = Gtk.Box(spacing=6)
	img = icono(iconos)
	if img is not None:
		caja.pack_start(img, False, False, 0)
	if texto:
		caja.pack_start(Gtk.Label(label=texto), False, False, 0)
	b.add(caja)
	if tooltip:
		b.set_tooltip_text(tooltip)
	return b


def ventanas():
	"""Rectángulos de las ventanas visibles, de la de arriba a la de abajo (el escritorio el último)."""
	if Wnck is None:
		return []
	pantalla = Wnck.Screen.get_default()
	pantalla.force_update()
	escritorio_activo = pantalla.get_active_workspace()
	lista = []
	for v in reversed(pantalla.get_windows_stacked()):
		if v.is_minimized():
			continue
		if escritorio_activo and v.get_window_type() != Wnck.WindowType.DESKTOP and not v.is_visible_on_workspace(escritorio_activo):
			continue
		x, y, w, h = v.get_geometry()
		if w > 1 and h > 1:
			lista.append((x, y, w, h))
	return lista


class Capa(Gtk.Window):
	"""La pantalla congelada y oscurecida, encima de todo, donde se elige qué recortar."""

	def __init__(self, app, foto, modo):
		super().__init__(type=Gtk.WindowType.POPUP)
		self.app, self.foto, self.modo = app, foto, modo
		self.ancho, self.alto = foto.get_width(), foto.get_height()
		self.inicio = self.fin = None
		self.resaltada = None
		self.lista_ventanas = ventanas()
		self.move(0, 0)
		self.set_default_size(self.ancho, self.alto)
		capas = Gtk.Overlay()
		self.add(capas)
		self.lienzo = Gtk.DrawingArea()
		self.lienzo.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK |
							   Gdk.EventMask.POINTER_MOTION_MASK)
		self.lienzo.connect('draw', self.pintar)
		self.lienzo.connect('button-press-event', self.pulsar)
		self.lienzo.connect('motion-notify-event', self.mover)
		self.lienzo.connect('button-release-event', self.soltar)
		capas.add(self.lienzo)
		arriba = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, halign=Gtk.Align.CENTER,
						 valign=Gtk.Align.START, margin_top=16)
		barra = clase(Gtk.Box(spacing=2), 'r-barra')
		self.modos = {}
		for clave, texto, iconos in (('rect', 'Rectángulo', ('selection-rectangular-symbolic', 'view-fullscreen-symbolic')),
									 ('ventana', 'Ventana', ('window-symbolic', 'focus-windows-symbolic', 'preferences-system-windows-symbolic')),
									 ('pantalla', 'Pantalla completa', ('video-display-symbolic', 'view-fullscreen-symbolic'))):
			b = boton(texto, iconos, Gtk.ToggleButton)
			b.set_active(clave == modo)
			b.connect('toggled', self.cambiar_modo, clave)
			barra.pack_start(b, False, False, 0)
			self.modos[clave] = b
		cerrar = boton('', ('window-close-symbolic',), tooltip='Cancelar (Esc)')
		if not cerrar.get_child().get_children():
			cerrar = Gtk.Button(label='✕')
		cerrar.connect('clicked', lambda *_: self.cancelar())
		barra.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL, margin=4), False, False, 0)
		barra.pack_start(cerrar, False, False, 0)
		arriba.pack_start(barra, False, False, 0)
		self.pista = clase(etiqueta('', xalign=0.5), 'r-pista')
		self.pista.set_halign(Gtk.Align.CENTER)
		arriba.pack_start(self.pista, False, False, 0)
		capas.add_overlay(arriba)
		self.connect('key-press-event', self.tecla)
		self.poner_pista()
		self.show_all()
		self.agarrar()

	def agarrar(self):
		"""Todo el ratón, el dedo y el teclado para esta ventana (si no, Esc no llegaría)."""
		ventana = self.get_window()
		asiento = Gdk.Display.get_default().get_default_seat()
		for _ in range(20):   # el gestor de ventanas puede tener el teclado un instante
			if asiento.grab(ventana, Gdk.SeatCapabilities.ALL, True, None, None, None) == Gdk.GrabStatus.SUCCESS:
				break
			time.sleep(0.02)

	def soltar_agarre(self):
		Gdk.Display.get_default().get_default_seat().ungrab()

	def poner_pista(self):
		self.pista.set_text({'rect': 'Arrastra para elegir la zona que quieres recortar · Esc para salir',
							 'ventana': 'Pulsa en la ventana que quieres recortar · Esc para salir',
							 'pantalla': 'Pulsa en cualquier sitio para recortar toda la pantalla'}[self.modo])

	def cambiar_modo(self, boton_, clave):
		if not boton_.get_active():
			if self.modo == clave:
				boton_.set_active(True)   # siempre hay uno elegido
			return
		self.modo = clave
		for k, b in self.modos.items():
			if k != clave and b.get_active():
				b.set_active(False)
		self.inicio = self.fin = self.resaltada = None
		self.poner_pista()
		self.lienzo.queue_draw()

	def rectangulo(self):
		if self.modo == 'ventana':
			return self.resaltada
		if self.modo == 'pantalla':
			return None
		if self.inicio and self.fin:
			x0, y0 = self.inicio
			x1, y1 = self.fin
			return (min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0))
		return None

	def pintar(self, _w, cr):
		Gdk.cairo_set_source_pixbuf(cr, self.foto, 0, 0)
		cr.paint()
		r = self.rectangulo()
		cr.set_source_rgba(0, 0, 0, 0.45)
		cr.rectangle(0, 0, self.ancho, self.alto)
		if r and r[2] > 0 and r[3] > 0:
			cr.rectangle(*r)
			cr.set_fill_rule(cairo.FILL_RULE_EVEN_ODD)
		cr.fill()
		if r and r[2] > 0 and r[3] > 0:
			x, y, w, h = r
			cr.set_source_rgb(*NARANJA)
			cr.set_line_width(2)
			cr.rectangle(x - 1, y - 1, w + 2, h + 2)
			cr.stroke()
			texto = f'{int(w)} × {int(h)}'
			cr.select_font_face('Inter', cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
			cr.set_font_size(12)
			ext = cr.text_extents(texto)
			tx = min(max(x, 4), self.ancho - ext.width - 16)
			ty = y + h + 22 if y + h + 28 < self.alto else y - 10
			cr.set_source_rgba(0.08, 0.06, 0.05, 0.8)
			cr.rectangle(tx, ty - 15, ext.width + 12, 21)
			cr.fill()
			cr.set_source_rgb(1, 1, 1)
			cr.move_to(tx + 6, ty)
			cr.show_text(texto)

	def ventana_en(self, x, y):
		for vx, vy, vw, vh in self.lista_ventanas:
			if vx <= x < vx + vw and vy <= y < vy + vh:
				return (max(vx, 0), max(vy, 0), min(vw, self.ancho - max(vx, 0)), min(vh, self.alto - max(vy, 0)))
		return (0, 0, self.ancho, self.alto)

	def pulsar(self, _w, e):
		if e.button != 1:
			if e.button == 3:
				self.cancelar()
			return True
		if self.modo == 'rect':
			self.inicio = self.fin = (e.x, e.y)
		return True

	def mover(self, _w, e):
		if self.modo == 'rect' and self.inicio:
			self.fin = (e.x, e.y)
			self.lienzo.queue_draw()
		elif self.modo == 'ventana':
			r = self.ventana_en(e.x, e.y)
			if r != self.resaltada:
				self.resaltada = r
				self.lienzo.queue_draw()
		return True

	def soltar(self, _w, e):
		if e.button != 1:
			return True
		if self.modo == 'pantalla':
			self.recortar((0, 0, self.ancho, self.alto))
		elif self.modo == 'ventana':
			self.recortar(self.ventana_en(e.x, e.y))
		elif self.inicio:
			self.fin = (e.x, e.y)
			r = self.rectangulo()
			self.inicio = self.fin = None
			if r and r[2] >= 4 and r[3] >= 4:
				self.recortar(r)
			else:
				self.lienzo.queue_draw()
		return True

	def tecla(self, _w, e):
		if e.keyval == Gdk.KEY_Escape:
			self.cancelar()
		elif e.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter) and self.modo == 'pantalla':
			self.recortar((0, 0, self.ancho, self.alto))
		return True

	def recortar(self, r):
		x, y, w, h = (int(round(v)) for v in r)
		x, y = max(0, x), max(0, y)
		w, h = min(w, self.ancho - x), min(h, self.alto - y)
		if w < 1 or h < 1:
			return
		recorte = self.foto.new_subpixbuf(x, y, w, h).copy()
		self.soltar_agarre()
		self.destroy()
		self.app.recorte_hecho(recorte)

	def cancelar(self):
		self.soltar_agarre()
		self.destroy()
		self.app.cancelado()


class Editor(Gtk.ApplicationWindow):
	"""El recorte, para marcar encima (bolígrafo, subrayador, borrador), copiarlo y guardarlo."""

	def __init__(self, app):
		super().__init__(application=app, title='Recortes')
		self.set_icon_name('mandarin-recortes')
		self.imagen = None
		self.trazos = []
		self.trazo = None
		self.herramienta = 'boli'
		self.color = 'rojo'
		self.escala, self.desplazamiento = 1.0, (0, 0)
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.add(caja)
		barra = clase(Gtk.Box(spacing=4, margin=6), 'r-herramientas')
		nuevo = boton('Nuevo recorte', ('mandarin-recortes', 'edit-cut-symbolic'), tooltip='Ctrl+N')
		nuevo.connect('clicked', lambda *_: app.nuevo_recorte('rect', espera=250))
		barra.pack_start(nuevo, False, False, 0)
		barra.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL, margin=4), False, False, 0)
		self.botones = {}
		for clave, texto, iconos in (('boli', 'Bolígrafo', ('document-edit-symbolic', 'edit-symbolic')),
									 ('subrayador', 'Subrayador', ('format-text-highlight-symbolic', 'marker-symbolic', 'draw-highlight-symbolic')),
									 ('borrador', 'Borrador', ('edit-clear-symbolic', 'draw-eraser-symbolic'))):
			b = boton(texto, iconos, Gtk.ToggleButton)
			b.set_active(clave == self.herramienta)
			b.connect('toggled', self.elegir, clave)
			barra.pack_start(b, False, False, 0)
			self.botones[clave] = b
		self.botones_color = {}
		for nombre, (r, g, b_) in COLORES.items():
			bc = clase(Gtk.ToggleButton(), 'r-color')
			muestra = Gtk.DrawingArea()
			muestra.set_size_request(14, 14)
			muestra.connect('draw', lambda _a, cr, c=(r, g, b_): (cr.arc(7, 7, 7, 0, 2 * math.pi), cr.set_source_rgb(*c), cr.fill()))
			bc.add(muestra)
			bc.set_tooltip_text(nombre.capitalize())
			bc.set_active(nombre == self.color)
			bc.connect('toggled', self.elegir_color, nombre)
			barra.pack_start(bc, False, False, 0)
			self.botones_color[nombre] = bc
		deshacer = boton('', ('edit-undo-symbolic',), tooltip='Deshacer (Ctrl+Z)')
		deshacer.connect('clicked', lambda *_: self.deshacer())
		barra.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL, margin=4), False, False, 0)
		barra.pack_start(deshacer, False, False, 0)
		guardar = boton('Guardar como…', ('document-save-as-symbolic', 'document-save-symbolic'), tooltip='Ctrl+S')
		guardar.connect('clicked', lambda *_: self.guardar_como())
		copiar = boton('Copiar', ('edit-copy-symbolic',), tooltip='Ctrl+C')
		copiar.connect('clicked', lambda *_: self.copiar())
		barra.pack_end(guardar, False, False, 0)
		barra.pack_end(copiar, False, False, 0)
		caja.pack_start(clase(barra, 'm-barra'), False, False, 0)
		self.lienzo = clase(Gtk.DrawingArea(), 'r-lienzo')
		self.lienzo.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK |
							   Gdk.EventMask.BUTTON1_MOTION_MASK)
		self.lienzo.connect('draw', self.pintar)
		self.lienzo.connect('button-press-event', self.pulsar)
		self.lienzo.connect('motion-notify-event', self.mover)
		self.lienzo.connect('button-release-event', self.soltar)
		caja.pack_start(self.lienzo, True, True, 0)
		self.nota = clase(etiqueta('', 'm-pie', 'm-tenue', elipsis=True), 'm-barra')
		self.nota.set_margin_start(10)
		self.nota.set_margin_top(4)
		self.nota.set_margin_bottom(4)
		caja.pack_start(self.nota, False, False, 0)
		self.connect('key-press-event', self.tecla)

	def poner(self, imagen, nota):
		self.imagen, self.trazos, self.trazo = imagen, [], None
		w, h = imagen.get_width(), imagen.get_height()
		pantalla = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
		area = pantalla.get_workarea()
		self.resize(max(560, min(w + 40, int(area.width * 0.8))), max(300, min(h + 120, int(area.height * 0.8))))
		self.nota.set_text(nota)
		self.lienzo.queue_draw()

	# ── herramientas ──
	def elegir(self, b, clave):
		if not b.get_active():
			if self.herramienta == clave:
				b.set_active(True)
			return
		self.herramienta = clave
		for k, otro in self.botones.items():
			if k != clave and otro.get_active():
				otro.set_active(False)

	def elegir_color(self, b, nombre):
		if not b.get_active():
			if self.color == nombre:
				b.set_active(True)
			return
		self.color = nombre
		for k, otro in self.botones_color.items():
			if k != nombre and otro.get_active():
				otro.set_active(False)
		if self.herramienta == 'borrador':
			self.botones['boli'].set_active(True)

	def a_imagen(self, x, y):
		dx, dy = self.desplazamiento
		return ((x - dx) / self.escala, (y - dy) / self.escala)

	def pulsar(self, _w, e):
		if e.button != 1 or self.imagen is None:
			return True
		p = self.a_imagen(e.x, e.y)
		if self.herramienta == 'borrador':
			self.borrar(p)
		else:
			self.trazo = {'tipo': self.herramienta, 'color': COLORES[self.color], 'puntos': [p]}
			if self.herramienta == 'subrayador':
				self.trazo['color'] = (1.0, 0.86, 0.10)
			self.trazos.append(self.trazo)
		self.lienzo.queue_draw()
		return True

	def mover(self, _w, e):
		p = self.a_imagen(e.x, e.y)
		if self.herramienta == 'borrador':
			self.borrar(p)
		elif self.trazo is not None:
			self.trazo['puntos'].append(p)
			self.lienzo.queue_draw()
		return True

	def soltar(self, _w, _e):
		self.trazo = None
		return True

	def borrar(self, p):
		radio = 12 / self.escala
		antes = len(self.trazos)
		self.trazos = [t for t in self.trazos if not any(math.hypot(q[0] - p[0], q[1] - p[1]) < radio for q in t['puntos'])]
		if len(self.trazos) != antes:
			self.lienzo.queue_draw()

	def deshacer(self):
		if self.trazos:
			self.trazos.pop()
			self.lienzo.queue_draw()

	@staticmethod
	def dibujar_trazos(cr, trazos):
		cr.set_line_cap(cairo.LINE_CAP_ROUND)
		cr.set_line_join(cairo.LINE_JOIN_ROUND)
		for t in trazos:
			puntos = t['puntos']
			if t['tipo'] == 'subrayador':
				cr.set_source_rgba(*t['color'], 0.40)
				cr.set_line_width(18)
				cr.set_line_cap(cairo.LINE_CAP_SQUARE)
			else:
				cr.set_source_rgb(*t['color'])
				cr.set_line_width(4)
				cr.set_line_cap(cairo.LINE_CAP_ROUND)
			cr.move_to(*puntos[0])
			for q in puntos[1:] if len(puntos) > 1 else [(puntos[0][0] + 0.1, puntos[0][1])]:
				cr.line_to(*q)
			cr.stroke()

	def pintar(self, w, cr):
		if self.imagen is None:
			return
		aw, ah = w.get_allocated_width(), w.get_allocated_height()
		iw, ih = self.imagen.get_width(), self.imagen.get_height()
		self.escala = min(1.0, (aw - 24) / iw, (ah - 24) / ih)
		self.desplazamiento = ((aw - iw * self.escala) / 2, (ah - ih * self.escala) / 2)
		cr.save()
		cr.translate(*self.desplazamiento)
		cr.scale(self.escala, self.escala)
		cr.set_source_rgba(0, 0, 0, 0.18)   # sombrita bajo el recorte
		cr.rectangle(3 / self.escala, 3 / self.escala, iw, ih)
		cr.fill()
		Gdk.cairo_set_source_pixbuf(cr, self.imagen, 0, 0)
		cr.paint()
		self.dibujar_trazos(cr, self.trazos)
		cr.restore()

	# ── resultado ──
	def resultado(self):
		iw, ih = self.imagen.get_width(), self.imagen.get_height()
		superficie = cairo.ImageSurface(cairo.FORMAT_ARGB32, iw, ih)
		cr = cairo.Context(superficie)
		Gdk.cairo_set_source_pixbuf(cr, self.imagen, 0, 0)
		cr.paint()
		self.dibujar_trazos(cr, self.trazos)
		superficie.flush()
		return Gdk.pixbuf_get_from_surface(superficie, 0, 0, iw, ih)

	def copiar(self):
		if self.imagen is None:
			return
		self.get_application().al_portapapeles(self.resultado())
		self.nota.set_text('Copiado: ya puedes pegarlo con Ctrl+V')

	def guardar_como(self):
		if self.imagen is None:
			return
		d = Gtk.FileChooserDialog(title='Guardar recorte', transient_for=self, action=Gtk.FileChooserAction.SAVE)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Guardar', Gtk.ResponseType.OK)
		d.set_do_overwrite_confirmation(True)
		d.set_current_folder(carpeta_capturas())
		d.set_current_name(time.strftime('Recorte %Y-%m-%d %H%M%S.png'))
		if d.run() == Gtk.ResponseType.OK:
			ruta = d.get_filename()
			tipo = 'jpeg' if ruta.lower().endswith(('.jpg', '.jpeg')) else 'png'
			if tipo == 'png' and not ruta.lower().endswith('.png'):
				ruta += '.png'
			try:
				self.resultado().savev(ruta, tipo, [], [])
				self.nota.set_text(f'Guardado en {ruta}')
			except GLib.Error as e:
				self.nota.set_text(f'No se ha podido guardar: {e.message}')
		d.destroy()

	def tecla(self, _w, e):
		ctrl = e.state & Gdk.ModifierType.CONTROL_MASK
		if ctrl and e.keyval in (Gdk.KEY_z, Gdk.KEY_Z):
			self.deshacer()
		elif ctrl and e.keyval in (Gdk.KEY_c, Gdk.KEY_C):
			self.copiar()
		elif ctrl and e.keyval in (Gdk.KEY_s, Gdk.KEY_S):
			self.guardar_como()
		elif ctrl and e.keyval in (Gdk.KEY_n, Gdk.KEY_N):
			self.get_application().nuevo_recorte('rect', espera=250)
		else:
			return False
		return True


def carpeta_capturas():
	ruta = os.path.join(carpeta('imagenes'), 'Capturas de pantalla')
	os.makedirs(ruta, exist_ok=True)
	return ruta


class AppRecortes(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Recortes', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
		self.capa = None
		self.editor = None
		self.esperando = False

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)

	def do_command_line(self, linea):
		args = linea.get_arguments()[1:]
		modo = 'ventana' if '--ventana' in args else 'pantalla' if '--pantalla' in args else 'rect'
		self.nuevo_recorte(modo)
		return 0

	def nuevo_recorte(self, modo, espera=0):
		if self.capa is not None or self.esperando:
			return
		self.esperando = True
		self.hold()   # que la aplicación no se cierre mientras no hay ninguna ventana
		if self.editor is not None and self.editor.get_visible():
			self.editor.hide()
			espera = max(espera, 250)   # que el editor desaparezca antes de la foto
		GLib.timeout_add(max(espera, 1), self.capturar, modo)

	def capturar(self, modo):
		self.esperando = False
		raiz = Gdk.get_default_root_window()
		foto = Gdk.pixbuf_get_from_window(raiz, 0, 0, raiz.get_width(), raiz.get_height())
		if foto is None:
			self.release()
			return False
		self.capa = Capa(self, foto, modo)
		return False

	def recorte_hecho(self, imagen):
		self.capa = None
		nota = 'Copiado: pégalo con Ctrl+V'
		try:
			ruta = os.path.join(carpeta_capturas(), time.strftime('Recorte %Y-%m-%d %H%M%S.png'))
			imagen.savev(ruta, 'png', [], [])
			nota += ' · Guardado en Imágenes › Capturas de pantalla'
		except (GLib.Error, OSError):
			pass
		self.al_portapapeles(imagen)
		if self.editor is None:
			self.editor = Editor(self)
		self.editor.poner(imagen, nota)
		self.editor.show_all()
		self.editor.present()
		self.release()

	def cancelado(self):
		self.capa = None
		if self.editor is not None and self.editor.imagen is not None:
			self.editor.show_all()
			self.editor.present()
		self.release()

	@staticmethod
	def al_portapapeles(imagen):
		portapapeles = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
		portapapeles.set_image(imagen)
		portapapeles.store()   # que siga ahí aunque se cierre Recortes

	def do_shutdown(self):
		Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).store()
		Gtk.Application.do_shutdown(self)


if __name__ == '__main__':
	sys.exit(AppRecortes().run(sys.argv))
