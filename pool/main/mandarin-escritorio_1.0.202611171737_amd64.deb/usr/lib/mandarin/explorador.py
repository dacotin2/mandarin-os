#!/usr/bin/env python3
"""Mandarin OS · Explorador de archivos.

Distribución del Explorador de Windows: panel lateral con Inicio, Galería, carpetas ancladas,
Este equipo, unidades y Red; ruta en migas; buscador; barra de órdenes; vista de iconos o de
detalles; panel de detalles abajo. Este equipo enseña los discos con su barra de espacio.
También atiende las peticiones de «abrir carpeta» del escritorio (org.xfce.FileManager).

Uso: mandarin-explorador [ruta | uri | inicio | equipo | galeria]
"""
import os
import sys
import subprocess
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import (CARPETAS, Gdk, GdkPixbuf, Gio, GLib, Gtk, abrir_archivo, cargar_css, carpeta, clase, cristal,  # noqa: E402
				   ejecutar, es_programa_windows, etiqueta, fecha, gb, icono, modo, pixbuf, tam)

COMPRIMIDOS = ('.zip', '.rar', '.7z', '.tar', '.gz', '.tgz', '.bz2', '.tbz2', '.xz', '.txz', '.zst', '.lz', '.lzma', '.cab',
			   '.arj', '.lha', '.iso')
from gi.repository import GObject, Pango  # noqa: E402
import propiedades  # noqa: E402

GLib.set_prgname('mandarin-explorador')
Gdk.set_program_class('mandarin-explorador')  # WM_CLASS igual al .desktop: la barra (docklike) lo junta con el anclado
GLib.set_application_name('Explorador de archivos')

ATRIB = ('standard::name,standard::display-name,standard::type,standard::size,standard::icon,standard::is-hidden,'
		 'standard::is-backup,standard::content-type,standard::target-uri,time::modified')
(C_PIX, C_NOMBRE, C_URI, C_DIR, C_ORDEN, C_TAM, C_FECHA, C_TIPO, C_DESC, C_TAMTXT, C_FECHATXT, C_PEQ) = range(12)
ESPECIALES = {'inicio': ('Inicio', 'user-home'), 'galeria': ('Galería', 'folder-pictures'), 'equipo': ('Este equipo', 'computer')}
MESES_IMG = ('image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp')


class Ventana(Gtk.ApplicationWindow):
	def __init__(self, app, lugar):
		super().__init__(application=app, title='Explorador de archivos')
		self.set_default_size(900, 560)
		self.set_icon_name('system-file-manager')
		cristal(self)
		self.set_position(Gtk.WindowPosition.CENTER)  # centrada, como en la maqueta (xfwm4 las pondría arriba a la izquierda)
		self.historia, self.pos = [], -1
		self.lugar = None
		self.portapapeles = (None, [])  # ('copiar' | 'cortar', [Gio.File])
		self.ocultos = False
		self.vista = 'iconos'
		self.generacion = 0
		self.vigilante = None
		self.monitor_vol = Gio.VolumeMonitor.get()
		self.monitor_vol.connect('mount-added', lambda *a: self.cambio_unidades())
		self.monitor_vol.connect('mount-removed', lambda *a: self.cambio_unidades())

		raiz = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.add(raiz)
		raiz.pack_start(self.barra_navegacion(), False, False, 0)
		raiz.pack_start(self.barra_ordenes(), False, False, 0)
		cuerpo = Gtk.Box()
		raiz.pack_start(cuerpo, True, True, 0)
		cuerpo.pack_start(self.panel_lateral(), False, False, 0)
		self.pila = Gtk.Stack(transition_type=Gtk.StackTransitionType.NONE)
		cuerpo.pack_start(self.pila, True, True, 0)
		self.modelo = Gtk.ListStore(GdkPixbuf.Pixbuf, str, str, bool, str, GObject.TYPE_INT64, GObject.TYPE_INT64, str, str, str, str, GdkPixbuf.Pixbuf)
		self.filtrado = self.modelo.filter_new()
		self.filtrado.set_visible_func(self.visible)
		self.pila.add_named(self.vista_iconos(), 'iconos')
		self.pila.add_named(self.vista_detalles(), 'detalles')
		self.caja_especial = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=16)
		desplaza = clase(Gtk.ScrolledWindow(), 'm-contenido')
		desplaza.add(self.caja_especial)
		self.pila.add_named(desplaza, 'especial')
		raiz.pack_start(self.panel_detalles(), False, False, 0)
		self.connect('key-press-event', self.tecla)
		self.show_all()
		self.ir(lugar)

	# ---------- construcción ----------
	def barra_navegacion(self):
		caja = clase(Gtk.Box(spacing=6, margin_start=10, margin_end=10, margin_top=6, margin_bottom=6), 'm-barra')
		self.b_atras = Gtk.Button.new_from_icon_name('go-previous-symbolic', Gtk.IconSize.BUTTON)
		self.b_adelante = Gtk.Button.new_from_icon_name('go-next-symbolic', Gtk.IconSize.BUTTON)
		self.b_arriba = Gtk.Button.new_from_icon_name('go-up-symbolic', Gtk.IconSize.BUTTON)
		for b, ayuda, f in ((self.b_atras, 'Atrás (Alt+Izquierda)', self.atras), (self.b_adelante, 'Adelante (Alt+Derecha)', self.adelante),
							(self.b_arriba, 'Subir un nivel (Alt+Arriba)', self.arriba)):
			b.set_tooltip_text(ayuda)
			b.connect('clicked', lambda _b, f=f: f())
			caja.pack_start(b, False, False, 0)
		self.pila_ruta = Gtk.Stack()
		self.migas = clase(Gtk.Box(spacing=0), 'm-ruta')
		evento = Gtk.EventBox()
		evento.add(self.migas)
		evento.connect('button-press-event', lambda *a: self.editar_ruta())
		self.entrada_ruta = Gtk.Entry()
		self.entrada_ruta.connect('activate', self.ruta_escrita)
		self.entrada_ruta.connect('focus-out-event', lambda *a: self.pila_ruta.set_visible_child_name('migas'))
		self.pila_ruta.add_named(evento, 'migas')
		self.pila_ruta.add_named(self.entrada_ruta, 'entrada')
		caja.pack_start(self.pila_ruta, True, True, 0)
		self.buscador = Gtk.SearchEntry()
		self.buscador.set_size_request(220, -1)
		self.buscador.connect('search-changed', lambda *a: self.filtrar())
		caja.pack_start(self.buscador, False, False, 0)
		return caja

	def barra_ordenes(self):
		caja = clase(Gtk.Box(spacing=2, margin_start=8, margin_end=8, margin_bottom=4), 'm-barra', 'm-borde-abajo')
		organizar = clase(Gtk.MenuButton(label='Organizar'), 'm-plano')
		organizar.set_image(Gtk.Image.new_from_icon_name('pan-down-symbolic', Gtk.IconSize.BUTTON))
		organizar.set_image_position(Gtk.PositionType.RIGHT)
		organizar.set_always_show_image(True)
		organizar.set_popup(self.menu_organizar())
		caja.pack_start(organizar, False, False, 0)
		for texto, icono_n, f in (('Abrir', 'document-open-symbolic', self.abrir_seleccion),
								 ('Nueva carpeta', 'folder-new-symbolic', self.nueva_carpeta)):
			b = clase(Gtk.Button(label=texto), 'm-plano')
			b.set_image(Gtk.Image.new_from_icon_name(icono_n, Gtk.IconSize.BUTTON))
			b.set_always_show_image(True)
			b.connect('clicked', lambda _b, f=f: f())
			caja.pack_start(b, False, False, 0)
		self.b_vaciar = clase(Gtk.Button(label='Vaciar papelera'), 'm-plano')
		self.b_vaciar.connect('clicked', lambda *a: self.vaciar_papelera())
		caja.pack_start(self.b_vaciar, False, False, 0)
		ver = clase(Gtk.MenuButton(label='Ver'), 'm-plano')
		ver.set_image(Gtk.Image.new_from_icon_name('view-grid-symbolic', Gtk.IconSize.BUTTON))
		ver.set_always_show_image(True)
		menu = Gtk.Menu()
		grupo = None
		for texto, v in (('Iconos', 'iconos'), ('Detalles', 'detalles')):
			item = Gtk.RadioMenuItem.new_with_label_from_widget(grupo, texto)
			grupo = grupo or item
			item.set_active(v == self.vista)
			item.connect('toggled', lambda it, v=v: it.get_active() and self.cambiar_vista(v))
			menu.append(item)
		menu.append(Gtk.SeparatorMenuItem())
		ocultos = Gtk.CheckMenuItem(label='Archivos ocultos')
		ocultos.connect('toggled', lambda it: self.poner_ocultos(it.get_active()))
		menu.append(ocultos)
		menu.show_all()
		ver.set_popup(menu)
		caja.pack_end(ver, False, False, 0)
		return caja

	def menu_organizar(self):
		menu = Gtk.Menu()
		for texto, f in (('Cortar', lambda: self.copiar(True)), ('Copiar', lambda: self.copiar(False)), ('Pegar', self.pegar), (None, None),
						 ('Cambiar nombre', self.renombrar), ('Eliminar', self.eliminar), (None, None), ('Seleccionar todo', self.seleccionar_todo),
						 (None, None), ('Propiedades', self.propiedades)):
			if texto is None:
				menu.append(Gtk.SeparatorMenuItem())
				continue
			item = Gtk.MenuItem(label=texto)
			item.connect('activate', lambda _i, f=f: f())
			menu.append(item)
		menu.show_all()
		return menu

	def panel_lateral(self):
		desplaza = clase(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER), 'm-lateral')
		desplaza.set_size_request(200, -1)
		self.lista_lateral = Gtk.ListBox(margin_top=6, margin_bottom=6)
		self.lista_lateral.set_selection_mode(Gtk.SelectionMode.SINGLE)
		self.lista_lateral.connect('row-activated', lambda _l, fila: fila.destino and self.ir(fila.destino))
		self.lista_lateral.connect('button-press-event', self.clic_derecho_lateral)
		desplaza.add(self.lista_lateral)
		self.pintar_lateral()
		return desplaza

	def fila_lateral(self, texto, nombre_icono, destino, anclada=False, gicon=None):
		fila = Gtk.ListBoxRow()
		fila.destino = destino
		caja = Gtk.Box(spacing=8)
		simbolico = nombre_icono if (nombre_icono or '').endswith('-symbolic') else f'{nombre_icono}-symbolic'
		img = Gtk.Image.new_from_gicon(gicon, Gtk.IconSize.MENU) if gicon else Gtk.Image.new_from_icon_name(simbolico, Gtk.IconSize.MENU)
		img.set_pixel_size(16)
		caja.pack_start(img, False, False, 0)
		caja.pack_start(etiqueta(texto, elipsis=True), True, True, 0)
		if anclada:
			chincheta = clase(Gtk.Image.new_from_icon_name('view-pin-symbolic', Gtk.IconSize.MENU), 'm-pin')
			caja.pack_end(chincheta, False, False, 0)
		fila.add(caja)
		return fila

	def separador_lateral(self):
		fila = Gtk.ListBoxRow(selectable=False, activatable=False)
		fila.destino = None
		fila.add(Gtk.Separator(margin_top=4, margin_bottom=4))
		return fila

	def pintar_lateral(self):
		for hijo in self.lista_lateral.get_children():
			self.lista_lateral.remove(hijo)
		self.lista_lateral.add(self.fila_lateral('Inicio', 'user-home', 'inicio'))
		self.lista_lateral.add(self.fila_lateral('Galería', 'folder-pictures', 'galeria'))
		self.lista_lateral.add(self.separador_lateral())
		for clave, nombre, _, icono_n in CARPETAS:
			self.lista_lateral.add(self.fila_lateral(nombre, icono_n, Gio.File.new_for_path(carpeta(clave)).get_uri(), anclada=True))
		self.lista_lateral.add(self.separador_lateral())
		self.lista_lateral.add(self.fila_lateral('Este equipo', 'computer', 'equipo'))
		for montaje in self.monitor_vol.get_mounts():
			if montaje.can_unmount() and not montaje.is_shadowed():
				fila = self.fila_lateral(montaje.get_name(), None, montaje.get_root().get_uri(), gicon=montaje.get_symbolic_icon())
				fila.montaje = montaje
				self.lista_lateral.add(fila)
		self.lista_lateral.add(self.fila_lateral('Red', 'network-workgroup', 'network:///'))
		self.lista_lateral.show_all()
		if self.lugar:
			self.marcar_lateral()

	def vista_iconos(self):
		desplaza = clase(Gtk.ScrolledWindow(), 'm-contenido')
		self.iconos = Gtk.IconView(model=self.filtrado)
		self.iconos.set_pixbuf_column(C_PIX)
		self.iconos.set_text_column(C_NOMBRE)
		self.iconos.set_item_width(92)
		self.iconos.set_margin(12)
		self.iconos.set_column_spacing(4)
		self.iconos.set_row_spacing(4)
		self.iconos.set_selection_mode(Gtk.SelectionMode.MULTIPLE)
		self.iconos.connect('item-activated', lambda _v, ruta: self.abrir_ruta_modelo(ruta))
		self.iconos.connect('selection-changed', lambda *a: self.pintar_detalles())
		self.iconos.connect('button-press-event', self.clic_derecho)
		desplaza.add(self.iconos)
		return desplaza

	def vista_detalles(self):
		desplaza = clase(Gtk.ScrolledWindow(), 'm-contenido')
		ordenado = Gtk.TreeModelSort(model=self.filtrado)
		self.arbol = Gtk.TreeView(model=ordenado)
		self.arbol.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
		col = Gtk.TreeViewColumn('Nombre')
		r_pix = Gtk.CellRendererPixbuf()
		r_txt = Gtk.CellRendererText(ellipsize=Pango.EllipsizeMode.END)
		col.pack_start(r_pix, False)
		col.pack_start(r_txt, True)
		col.add_attribute(r_pix, 'pixbuf', C_PEQ)
		col.add_attribute(r_txt, 'text', C_NOMBRE)
		col.set_expand(True)
		col.set_sort_column_id(C_ORDEN)
		col.set_resizable(True)
		self.arbol.append_column(col)
		for titulo, columna, orden in (('Fecha de modificación', C_FECHATXT, C_FECHA), ('Tipo', C_DESC, C_DESC), ('Tamaño', C_TAMTXT, C_TAM)):
			c = Gtk.TreeViewColumn(titulo, Gtk.CellRendererText(), text=columna)
			c.set_sort_column_id(orden)
			c.set_resizable(True)
			c.set_min_width(110)
			self.arbol.append_column(c)
		self.arbol.connect('row-activated', lambda _a, ruta, _c: self.abrir_ruta_modelo(ordenado.convert_path_to_child_path(ruta)))
		self.arbol.get_selection().connect('changed', lambda *a: self.pintar_detalles())
		self.arbol.connect('button-press-event', self.clic_derecho)
		desplaza.add(self.arbol)
		return desplaza

	def panel_detalles(self):
		caja = clase(Gtk.Box(spacing=12, margin_start=16, margin_end=16, margin_top=8, margin_bottom=8), 'm-barra')
		marco = clase(Gtk.Box(), 'm-borde-arriba', 'm-barra')
		marco.pack_start(caja, True, True, 0)
		self.det_icono = Gtk.Image()
		caja.pack_start(self.det_icono, False, False, 0)
		textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.det_nombre = etiqueta('', 'm-fuerte', elipsis=True)
		self.det_linea1 = etiqueta('', 'm-pie', 'm-tenue', elipsis=True)
		self.det_linea2 = etiqueta('', 'm-pie', elipsis=True)
		for w in (self.det_nombre, self.det_linea1, self.det_linea2):
			textos.pack_start(w, False, False, 0)
		caja.pack_start(textos, True, True, 0)
		self.det_abrir = clase(Gtk.Button(label='Abrir'), 'suggested-action')
		self.det_abrir.set_valign(Gtk.Align.CENTER)
		self.det_abrir.connect('clicked', lambda *a: self.abrir_seleccion())
		caja.pack_end(self.det_abrir, False, False, 0)
		return marco

	# ---------- navegación ----------
	def ir(self, lugar, historial=True):
		lugar = self.normalizar(lugar)
		if historial:
			self.historia = self.historia[:self.pos + 1] + [lugar]
			self.pos = len(self.historia) - 1
		self.lugar = lugar
		self.buscador.set_text('')
		self.generacion += 1
		if self.vigilante:
			self.vigilante.cancel()
			self.vigilante = None
		self.b_vaciar.set_visible(lugar == 'trash:///')
		if lugar == 'equipo':
			self.pintar_equipo()
		elif lugar == 'inicio':
			self.pintar_inicio()
		elif lugar == 'galeria':
			self.cargar_galeria()
		else:
			self.cargar(Gio.File.new_for_uri(lugar))
		self.pintar_migas()
		self.marcar_lateral()
		self.b_atras.set_sensitive(self.pos > 0)
		self.b_adelante.set_sensitive(self.pos < len(self.historia) - 1)
		self.b_arriba.set_sensitive(lugar not in ESPECIALES and Gio.File.new_for_uri(lugar).get_parent() is not None)
		nombre = ESPECIALES[lugar][0] if lugar in ESPECIALES else self.nombre_lugar(lugar)
		self.set_title(nombre)
		self.buscador.set_placeholder_text(f'Buscar en {nombre}')

	def normalizar(self, lugar):
		if not lugar or lugar in ESPECIALES:
			return lugar or 'inicio'
		if '://' not in lugar:
			return Gio.File.new_for_path(os.path.abspath(os.path.expanduser(lugar))).get_uri()
		return lugar

	def nombre_lugar(self, uri):
		f = Gio.File.new_for_uri(uri)
		if uri == 'trash:///':
			return 'Papelera'
		if uri.startswith('network:'):
			return 'Red'
		if f.get_path() == '/':
			return 'Disco local (/)'
		if f.get_path() == GLib.get_home_dir():
			return GLib.get_user_name()
		try:
			return f.query_info('standard::display-name', Gio.FileQueryInfoFlags.NONE, None).get_display_name()
		except GLib.Error:
			return f.get_basename() or uri

	def atras(self):
		if self.pos > 0:
			self.pos -= 1
			self.ir(self.historia[self.pos], False)

	def adelante(self):
		if self.pos < len(self.historia) - 1:
			self.pos += 1
			self.ir(self.historia[self.pos], False)

	def arriba(self):
		if self.lugar in ESPECIALES:
			return
		padre = Gio.File.new_for_uri(self.lugar).get_parent()
		if padre:
			self.ir(padre.get_uri())

	def pintar_migas(self):
		for hijo in self.migas.get_children():
			self.migas.remove(hijo)
		tramos = []
		if self.lugar in ESPECIALES:
			nombre, icono_n = ESPECIALES[self.lugar]
			tramos = [(nombre, self.lugar)]
		elif self.lugar.startswith('file://'):
			ruta = Gio.File.new_for_uri(self.lugar).get_path()
			casa = GLib.get_home_dir()
			if ruta == casa or ruta.startswith(casa + '/'):
				icono_n, base, partes = 'user-home', casa, [p for p in ruta[len(casa):].split('/') if p]
				tramos = [(GLib.get_user_name(), Gio.File.new_for_path(casa).get_uri())]
			else:
				icono_n, base, partes = 'drive-harddisk', '/', [p for p in ruta.split('/') if p]
				tramos = [('Este equipo', 'equipo'), ('Disco local (/)', 'file:///')]
			acumulado = base
			for p in partes:
				acumulado = os.path.join(acumulado, p)
				tramos.append((GLib.filename_display_name(p), Gio.File.new_for_path(acumulado).get_uri()))
		else:
			icono_n = 'user-trash' if self.lugar.startswith('trash') else 'folder-remote'
			tramos = [(self.nombre_lugar(self.lugar), self.lugar)]
		self.migas.pack_start(Gtk.Image.new_from_icon_name(icono_n, Gtk.IconSize.MENU), False, False, 4)
		for i, (texto, destino) in enumerate(tramos):
			if i:
				self.migas.pack_start(etiqueta('›', 'm-tenue'), False, False, 0)
			b = clase(Gtk.Button(label=texto), 'm-plano')
			if i == len(tramos) - 1:
				clase(b.get_child(), 'm-fuerte')
			b.connect('clicked', lambda _b, d=destino: self.ir(d))
			self.migas.pack_start(b, False, False, 0)
		self.migas.show_all()
		self.pila_ruta.set_visible_child_name('migas')

	def editar_ruta(self):
		if self.lugar in ESPECIALES:
			return
		f = Gio.File.new_for_uri(self.lugar)
		self.entrada_ruta.set_text(f.get_path() or self.lugar)
		self.pila_ruta.set_visible_child_name('entrada')
		self.entrada_ruta.grab_focus()

	def ruta_escrita(self, entrada):
		texto = entrada.get_text().strip()
		if texto:
			self.ir(texto)

	def marcar_lateral(self):
		for fila in self.lista_lateral.get_children():
			if getattr(fila, 'destino', None) == self.lugar:
				self.lista_lateral.select_row(fila)
				return
		self.lista_lateral.unselect_all()

	# ---------- contenido ----------
	def cargar(self, gfile):
		self.modelo.clear()
		self.pila.set_visible_child_name(self.vista)
		try:
			enum = gfile.enumerate_children(ATRIB, Gio.FileQueryInfoFlags.NONE, None)
		except GLib.Error as e:
			self.mensaje_vacio(f'No se puede abrir esta carpeta. {e.message}')
			return
		for info in enum:
			self.anadir(gfile, info)
		enum.close(None)
		self.ordenar()
		self.cargar_miniaturas(self.generacion)
		try:
			self.vigilante = gfile.monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
			self.vigilante.connect('changed', self.cambio_en_disco)
		except GLib.Error:
			self.vigilante = None
		self.pintar_detalles()

	def anadir(self, padre, info):
		nombre = info.get_name()
		destino = info.get_attribute_string('standard::target-uri')
		hijo = Gio.File.new_for_uri(destino) if destino else padre.get_child(nombre)
		es_dir = info.get_file_type() in (Gio.FileType.DIRECTORY, Gio.FileType.MOUNTABLE, Gio.FileType.SHORTCUT)
		tipo = info.get_content_type() or ''
		modificado = info.get_attribute_uint64('time::modified')
		tamano = -1 if es_dir else info.get_size()
		visible = info.get_display_name()
		# la clave de orden lleva delante un punto si el archivo está oculto, para filtrarlo después
		orden = ('.' if info.get_is_hidden() or info.get_is_backup() else '') + ('0' if es_dir else '1') + GLib.utf8_collate_key_for_filename(visible, -1)
		self.modelo.append([pixbuf(info.get_icon(), 48), visible, hijo.get_uri(), es_dir, orden,
							tamano, modificado, tipo, Gio.content_type_get_description(tipo) if tipo else '',
							'' if es_dir else tam(tamano), fecha(modificado), pixbuf(info.get_icon(), 20)])

	def ordenar(self):
		self.modelo.set_sort_column_id(C_ORDEN, Gtk.SortType.ASCENDING)

	def visible(self, modelo, it, _datos):
		if not self.ocultos and modelo[it][C_ORDEN].startswith('.'):
			return False
		texto = self.buscador.get_text().strip().lower() if hasattr(self, 'buscador') else ''
		return not texto or texto in (modelo[it][C_NOMBRE] or '').lower()

	def filtrar(self):
		if self.lugar in ('equipo', 'inicio'):
			return
		self.filtrado.refilter()
		self.pintar_detalles()

	def poner_ocultos(self, activo):
		self.ocultos = activo
		self.filtrado.refilter()

	def cambiar_vista(self, vista):
		self.vista = vista
		if self.lugar not in ('equipo', 'inicio'):
			self.pila.set_visible_child_name(vista)

	def cargar_miniaturas(self, generacion):
		"""Miniaturas de las fotos, poco a poco para no congelar la ventana."""
		pendientes = [Gtk.TreeRowReference.new(self.modelo, fila.path) for fila in self.modelo if fila[C_TIPO] in MESES_IMG and 0 < fila[C_TAM] < 25_000_000]

		def siguiente():
			if generacion != self.generacion or not pendientes:
				return False
			ref = pendientes.pop(0)
			if ref.valid():
				fila = self.modelo[ref.get_path()]
				try:
					ruta = Gio.File.new_for_uri(fila[C_URI]).get_path()
					fila[C_PIX] = GdkPixbuf.Pixbuf.new_from_file_at_scale(ruta, 72, 54, True)
				except GLib.Error:
					pass
			return True
		GLib.idle_add(siguiente)

	def cambio_en_disco(self, *_a):
		if getattr(self, '_recarga', None):
			return
		def recargar():
			self._recarga = None
			if self.lugar not in ESPECIALES:
				self.ir(self.lugar, historial=False)
			return False
		self._recarga = GLib.timeout_add(400, recargar)

	def mensaje_vacio(self, texto):
		self.limpiar_especial()
		self.caja_especial.pack_start(etiqueta(texto, 'm-tenue', xalign=0.5), False, False, 40)
		self.caja_especial.show_all()
		self.pila.set_visible_child_name('especial')

	def limpiar_especial(self):
		for hijo in self.caja_especial.get_children():
			self.caja_especial.remove(hijo)

	def titulo_seccion(self, texto):
		caja = Gtk.Box(spacing=6, margin_top=6, margin_bottom=4)
		caja.pack_start(Gtk.Image.new_from_icon_name('pan-down-symbolic', Gtk.IconSize.MENU), False, False, 0)
		caja.pack_start(etiqueta(texto, 'm-fuerte'), False, False, 0)
		return caja

	def pintar_equipo(self):
		self.modelo.clear()
		self.limpiar_especial()
		self.caja_especial.pack_start(self.titulo_seccion('Dispositivos y unidades'), False, False, 0)
		rejilla = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3, min_children_per_line=1, column_spacing=6, row_spacing=6, homogeneous=True)
		unidades = [('Disco local (/)', 'drive-harddisk', Gio.File.new_for_path('/'), None, None)]
		for montaje in self.monitor_vol.get_mounts():
			if not montaje.is_shadowed() and montaje.get_root().get_path() not in ('/', None):
				unidades.append((montaje.get_name(), None, montaje.get_root(), montaje.get_icon(), None))
		for volumen in self.monitor_vol.get_volumes():
			if volumen.get_mount() is None:
				unidades.append((volumen.get_name(), None, None, volumen.get_icon(), volumen))
		for nombre, icono_n, raiz, gicon, volumen in unidades:
			rejilla.add(self.baldosa_unidad(nombre, icono_n, raiz, gicon, volumen))
		self.caja_especial.pack_start(rejilla, False, False, 0)
		self.caja_especial.show_all()
		self.pila.set_visible_child_name('especial')
		self.det_icono.set_from_icon_name('computer', Gtk.IconSize.DIALOG)
		self.det_icono.set_pixel_size(40)
		self.det_nombre.set_text('Este equipo')
		self.det_linea1.set_text(f'{len(unidades)} dispositivos y unidades')
		self.det_linea2.set_text('')
		self.det_abrir.hide()

	def montar(self, volumen):
		def hecho(vol, resultado):
			try:
				vol.mount_finish(resultado)
				montaje = vol.get_mount()
				if montaje:
					self.ir(montaje.get_root().get_uri())
			except GLib.Error as e:
				self.aviso('No se ha podido abrir la unidad.', e.message)
		volumen.mount(Gio.MountMountFlags.NONE, Gtk.MountOperation(parent=self), None, hecho)

	def baldosa_unidad(self, nombre, icono_n, raiz, gicon, volumen=None):
		boton = clase(Gtk.Button(), 'm-plano', 'm-baldosa')
		caja = Gtk.Box(spacing=12)
		img = Gtk.Image.new_from_gicon(gicon, Gtk.IconSize.DIALOG) if gicon else Gtk.Image.new_from_icon_name(icono_n, Gtk.IconSize.DIALOG)
		img.set_pixel_size(44)
		caja.pack_start(img, False, False, 0)
		datos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
		datos.pack_start(etiqueta(nombre, elipsis=True), False, False, 0)
		texto = 'Sin montar'
		if raiz is not None:
			try:
				info = raiz.query_filesystem_info('filesystem::size,filesystem::free', None)
				total, libre = info.get_attribute_uint64('filesystem::size'), info.get_attribute_uint64('filesystem::free')
				if total:
					barra = clase(Gtk.LevelBar(min_value=0, max_value=1, value=1 - libre / total), 'm-uso')
					for o in (Gtk.LEVEL_BAR_OFFSET_LOW, Gtk.LEVEL_BAR_OFFSET_HIGH, 'full'):
						barra.remove_offset_value(o)
					if libre / total < 0.1:
						clase(barra, 'm-lleno')
					barra.set_size_request(190, -1)
					datos.pack_start(barra, False, False, 0)
					texto = f'{gb(libre)} GB disponibles de {gb(total)} GB'
			except GLib.Error:
				texto = ''
		datos.pack_start(etiqueta(texto, 'm-pie', 'm-tenue'), False, False, 0)
		caja.pack_start(datos, True, True, 0)
		boton.add(caja)
		boton.set_size_request(280, -1)
		boton.connect('clicked', lambda *a: self.ir(raiz.get_uri()) if raiz is not None else (volumen and self.montar(volumen)))
		boton.connect('button-press-event', lambda _b, ev: ev.button == 3 and self.menu_unidad(ev, raiz, volumen))
		return boton

	def montaje_de(self, raiz):
		if raiz is None or raiz.get_path() == '/':
			return None
		try:
			return raiz.find_enclosing_mount(None)
		except GLib.Error:
			return None

	def menu_unidad(self, evento, raiz, volumen):
		"""Clic derecho en un disco de Este equipo: Abrir, Expulsar, Propiedades (como en Windows)."""
		montaje = self.montaje_de(raiz)
		if raiz is None:
			opciones = [('Abrir', lambda: self.montar(volumen))]
			if volumen is not None and volumen.can_eject():
				opciones += [(None, None), ('Expulsar', lambda: volumen.eject_with_operation(
					Gio.MountUnmountFlags.NONE, Gtk.MountOperation(parent=self), None, None))]
		else:
			opciones = [('Abrir', lambda: self.ir(raiz.get_uri())),
						('Abrir en ventana nueva', lambda: self.get_application().nueva_ventana(raiz.get_uri())),
						('Abrir en Terminal', lambda: self.abrir_terminal(raiz))]
			if montaje is not None and (montaje.can_eject() or montaje.can_unmount()):
				opciones += [(None, None), ('Expulsar', lambda: propiedades.expulsar(montaje, self))]
			opciones += [(None, None), ('Propiedades', lambda: propiedades.mostrar([raiz], self, self.get_application(), montaje))]
		self.sacar_menu(opciones, evento)
		return True

	def clic_derecho_lateral(self, _lista, evento):
		if evento.button != 3:
			return False
		fila = self.lista_lateral.get_row_at_y(int(evento.y))
		if fila is None or not fila.destino:
			return False
		destino = fila.destino
		opciones = [('Abrir', lambda: self.ir(destino)),
					('Abrir en ventana nueva', lambda: self.get_application().nueva_ventana(destino))]
		montaje = getattr(fila, 'montaje', None)
		if montaje is not None:
			opciones += [(None, None), ('Expulsar', lambda: propiedades.expulsar(montaje, self))]
		if destino == 'equipo':   # en Windows, «Este equipo › Propiedades» lleva a Sistema
			opciones += [(None, None), ('Propiedades', lambda: ejecutar('mandarin-panel', 'sistema'))]
		elif '://' in destino and Gio.File.new_for_uri(destino).get_path():
			opciones += [(None, None), ('Propiedades', lambda: propiedades.mostrar(
				[Gio.File.new_for_uri(destino)], self, self.get_application(), montaje))]
		self.sacar_menu(opciones, evento)
		return True

	def cambio_unidades(self):
		self.pintar_lateral()
		if self.lugar == 'equipo':
			self.pintar_equipo()
		elif self.lugar and '://' in self.lugar and not Gio.File.new_for_uri(self.lugar).query_exists(None):
			self.ir('equipo')   # la unidad donde estabas se ha expulsado

	def pintar_inicio(self):
		self.modelo.clear()
		self.limpiar_especial()
		self.caja_especial.pack_start(self.titulo_seccion('Acceso rápido'), False, False, 0)
		rejilla = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=4, min_children_per_line=2, column_spacing=4, row_spacing=4, homogeneous=True)
		for clave, nombre, _, icono_n in CARPETAS:
			b = clase(Gtk.Button(), 'm-plano', 'm-baldosa')
			caja = Gtk.Box(spacing=10)
			caja.pack_start(icono(icono_n, 36), False, False, 0)
			textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
			textos.pack_start(etiqueta(nombre), False, False, 0)
			textos.pack_start(etiqueta('Anclada', 'm-pie', 'm-tenue'), False, False, 0)
			caja.pack_start(textos, True, True, 0)
			b.add(caja)
			uri = Gio.File.new_for_path(carpeta(clave)).get_uri()
			b.connect('clicked', lambda _b, u=uri: self.ir(u))
			rejilla.add(b)
		self.caja_especial.pack_start(rejilla, False, False, 0)
		self.caja_especial.pack_start(self.titulo_seccion('Recientes'), False, False, 8)
		lista = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
		cabecera = Gtk.Box(spacing=10, margin_start=8, margin_end=8)
		for texto, ancho, expande in (('Nombre', 300, True), ('Fecha', 130, False), ('Ubicación', 160, False)):
			lbl = etiqueta(texto, 'm-pie', 'm-tenue')
			lbl.set_size_request(ancho, -1)
			cabecera.pack_start(lbl, expande, expande, 0)
		self.caja_especial.pack_start(cabecera, False, False, 0)
		elementos = [e for e in Gtk.RecentManager.get_default().get_items() if e.is_local() and e.exists()]
		elementos.sort(key=lambda e: e.get_modified(), reverse=True)
		for e in elementos[:15]:
			fila = Gtk.ListBoxRow()
			caja = Gtk.Box(spacing=10, margin=4, margin_start=8, margin_end=8)
			img = Gtk.Image.new_from_gicon(e.get_gicon(), Gtk.IconSize.MENU)
			img.set_pixel_size(20)
			caja.pack_start(img, False, False, 0)
			nombre = etiqueta(e.get_display_name(), elipsis=True)
			nombre.set_size_request(270, -1)
			caja.pack_start(nombre, True, True, 0)
			f = etiqueta(fecha(e.get_modified()), 'm-tenue')
			f.set_size_request(130, -1)
			caja.pack_start(f, False, False, 0)
			ruta = GLib.filename_from_uri(e.get_uri())[0]
			ubic = etiqueta(os.path.basename(os.path.dirname(ruta)), 'm-tenue', elipsis=True)
			ubic.set_size_request(160, -1)
			caja.pack_start(ubic, False, False, 0)
			fila.add(caja)
			fila.uri = e.get_uri()
			lista.add(fila)
		if not elementos:
			fila = Gtk.ListBoxRow(activatable=False)
			fila.add(etiqueta('Aquí aparecerán los archivos que abras.', 'm-tenue', xalign=0.0))
			lista.add(fila)
		lista.connect('row-activated', lambda _l, fila: hasattr(fila, 'uri') and abrir_archivo(Gio.File.new_for_uri(fila.uri), self))
		self.caja_especial.pack_start(lista, False, False, 0)
		self.caja_especial.show_all()
		self.pila.set_visible_child_name('especial')
		self.det_icono.set_from_icon_name('user-home', Gtk.IconSize.DIALOG)
		self.det_icono.set_pixel_size(40)
		self.det_nombre.set_text('Inicio')
		self.det_linea1.set_text('Acceso rápido y archivos recientes')
		self.det_linea2.set_text('')
		self.det_abrir.hide()

	def cargar_galeria(self):
		self.modelo.clear()
		self.pila.set_visible_child_name(self.vista)
		raiz = carpeta('imagenes')
		for dirpath, dirnames, ficheros in os.walk(raiz):
			if dirpath.count(os.sep) - raiz.count(os.sep) >= 3:
				dirnames[:] = []
			dirnames[:] = [d for d in dirnames if not d.startswith('.')]
			for nombre in sorted(ficheros):
				f = Gio.File.new_for_path(os.path.join(dirpath, nombre))
				try:
					info = f.query_info(ATRIB, Gio.FileQueryInfoFlags.NONE, None)
				except GLib.Error:
					continue
				if (info.get_content_type() or '').startswith('image/'):
					self.anadir(f.get_parent(), info)
		self.ordenar()
		self.cargar_miniaturas(self.generacion)
		self.pintar_detalles()

	# ---------- selección y detalles ----------
	def seleccion(self):
		"""Lista de (Gio.File, fila del modelo) seleccionados en la vista activa."""
		filas = []
		if self.pila.get_visible_child_name() == 'detalles':
			modelo, rutas = self.arbol.get_selection().get_selected_rows()
			rutas = [modelo.convert_path_to_child_path(r) for r in rutas]
		elif self.pila.get_visible_child_name() == 'iconos':
			rutas = self.iconos.get_selected_items()
		else:
			return []
		for r in rutas:
			fila = self.filtrado[r]
			filas.append((Gio.File.new_for_uri(fila[C_URI]), fila))
		return filas

	def pintar_detalles(self):
		if self.lugar in ('equipo', 'inicio'):
			return
		sel = self.seleccion()
		self.det_abrir.show()
		if len(sel) == 1:
			_f, fila = sel[0]
			self.det_icono.set_from_pixbuf(fila[C_PIX].scale_simple(40, 40 if fila[C_PIX].get_width() == fila[C_PIX].get_height() else 30, GdkPixbuf.InterpType.BILINEAR) if fila[C_PIX] else None)
			self.det_nombre.set_text(fila[C_NOMBRE])
			partes = [fila[C_DESC]] + ([fila[C_TAMTXT]] if fila[C_TAMTXT] else []) + ([fila[C_FECHATXT]] if fila[C_FECHATXT] else [])
			self.det_linea1.set_text(' · '.join(p for p in partes if p))
			self.det_linea2.set_markup(self.se_abre_con(fila))
		elif len(sel) > 1:
			self.det_icono.set_from_icon_name('edit-copy', Gtk.IconSize.DIALOG)
			self.det_icono.set_pixel_size(40)
			self.det_nombre.set_text(f'{len(sel)} elementos seleccionados')
			total = sum(max(0, fila[C_TAM]) for _f, fila in sel)
			self.det_linea1.set_text(tam(total) if total else '')
			self.det_linea2.set_text('')
		else:
			n = len(self.filtrado)
			self.det_icono.set_from_icon_name('folder', Gtk.IconSize.DIALOG)
			self.det_icono.set_pixel_size(40)
			self.det_nombre.set_text(ESPECIALES[self.lugar][0] if self.lugar in ESPECIALES else self.nombre_lugar(self.lugar))
			self.det_linea1.set_text('1 elemento' if n == 1 else f'{n} elementos')
			self.det_linea2.set_text('')
			self.det_abrir.hide()

	def se_abre_con(self, fila):
		if fila[C_DIR]:
			return ''
		if es_programa_windows(fila[C_NOMBRE]):
			motor = 'Proton, porque la gráfica tiene Vulkan' if modo() == 'completo' else 'Wine, automáticamente'
			return f'Se abre con: <span weight="500">{motor}</span>'
		app = Gio.AppInfo.get_default_for_type(fila[C_TIPO], False) if fila[C_TIPO] else None
		if app:
			return f'Se abre con: <span weight="500">{GLib.markup_escape_text(app.get_display_name())}</span>'
		return 'Sin programa asociado'

	# ---------- acciones ----------
	def abrir_ruta_modelo(self, ruta):
		fila = self.filtrado[ruta]
		if fila[C_DIR]:
			self.ir(fila[C_URI])
		else:
			abrir_archivo(Gio.File.new_for_uri(fila[C_URI]), self)

	def abrir_seleccion(self):
		sel = self.seleccion()
		for f, fila in sel[:10]:
			if fila[C_DIR]:
				self.ir(fila[C_URI])
				return
			abrir_archivo(f, self)

	def copiar(self, cortar):
		archivos = [f for f, _ in self.seleccion()]
		if archivos:
			self.portapapeles = ('cortar' if cortar else 'copiar', archivos)

	def pegar(self):
		if self.lugar not in ESPECIALES:
			self.pegar_en(Gio.File.new_for_uri(self.lugar))

	def pegar_en(self, destino):
		"""Pega lo copiado o cortado en una carpeta (la abierta, o la que tiene el clic derecho)."""
		operacion, archivos = self.portapapeles
		if not archivos:
			return
		self.det_linea2.set_text(f'{"Moviendo" if operacion == "cortar" else "Copiando"} {len(archivos)} elementos…')

		def trabajo():
			errores = 0
			for origen in archivos:
				final = self.nombre_libre(destino, origen.get_basename())
				try:
					if operacion == 'cortar':
						origen.move(final, Gio.FileCopyFlags.NONE, None, None, None)
					elif origen.query_file_type(Gio.FileQueryInfoFlags.NONE, None) == Gio.FileType.DIRECTORY:
						self.copiar_carpeta(origen, final)
					else:
						origen.copy(final, Gio.FileCopyFlags.NONE, None, None, None)
				except GLib.Error:
					errores += 1
			GLib.idle_add(self.fin_pegar, errores)
		if operacion == 'cortar':
			self.portapapeles = (None, [])
		threading.Thread(target=trabajo, daemon=True).start()

	def copiar_carpeta(self, origen, destino):
		destino.make_directory_with_parents(None)
		for info in origen.enumerate_children('standard::name,standard::type', Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None):
			hijo = origen.get_child(info.get_name())
			if info.get_file_type() == Gio.FileType.DIRECTORY:
				self.copiar_carpeta(hijo, destino.get_child(info.get_name()))
			else:
				hijo.copy(destino.get_child(info.get_name()), Gio.FileCopyFlags.NOFOLLOW_SYMLINKS, None, None, None)

	def fin_pegar(self, errores):
		self.ir(self.lugar, historial=False)
		if errores:
			self.aviso(f'{errores} elementos no se han podido copiar.', 'Comprueba que tienes permiso para escribir aquí.')
		return False

	def nombre_libre(self, carpeta_dest, nombre):
		final = carpeta_dest.get_child(nombre)
		if not final.query_exists(None):
			return final
		base, ext = os.path.splitext(nombre)
		n = 1
		while True:
			sufijo = ' (copia)' if n == 1 else f' (copia {n})'
			final = carpeta_dest.get_child(f'{base}{sufijo}{ext}')
			if not final.query_exists(None):
				return final
			n += 1

	def nueva_carpeta(self):
		if self.lugar in ESPECIALES:
			return
		destino = self.nombre_libre(Gio.File.new_for_uri(self.lugar), 'Nueva carpeta')
		try:
			destino.make_directory(None)
		except GLib.Error as e:
			self.aviso('No se ha podido crear la carpeta.', e.message)
			return
		self.ir(self.lugar, historial=False)
		self.renombrar_archivo(destino)

	def renombrar(self):
		sel = self.seleccion()
		if len(sel) == 1:
			self.renombrar_archivo(sel[0][0])

	def renombrar_archivo(self, f):
		dialogo = Gtk.Dialog(title='Cambiar nombre', transient_for=self, modal=True)
		dialogo.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Cambiar nombre', Gtk.ResponseType.OK)
		dialogo.set_default_response(Gtk.ResponseType.OK)
		clase(dialogo.get_widget_for_response(Gtk.ResponseType.OK), 'suggested-action')
		entrada = Gtk.Entry(text=f.get_basename(), activates_default=True, width_chars=40)
		caja = dialogo.get_content_area()
		caja.set_spacing(8)
		caja.set_border_width(14)
		caja.add(etiqueta('Nombre nuevo'))
		caja.add(entrada)
		dialogo.show_all()
		base, _ext = os.path.splitext(f.get_basename())
		entrada.select_region(0, len(base) if not f.query_file_type(Gio.FileQueryInfoFlags.NONE, None) == Gio.FileType.DIRECTORY else -1)
		if dialogo.run() == Gtk.ResponseType.OK:
			nuevo = entrada.get_text().strip()
			if nuevo and nuevo != f.get_basename():
				try:
					f.set_display_name(nuevo, None)
				except GLib.Error as e:
					self.aviso('No se ha podido cambiar el nombre.', e.message)
		dialogo.destroy()

	def eliminar(self, definitivo=False):
		archivos = [f for f, _ in self.seleccion()]
		if not archivos:
			return
		if definitivo or self.lugar == 'trash:///':
			if not self.confirmar(f'¿Eliminar {"este elemento" if len(archivos) == 1 else f"estos {len(archivos)} elementos"} para siempre?',
								  'No se podrán recuperar desde la Papelera.', 'Eliminar'):
				return
			for f in archivos:
				try:
					f.delete(None)
				except GLib.Error:
					pass
		else:
			for f in archivos:
				try:
					f.trash(None)
				except GLib.Error as e:
					self.aviso('No se ha podido mover a la Papelera.', e.message)
					break
		self.ir(self.lugar, historial=False)

	def vaciar_papelera(self):
		if not self.confirmar('¿Vaciar la Papelera?', 'Todo lo que hay dentro se eliminará para siempre.', 'Vaciar papelera'):
			return
		papelera = Gio.File.new_for_uri('trash:///')
		for info in papelera.enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, None):
			try:
				papelera.get_child(info.get_name()).delete(None)
			except GLib.Error:
				pass
		self.ir(self.lugar, historial=False)

	def seleccionar_todo(self):
		if self.pila.get_visible_child_name() == 'iconos':
			self.iconos.select_all()
		elif self.pila.get_visible_child_name() == 'detalles':
			self.arbol.get_selection().select_all()

	def confirmar(self, titulo, texto, accion):
		d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION, buttons=Gtk.ButtonsType.NONE, text=titulo)
		d.format_secondary_text(texto)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, accion, Gtk.ResponseType.OK)
		clase(d.get_widget_for_response(Gtk.ResponseType.OK), 'destructive-action')
		r = d.run()
		d.destroy()
		return r == Gtk.ResponseType.OK

	def aviso(self, titulo, texto):
		d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.WARNING, buttons=Gtk.ButtonsType.OK, text=titulo)
		d.format_secondary_text(texto)
		d.run()
		d.destroy()

	def clic_derecho(self, vista, evento):
		if evento.button != 3:
			return False
		if vista is self.iconos:
			ruta = self.iconos.get_path_at_pos(int(evento.x), int(evento.y))
			if ruta and not self.iconos.path_is_selected(ruta):
				self.iconos.unselect_all()
				self.iconos.select_path(ruta)
			elif not ruta:
				self.iconos.unselect_all()
		else:
			res = self.arbol.get_path_at_pos(int(evento.x), int(evento.y))
			if res and not self.arbol.get_selection().path_is_selected(res[0]):
				self.arbol.get_selection().unselect_all()
				self.arbol.get_selection().select_path(res[0])
		sel = self.seleccion()
		pegar = self.pegar if self.portapapeles[1] else None   # None: sale en gris
		if sel:   # el menú de Windows sobre uno o varios archivos
			opciones = [('Abrir', self.abrir_seleccion)]
			if len(sel) == 1 and sel[0][1][C_DIR]:
				uri = sel[0][1][C_URI]
				opciones += [('Abrir en ventana nueva', lambda: self.get_application().nueva_ventana(uri)),
							 ('Abrir en Terminal', lambda: self.abrir_terminal(Gio.File.new_for_uri(uri)))]
			elif len(sel) == 1:
				opciones += [('Abrir con…', self.abrir_con)]
			# comprimidos (como el «Extraer todo…» y «Enviar a › Carpeta comprimida» de Windows), con el Descompresor
			archivos = [s[0] for s in sel if s[0].get_path()]
			extra = []
			if len(archivos) == 1 and (archivos[0].get_basename() or '').lower().endswith(COMPRIMIDOS):
				extra.append(('Extraer aquí', lambda: ejecutar('xarchiver', '-x', archivos[0].get_parent().get_path(),
															 archivos[0].get_path())))
			if archivos:
				extra.append(('Comprimir…', lambda: ejecutar('xarchiver', '-c', *[a.get_path() for a in archivos])))
			if extra:
				opciones += [(None, None)] + extra
			opciones += [(None, None), ('Cortar', lambda: self.copiar(True)), ('Copiar', lambda: self.copiar(False))]
			if len(sel) == 1 and sel[0][1][C_DIR]:
				opciones += [('Pegar', pegar and (lambda: self.pegar_en(Gio.File.new_for_uri(sel[0][1][C_URI]))))]
			opciones += [(None, None), ('Eliminar', self.eliminar), ('Cambiar nombre', self.renombrar if len(sel) == 1 else None),
						 (None, None), ('Copiar ruta de acceso', self.copiar_ruta), ('Propiedades', self.propiedades)]
		else:     # el del fondo de la carpeta
			fuera = self.lugar in ESPECIALES
			opciones = [('Ver', [('Iconos', lambda: self.cambiar_vista_menu('iconos'), self.vista == 'iconos', True),
								 ('Detalles', lambda: self.cambiar_vista_menu('detalles'), self.vista == 'detalles', True),
								 (None, None),
								 ('Archivos ocultos', lambda: self.poner_ocultos(not self.ocultos), self.ocultos)]),
						('Actualizar', lambda: self.ir(self.lugar, False)),
						(None, None), ('Pegar', pegar),
						(None, None), ('Nuevo', [('Carpeta', None if fuera else self.nueva_carpeta),
												 ('Documento de texto', None if fuera else self.nuevo_documento)])]
			if not fuera and Gio.File.new_for_uri(self.lugar).get_path():
				opciones += [(None, None), ('Abrir en Terminal', lambda: self.abrir_terminal(Gio.File.new_for_uri(self.lugar)))]
			opciones += [(None, None), ('Propiedades', self.propiedades)]
		self.sacar_menu(opciones, evento, vista)
		return True

	def construir_menu(self, opciones):
		"""Opciones: (texto, función) — función None sale en gris —, (texto, [submenú]), (None, None) separador,
		o (texto, función, marcada[, redonda]) para las casillas."""
		menu = Gtk.Menu()
		for op in opciones:
			texto, f = op[0], op[1]
			if texto is None:
				menu.append(Gtk.SeparatorMenuItem())
				continue
			if len(op) > 2:
				item = Gtk.CheckMenuItem(label=texto, active=op[2], draw_as_radio=len(op) > 3 and op[3])
			else:
				item = Gtk.MenuItem(label=texto)
			if isinstance(f, list):
				item.set_submenu(self.construir_menu(f))
			elif f is None:
				item.set_sensitive(False)
			else:
				item.connect('activate', lambda _i, f=f: f())
			menu.append(item)
		return menu

	def sacar_menu(self, opciones, evento, widget=None):
		menu = self.construir_menu(opciones)
		menu.show_all()
		menu.attach_to_widget(widget or self, None)
		menu.popup_at_pointer(evento)

	def cambiar_vista_menu(self, vista):
		if vista != self.vista:
			self.cambiar_vista(vista)

	def propiedades(self):
		sel = [f for f, _ in self.seleccion()]
		if sel:
			propiedades.mostrar(sel, self, self.get_application())
		elif self.lugar == 'equipo':
			ejecutar('mandarin-panel', 'sistema')
		elif self.lugar and self.lugar not in ESPECIALES:
			propiedades.mostrar([Gio.File.new_for_uri(self.lugar)], self, self.get_application())

	def copiar_ruta(self):
		rutas = [f.get_path() or f.get_uri() for f, _ in self.seleccion()]
		if rutas:
			Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text('\n'.join(rutas), -1)

	def abrir_terminal(self, gfile):
		if gfile.get_path():
			ejecutar('xfce4-terminal', f'--working-directory={gfile.get_path()}')

	def nuevo_documento(self):
		if self.lugar in ESPECIALES:
			return
		destino = self.nombre_libre(Gio.File.new_for_uri(self.lugar), 'Documento de texto nuevo.txt')
		try:
			destino.create(Gio.FileCreateFlags.NONE, None).close(None)
		except GLib.Error as e:
			self.aviso('No se ha podido crear el documento.', e.message)
			return
		self.ir(self.lugar, historial=False)
		self.renombrar_archivo(destino)

	def abrir_con(self):
		sel = self.seleccion()
		if len(sel) != 1:
			return
		d = Gtk.AppChooserDialog.new(self, Gtk.DialogFlags.MODAL, sel[0][0])
		if d.run() == Gtk.ResponseType.OK and d.get_app_info():
			d.get_app_info().launch([sel[0][0]], None)
		d.destroy()

	def tecla(self, _v, ev):
		ctrl = ev.state & Gdk.ModifierType.CONTROL_MASK
		alt = ev.state & Gdk.ModifierType.MOD1_MASK
		k = Gdk.keyval_name(ev.keyval)
		if self.entrada_ruta.has_focus() or (self.buscador.has_focus() and k not in ('Escape',)):
			if k == 'Escape':
				self.pila_ruta.set_visible_child_name('migas')
			return False
		acciones = {
			(False, True, 'Left'): self.atras, (False, True, 'Right'): self.adelante, (False, True, 'Up'): self.arriba,
			(False, False, 'BackSpace'): self.atras, (False, False, 'F2'): self.renombrar, (False, False, 'Delete'): self.eliminar,
			(False, False, 'F5'): lambda: self.ir(self.lugar, False), (True, False, 'c'): lambda: self.copiar(False),
			(True, False, 'x'): lambda: self.copiar(True), (True, False, 'v'): self.pegar, (True, False, 'a'): self.seleccionar_todo,
			(True, False, 'l'): self.editar_ruta, (True, False, 'f'): self.buscador.grab_focus, (True, False, 'h'): lambda: self.poner_ocultos(not self.ocultos),
			(True, False, 'n'): lambda: self.get_application().nueva_ventana(self.lugar),
			(False, True, 'Return'): self.propiedades, (False, True, 'KP_Enter'): self.propiedades,
		}
		if k == 'Delete' and ev.state & Gdk.ModifierType.SHIFT_MASK:
			self.eliminar(definitivo=True)
			return True
		if ctrl and ev.state & Gdk.ModifierType.SHIFT_MASK and k in ('N', 'n'):
			self.nueva_carpeta()
			return True
		f = acciones.get((bool(ctrl), bool(alt), k))
		if f:
			f()
			return True
		return False


DBUS_XML = """
<node>
  <interface name="org.xfce.FileManager">
    <method name="DisplayFolder"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="DisplayFolderAndSelect"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="DisplayFileProperties"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="Launch"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <!-- lo que usa el escritorio de XFCE (xfdesktop); mismas firmas que Thunar -->
    <method name="Execute"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="LaunchFiles"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="DisplayChooserDialog"><arg type="s" direction="in"/><arg type="b" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="DisplayPreferencesDialog"><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="RenameFile"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="CopyTo"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="MoveTo"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="CopyInto"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="MoveInto"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="LinkInto"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="UnlinkFiles"><arg type="s" direction="in"/><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="CreateFile"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="CreateFileFromTemplate"><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
  </interface>
  <interface name="org.xfce.Trash">
    <method name="DisplayTrash"><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="EmptyTrash"><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="MoveToTrash"><arg type="as" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/></method>
    <method name="QueryTrash"><arg type="b" direction="out"/></method>
    <signal name="TrashChanged"><arg type="b"/></signal>
  </interface>
  <interface name="org.freedesktop.FileManager1">
    <method name="ShowFolders"><arg type="as" direction="in"/><arg type="s" direction="in"/></method>
    <method name="ShowItems"><arg type="as" direction="in"/><arg type="s" direction="in"/></method>
    <method name="ShowItemProperties"><arg type="as" direction="in"/><arg type="s" direction="in"/></method>
  </interface>
</node>
"""


class Explorador(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Explorador', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css()
		conexion = self.get_dbus_connection()
		if conexion is None:
			return
		nodo = Gio.DBusNodeInfo.new_for_xml(DBUS_XML)
		self.conexion = conexion
		for interfaz, ruta, nombre in ((nodo.interfaces[0], '/org/xfce/FileManager', 'org.xfce.FileManager'),
									   (nodo.interfaces[1], '/org/xfce/FileManager', None),
									   (nodo.interfaces[2], '/org/freedesktop/FileManager1', 'org.freedesktop.FileManager1')):
			try:
				conexion.register_object(ruta, interfaz, self.llamada_dbus, None, None)
				if nombre:
					Gio.bus_own_name_on_connection(conexion, nombre, Gio.BusNameOwnerFlags.REPLACE, None, None)
			except GLib.Error:
				pass

	# ---------- lo que pide el escritorio (xfdesktop) por D-Bus ----------
	@staticmethod
	def archivo(nombre, carpeta=''):
		if '://' in nombre:
			return Gio.File.new_for_uri(nombre)
		return Gio.File.new_for_path(nombre if os.path.isabs(nombre) or not carpeta else os.path.join(carpeta, nombre))

	@staticmethod
	def libre(destino):
		"""Un nombre que no exista en la carpeta de destino: «foto (copia).jpg», «foto (copia 2).jpg»…"""
		if not destino.query_exists(None):
			return destino
		base, ext = os.path.splitext(destino.get_basename())
		for n in range(1, 1000):
			otro = destino.get_parent().get_child(f'{base} (copia{"" if n == 1 else " " + str(n)}){ext}')
			if not otro.query_exists(None):
				return otro
		return destino

	def copiar_todo(self, origen, destino):
		if origen.query_file_type(Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None) == Gio.FileType.DIRECTORY:
			destino.make_directory_with_parents(None)
			for info in origen.enumerate_children('standard::name', Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None):
				self.copiar_todo(origen.get_child(info.get_name()), destino.get_child(info.get_name()))
		else:
			origen.copy(destino, Gio.FileCopyFlags.NOFOLLOW_SYMLINKS, None, None, None)

	def operacion(self, tipo, pares):
		"""Copiar, mover o enlazar en un hilo aparte; si algo falla, se avisa al final."""
		def trabajo():
			fallos = []
			for origen, destino in pares:
				try:
					destino = self.libre(destino) if tipo != 'mover' or destino.query_exists(None) else destino
					if tipo == 'copiar':
						self.copiar_todo(origen, destino)
					elif tipo == 'mover':
						origen.move(destino, Gio.FileCopyFlags.NOFOLLOW_SYMLINKS, None, None, None)
					else:
						destino.make_symbolic_link(origen.get_path() or origen.get_uri(), None)
				except GLib.Error as e:
					fallos.append(f'{origen.get_basename()}: {e.message}')
			if fallos:
				GLib.idle_add(self.aviso, 'No se ha podido terminar la operación', '\n'.join(fallos[:6]))
		self.hold()
		threading.Thread(target=lambda: (trabajo(), GLib.idle_add(self.release)), daemon=True).start()

	def aviso(self, titulo, texto, pregunta=False):
		d = Gtk.MessageDialog(message_type=Gtk.MessageType.QUESTION if pregunta else Gtk.MessageType.WARNING,
							  buttons=Gtk.ButtonsType.NONE, text=titulo)
		d.format_secondary_text(texto)
		if pregunta:
			d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Eliminar', Gtk.ResponseType.OK)
		else:
			d.add_buttons('Cerrar', Gtk.ResponseType.CLOSE)
		d.set_keep_above(True)
		r = d.run()
		d.destroy()
		return r == Gtk.ResponseType.OK

	def renombrar_suelto(self, f):
		d = Gtk.Dialog(title='Cambiar nombre', modal=True)
		d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Cambiar nombre', Gtk.ResponseType.OK)
		d.set_default_response(Gtk.ResponseType.OK)
		entrada = Gtk.Entry(text=f.get_basename(), activates_default=True, margin=12, width_chars=40)
		d.get_content_area().add(entrada)
		d.show_all()
		base, _ext = os.path.splitext(f.get_basename())
		entrada.select_region(0, len(base))
		if d.run() == Gtk.ResponseType.OK and entrada.get_text().strip() and entrada.get_text() != f.get_basename():
			try:
				f.set_display_name(entrada.get_text().strip(), None)
			except GLib.Error as e:
				self.aviso('No se ha podido cambiar el nombre', e.message)
		d.destroy()

	def papelera_llena(self):
		try:
			info = Gio.File.new_for_uri('trash:///').query_info('trash::item-count', Gio.FileQueryInfoFlags.NONE, None)
			return info.get_attribute_uint32('trash::item-count') > 0
		except GLib.Error:
			return False

	def aviso_papelera(self):
		try:
			self.conexion.emit_signal(None, '/org/xfce/FileManager', 'org.xfce.Trash', 'TrashChanged',
									  GLib.Variant('(b)', (self.papelera_llena(),)))
		except GLib.Error:
			pass
		return False

	def llamada_dbus(self, _con, _remitente, _ruta, _interfaz, metodo, parametros, invocacion):
		args = parametros.unpack()
		respuesta = None
		try:
			respuesta = self.atender(metodo, args)
		except GLib.Error as e:
			invocacion.return_dbus_error('org.xfce.FileManager.Error', e.message)
			return
		invocacion.return_value(respuesta)

	def atender(self, metodo, args):
		if metodo == 'Execute':   # doble clic en un lanzador o programa del escritorio
			f = self.archivo(args[1], args[0])
			ruta = f.get_path() or ''
			if ruta.endswith('.desktop'):
				app = Gio.DesktopAppInfo.new_from_filename(ruta)
				if app is not None:
					app.launch_uris(list(args[2]), None)
			else:
				abrir_archivo(f)
			return None
		if metodo == 'LaunchFiles':
			for n in args[1]:
				f = self.archivo(n, args[0])
				if f.query_file_type(Gio.FileQueryInfoFlags.NONE, None) == Gio.FileType.DIRECTORY:
					self.nueva_ventana(f.get_uri())
				else:
					abrir_archivo(f)
			return None
		if metodo == 'DisplayChooserDialog':
			f = Gio.File.new_for_uri(args[0])
			d = Gtk.AppChooserDialog.new(None, Gtk.DialogFlags.MODAL, f)
			if d.run() == Gtk.ResponseType.OK and d.get_app_info() and args[1]:
				d.get_app_info().launch([f], None)
			d.destroy()
			return None
		if metodo == 'DisplayPreferencesDialog':
			ejecutar('mandarin-panel', 'apariencia')
			return None
		if metodo == 'RenameFile':
			self.renombrar_suelto(Gio.File.new_for_uri(args[0]))
			return None
		if metodo in ('CopyTo', 'MoveTo'):
			self.operacion('copiar' if metodo == 'CopyTo' else 'mover',
						   [(self.archivo(o, args[0]), self.archivo(d, args[0])) for o, d in zip(args[1], args[2])])
			return None
		if metodo in ('CopyInto', 'MoveInto', 'LinkInto'):
			carpeta = self.archivo(args[2], args[0])
			tipo = {'CopyInto': 'copiar', 'MoveInto': 'mover', 'LinkInto': 'enlazar'}[metodo]
			self.operacion(tipo, [(self.archivo(o, args[0]), carpeta.get_child(self.archivo(o, args[0]).get_basename()))
								  for o in args[1]])
			return None
		if metodo == 'UnlinkFiles':   # «Eliminar» de verdad (no a la papelera): se pregunta antes
			archivos = [self.archivo(n, args[0]) for n in args[1]]
			nombres = ', '.join(f.get_basename() for f in archivos[:3]) + ('…' if len(archivos) > 3 else '')
			if self.aviso(f'¿Eliminar para siempre {nombres}?', 'No irá a la papelera: no se podrá recuperar.', pregunta=True):
				for f in archivos:
					ejecutar('gio', 'remove', '--recursive', f.get_uri())
			return None
		if metodo == 'CreateFile':
			carpeta = Gio.File.new_for_uri(args[0]) if '://' in args[0] else Gio.File.new_for_path(args[0])
			if args[1] == 'inode/directory':
				self.libre(carpeta.get_child('Nueva carpeta')).make_directory(None)
			else:
				self.libre(carpeta.get_child('Documento nuevo')).create(Gio.FileCreateFlags.NONE, None).close(None)
			return None
		if metodo == 'CreateFileFromTemplate':
			carpeta = Gio.File.new_for_uri(args[0]) if '://' in args[0] else Gio.File.new_for_path(args[0])
			plantilla = Gio.File.new_for_uri(args[1])
			self.operacion('copiar', [(plantilla, carpeta.get_child(plantilla.get_basename()))])
			return None
		if metodo == 'DisplayTrash':
			self.nueva_ventana('trash:///')
			return None
		if metodo == 'EmptyTrash':
			if self.aviso('¿Vaciar la papelera?', 'Los archivos de la papelera se eliminarán para siempre.', pregunta=True):
				subprocess.run(['gio', 'trash', '--empty'], check=False)
				GLib.timeout_add(500, self.aviso_papelera)
			return None
		if metodo == 'MoveToTrash':
			for n in args[0]:
				self.archivo(n).trash(None)
			GLib.timeout_add(300, self.aviso_papelera)
			return None
		if metodo == 'QueryTrash':
			return GLib.Variant('(b)', (self.papelera_llena(),))
		self.atender_antiguo(metodo, args)
		return None

	def atender_antiguo(self, metodo, args):
		if metodo in ('DisplayFolder', 'DisplayFolderAndSelect'):
			self.nueva_ventana(args[0])
		elif metodo == 'Launch':
			f = Gio.File.new_for_uri(args[0])
			if f.query_file_type(Gio.FileQueryInfoFlags.NONE, None) == Gio.FileType.DIRECTORY:
				self.nueva_ventana(args[0])
			else:
				abrir_archivo(f)
		elif metodo == 'DisplayFileProperties':   # «Propiedades» en el escritorio
			propiedades.mostrar([self.archivo(args[0])], None, self)
		elif metodo == 'ShowItemProperties':
			propiedades.mostrar([Gio.File.new_for_uri(u) for u in args[0]], None, self)
		elif metodo in ('ShowFolders', 'ShowItems'):
			for uri in args[0][:4]:
				f = Gio.File.new_for_uri(uri)
				self.nueva_ventana(uri if metodo == 'ShowFolders' else (f.get_parent() or f).get_uri())

	def nueva_ventana(self, lugar):
		ventana = Ventana(self, lugar)
		ventana.present()
		return ventana

	def do_command_line(self, linea):
		args = linea.get_arguments()[1:]
		lugares = [a for a in args if not a.startswith('--')]
		if '--servicio' in args and not lugares:
			self.hold()
			GLib.timeout_add_seconds(30, lambda: self.release() or False)
			return 0
		for lugar in lugares or ['inicio']:
			if lugar not in ESPECIALES and '://' not in lugar:
				lugar = os.path.join(linea.get_cwd() or GLib.get_home_dir(), os.path.expanduser(lugar))
			self.nueva_ventana(lugar)
		return 0


if __name__ == '__main__':
	sys.exit(Explorador().run(sys.argv))
