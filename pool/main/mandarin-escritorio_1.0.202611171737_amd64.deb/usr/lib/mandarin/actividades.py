#!/usr/bin/env python3
"""Mandarin OS · Centro de actividades, como la configuración rápida de Windows 10/11.

Sale abajo a la derecha, encima de la bandeja (botón de la barra o Win+A), y se cierra al pulsar fuera o con Esc.
Botones grandes: Wi-Fi, modo avión, luz nocturna, no molestar, proyectar, recortes y teclado táctil (si la pantalla
es táctil); deslizadores de brillo (si es un portátil) y volumen; abajo, la batería y el Panel de control.

Uso: mandarin-actividades
     mandarin-actividades --aplicar    al entrar en la sesión: vuelve a poner la luz nocturna si estaba encendida
"""
import glob
import os
import re
import subprocess
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, Gio, GLib, Gtk, cargar_css, clase, ejecutar, etiqueta, existe  # noqa: E402,F401

GLib.set_prgname('mandarin-actividades')
GLib.set_application_name('Centro de actividades')

CONFIG = os.path.expanduser('~/.config/mandarin')
CERRADO = os.path.expanduser('~/.cache/mandarin/actividades-cerrado')
GAMMA_NOCTURNA = '1:0.86:0.70'
CSS = b"""
.a-ventana { background-color: @theme_base_color; border: 1px solid alpha(@theme_fg_color, 0.18); }
.a-boton { background-image: none; background-color: alpha(@theme_fg_color, 0.07); border: none; box-shadow: none;
           border-radius: 8px; padding: 10px 10px 8px 10px; }
.a-boton:hover { background-color: alpha(@theme_fg_color, 0.13); }
.a-boton.a-encendido { background-color: #f26b1d; }
.a-boton.a-encendido:hover { background-color: #dc5d13; }
.a-boton.a-encendido label, .a-boton.a-encendido image { color: #ffffff; }
.a-nombre { font-weight: 600; font-size: 9pt; }
.a-detalle { font-size: 8pt; opacity: 0.78; }
.a-pie { background-color: alpha(@theme_fg_color, 0.04); border-top: 1px solid alpha(@theme_fg_color, 0.10); }
.a-pie button { background-image: none; background-color: transparent; border: none; box-shadow: none; padding: 6px; }
.a-pie button:hover { background-color: alpha(@theme_fg_color, 0.10); }
.a-redondo { background-image: none; background-color: transparent; border: none; box-shadow: none; padding: 4px; border-radius: 16px; }
.a-redondo:hover { background-color: alpha(@theme_fg_color, 0.10); }
"""


def salida(*orden):
	try:
		return subprocess.run(list(orden), capture_output=True, text=True, env=dict(os.environ, LC_ALL='C.UTF-8', LANGUAGE=''), timeout=4).stdout.strip()
	except (OSError, subprocess.SubprocessError):
		return ''


def bandera(nombre, valor=None):
	"""Un ajuste de sí/no guardado en ~/.config/mandarin/<nombre>."""
	ruta = os.path.join(CONFIG, nombre)
	if valor is None:
		return os.path.exists(ruta)
	if valor:
		os.makedirs(CONFIG, exist_ok=True)
		open(ruta, 'w').close()
	elif os.path.exists(ruta):
		os.remove(ruta)
	return valor


# ─── Lo que controla cada botón ──────────────────────────────────────────────────────────────────────────────────

def wifi():
	"""(encendido, nombre de la red o None); None si no hay Wi-Fi."""
	if not existe('nmcli'):
		return None
	estado = salida('nmcli', '-t', '-f', 'WIFI', 'general')
	if not estado:
		return None
	red = None
	hay_tarjeta = False
	for linea in salida('nmcli', '-t', '-f', 'TYPE,STATE,CONNECTION', 'device').splitlines():
		partes = linea.split(':', 2)
		if partes[0] != 'wifi':
			continue
		hay_tarjeta = True
		if len(partes) == 3 and partes[1] == 'connected':
			red = partes[2].replace('\\:', ':')   # nmcli -t escapa los «:» del nombre de la red
	if not hay_tarjeta:
		return None
	return estado == 'enabled', red


def poner_wifi(si):
	ejecutar('nmcli', 'radio', 'wifi', 'on' if si else 'off')


def avion():
	return bandera('modo-avion') and salida('nmcli', '-t', '-f', 'WIFI', 'general') != 'enabled'


def poner_avion(si):
	bandera('modo-avion', si)
	ejecutar('nmcli', 'radio', 'all', 'off' if si else 'on')
	ejecutar('rfkill', 'block' if si else 'unblock', 'all')


def bluetooth():
	"""(encendido, nombre del aparato conectado o None); None si el equipo no tiene Bluetooth."""
	if not existe('bluetoothctl') or not glob.glob('/sys/class/bluetooth/hci*'):
		return None
	estado = salida('bluetoothctl', 'show')
	if 'Controller' not in estado:
		return None
	encendido = re.search(r'^\s*Powered: yes', estado, re.M) is not None
	conectado = None
	if encendido:
		m = re.search(r'^Device \S+ (.+)$', salida('bluetoothctl', 'devices', 'Connected'), re.M)
		conectado = m.group(1).strip() if m else None
	return encendido, conectado


# encender pasa también por rfkill: el modo avión lo deja bloqueado y bluetoothctl solo no puede encenderlo
ENCENDER_BT = 'rfkill unblock bluetooth 2>/dev/null; bluetoothctl power on >/dev/null 2>&1'


def poner_bluetooth(si):
	ejecutar('sh', '-c', ENCENDER_BT if si else 'bluetoothctl power off >/dev/null 2>&1')


def salidas_pantalla():
	return re.findall(r'^(\S+) connected', salida('xrandr', '--query'), re.M)


def aplicar_luz(si):
	for s in salidas_pantalla():
		subprocess.run(['xrandr', '--output', s, '--gamma', GAMMA_NOCTURNA if si else '1:1:1'], check=False)


def no_molestar():
	return salida('xfconf-query', '-c', 'xfce4-notifyd', '-p', '/do-not-disturb') == 'true'


def poner_no_molestar(si):
	ejecutar('xfconf-query', '-c', 'xfce4-notifyd', '-p', '/do-not-disturb', '-n', '-t', 'bool', '-s', 'true' if si else 'false')


def pantalla_tactil():
	return any('ID_INPUT_TOUCHSCREEN=1' in open(f, errors='ignore').read() for f in glob.glob('/run/udev/data/c13:*'))


def teclado_en_pantalla():
	"""Abre el teclado táctil de Mandarin (mandarin-teclado)."""
	ejecutar('mandarin-teclado', '--mostrar')


def luz_pantalla():
	"""(nombre, actual, máximo) de la retroiluminación, o None en un equipo de sobremesa."""
	mejores = sorted(glob.glob('/sys/class/backlight/*'), key=lambda d: ('intel' not in d and 'amdgpu' not in d, d))
	for d in mejores:
		try:
			maximo = int(open(d + '/max_brightness').read())
			actual = int(open(d + '/brightness').read())
		except (OSError, ValueError):
			continue
		if maximo > 0:
			return os.path.basename(d), actual, maximo
	return None


def poner_luz_pantalla(nombre, valor):
	"""Por logind: el usuario sentado delante puede cambiar el brillo sin contraseña."""
	try:
		bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
		bus.call_sync('org.freedesktop.login1', '/org/freedesktop/login1/session/auto', 'org.freedesktop.login1.Session',
					  'SetBrightness', GLib.Variant('(ssu)', ('backlight', nombre, int(valor))), None,
					  Gio.DBusCallFlags.NONE, 2000, None)
	except GLib.Error:
		pass


def volumen():
	"""(0..1, silenciado) del altavoz por defecto (PipeWire), o None."""
	if not existe('wpctl'):
		return None
	m = re.search(r'Volume:\s*([\d.]+)(\s*\[MUTED\])?', salida('wpctl', 'get-volume', '@DEFAULT_AUDIO_SINK@'))
	return (min(float(m.group(1)), 1.0), bool(m.group(2))) if m else None


def bateria():
	for d in sorted(glob.glob('/sys/class/power_supply/*')):
		try:
			if open(d + '/type').read().strip() != 'Battery' or os.path.exists(d + '/scope') and \
					open(d + '/scope').read().strip() == 'Device':
				continue
			nivel = int(open(d + '/capacity').read())
			estado = open(d + '/status').read().strip()
		except (OSError, ValueError):
			continue
		return nivel, estado
	return None


def icono(nombres, px=20):
	tema = Gtk.IconTheme.get_default()
	nombre = next((n for n in nombres if tema.has_icon(n)), nombres[-1])
	img = Gtk.Image.new_from_icon_name(nombre, Gtk.IconSize.LARGE_TOOLBAR)
	img.set_pixel_size(px)
	return img


# ─── Ventana ─────────────────────────────────────────────────────────────────────────────────────────────────────

class Boton(Gtk.Button):
	"""Botón grande de la rejilla: icono arriba, nombre y una línea de detalle; naranja si está encendido."""

	def __init__(self, nombre, iconos, accion, detalle=''):
		super().__init__()
		clase(self, 'a-boton')
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
		caja.pack_start(icono(iconos), False, False, 0)
		caja.get_children()[0].set_halign(Gtk.Align.START)
		caja.pack_start(Gtk.Box(), True, True, 0)
		caja.pack_start(etiqueta(nombre, 'a-nombre', elipsis=True), False, False, 0)
		self.detalle = etiqueta(detalle, 'a-detalle', elipsis=True)
		caja.pack_start(self.detalle, False, False, 0)
		self.add(caja)
		self.set_size_request(112, 78)
		self.connect('clicked', lambda *_: accion(self))

	def encendido(self, si, detalle=None):
		ctx = self.get_style_context()
		(ctx.add_class if si else ctx.remove_class)('a-encendido')
		if detalle is not None:
			self.detalle.set_text(detalle)


class Actividades(Gtk.ApplicationWindow):
	def __init__(self, app):
		super().__init__(application=app, title='Centro de actividades', decorated=False, resizable=False,
						 skip_taskbar_hint=True, skip_pager_hint=True)
		self.set_keep_above(True)
		clase(self, 'a-ventana')
		self.cerrando = False
		todo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
		self.add(todo)
		rejilla = Gtk.Grid(row_spacing=8, column_spacing=8, margin=14, column_homogeneous=True)
		todo.pack_start(rejilla, False, False, 0)
		botones = []

		red = wifi()
		if red is not None:
			self.b_wifi = Boton('Wi-Fi', ['network-wireless-symbolic', 'nm-signal-100'], self.pulsar_wifi)
			self.b_wifi.encendido(red[0], (red[1] or 'Sin conectar') if red[0] else 'Apagado')
			botones.append(self.b_wifi)
			self.b_avion = Boton('Modo avión', ['airplane-mode-symbolic', 'network-wireless-disabled-symbolic'], self.pulsar_avion)
			self.b_avion.encendido(avion(), 'Activado' if avion() else '')
			botones.append(self.b_avion)
		bt = bluetooth()
		if bt is not None:
			self.b_bt = Boton('Bluetooth', ['bluetooth-active-symbolic', 'bluetooth-symbolic'], self.pulsar_bt)
			self.b_bt.encendido(bt[0], (bt[1] or 'Activado') if bt[0] else 'Apagado')
			botones.append(self.b_bt)
			botones.append(Boton('Conectar', ['audio-headphones-symbolic', 'bluetooth-symbolic'],
								 lambda b: self.abrir('sh', '-c', ENCENDER_BT + '; exec blueman-manager'), 'Auriculares, ratón…'))
		self.b_luz =Boton('Luz nocturna', ['night-light-symbolic', 'weather-clear-night-symbolic', 'display-brightness-symbolic'],
						   self.pulsar_luz)
		self.b_luz.encendido(bandera('luz-nocturna'), 'Activada' if bandera('luz-nocturna') else 'Colores más cálidos')
		botones.append(self.b_luz)
		self.b_molestar = Boton('No molestar', ['notifications-disabled-symbolic', 'preferences-system-notifications-symbolic'],
								self.pulsar_molestar)
		self.b_molestar.encendido(no_molestar(), 'Sin avisos' if no_molestar() else '')
		botones.append(self.b_molestar)
		botones.append(Boton('Proyectar', ['video-display-symbolic', 'display-symbolic'],
							 lambda b: self.abrir('xfce4-display-settings', '--minimal'), 'Otra pantalla'))
		botones.append(Boton('Recortes', ['mandarin-recortes', 'edit-cut-symbolic'], lambda b: self.abrir('mandarin-recortes'),
							 'Win+Mayús+S'))
		if existe('mandarin-teclado') and (pantalla_tactil() or os.path.exists('/run/mandarin/tableta')):
			botones.append(Boton('Teclado táctil', ['mandarin-teclado-symbolic', 'input-keyboard-symbolic'],
								 lambda b: (teclado_en_pantalla(), self.cerrar()), 'En pantalla'))
		for i, b in enumerate(botones):
			rejilla.attach(b, i % 3, i // 3, 1, 1)

		# deslizadores
		deslizadores = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_start=14, margin_end=14, margin_bottom=10)
		todo.pack_start(deslizadores, False, False, 0)
		luz = luz_pantalla()
		if luz is not None:
			nombre, actual, maximo = luz
			fila = Gtk.Box(spacing=8)
			fila.pack_start(icono(['display-brightness-symbolic', 'weather-clear-symbolic']), False, False, 6)
			escala = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
			escala.set_draw_value(False)
			escala.set_value(round(actual * 100 / maximo))
			# nunca a 0: la pantalla se quedaría negra
			escala.connect('value-changed', lambda e: self.aplazar('luz', lambda: poner_luz_pantalla(
				nombre, max(1, round(e.get_value() * maximo / 100)))))
			fila.pack_start(escala, True, True, 0)
			deslizadores.pack_start(fila, False, False, 0)
		vol = volumen()
		if vol is not None:
			fila = Gtk.Box(spacing=8)
			self.b_mudo = clase(Gtk.Button(), 'a-redondo')
			self.b_mudo.set_tooltip_text('Silenciar')
			self.b_mudo.connect('clicked', self.pulsar_mudo)
			fila.pack_start(self.b_mudo, False, False, 2)
			self.escala_vol = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
			self.escala_vol.set_draw_value(False)
			self.escala_vol.set_value(round(vol[0] * 100))
			self.escala_vol.connect('value-changed', self.cambiar_volumen)
			fila.pack_start(self.escala_vol, True, True, 0)
			deslizadores.pack_start(fila, False, False, 0)
			self.mudo = vol[1]
			self.icono_volumen()

		# pie: batería y Panel de control
		pie = clase(Gtk.Box(spacing=8), 'a-pie')
		pie.set_border_width(6)
		bat = bateria()
		if bat is not None:
			nivel, estado = bat
			decena = min(100, round(nivel / 10) * 10)
			nombres = [f'battery-level-{decena}{"-charging" if estado == "Charging" else ""}-symbolic', 'battery-good-symbolic']
			pie.pack_start(icono(nombres, 18), False, False, 8)
			textos = {'Charging': ' · cargando', 'Full': ' · llena', 'Not charging': ' · enchufada'}
			pie.pack_start(etiqueta(f'{nivel} %' + textos.get(estado, '')), False, False, 0)
		ajustes = Gtk.Button()
		ajustes.add(icono(['emblem-system-symbolic', 'preferences-system-symbolic'], 18))
		ajustes.set_tooltip_text('Panel de control')
		ajustes.connect('clicked', lambda *_: self.abrir('mandarin-panel'))
		pie.pack_end(ajustes, False, False, 0)
		todo.pack_start(pie, False, False, 0)

		self.pendientes = {}
		self.connect('focus-out-event', lambda *_: GLib.timeout_add(120, self.quizas_cerrar))
		# tocar o hacer clic fuera lo cierra: mientras está abierto se queda con el ratón y el dedo, y lo que cae
		# fuera de la ventana lo recibe ella (con el foco solo no basta: al tocar el escritorio a veces no cambia)
		self.agarre = False
		self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.TOUCH_MASK)
		self.connect('map-event', lambda *_: GLib.timeout_add(150, self.agarrar))
		self.connect('button-press-event', lambda _w, e: self.quizas_fuera(e.x_root, e.y_root))
		self.connect('touch-event', lambda _w, e: e.type == Gdk.EventType.TOUCH_BEGIN and self.quizas_fuera(e.touch.x_root, e.touch.y_root))
		self.connect('key-press-event', lambda _w, e: self.cerrar() if e.keyval == Gdk.KEY_Escape else False)
		todo.show_all()
		self.colocar()

	def colocar(self):
		"""Abajo a la derecha, encima de la barra de tareas, como en Windows."""
		monitor = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
		area = monitor.get_workarea()
		_minimo, natural = self.get_preferred_size()
		ancho = max(natural.width, 380)
		self.set_size_request(ancho, -1)
		self.move(area.x + area.width - ancho - 10, area.y + area.height - natural.height - 10)

	# ── acciones ──
	def pulsar_wifi(self, b):
		encendido = not b.get_style_context().has_class('a-encendido')
		poner_wifi(encendido)
		b.encendido(encendido, 'Conectando…' if encendido else 'Apagado')
		if encendido and self.b_avion.get_style_context().has_class('a-encendido'):
			bandera('modo-avion', False)
			self.b_avion.encendido(False, '')
		GLib.timeout_add(3500, self.refrescar_wifi)

	def refrescar_wifi(self):
		if self.cerrando:
			return False
		red = wifi()
		if red is not None:
			self.b_wifi.encendido(red[0], (red[1] or 'Sin conectar') if red[0] else 'Apagado')
		return False

	def pulsar_avion(self, b):
		si = not b.get_style_context().has_class('a-encendido')
		poner_avion(si)
		b.encendido(si, 'Activado' if si else '')
		self.b_wifi.encendido(not si, 'Apagado' if si else 'Conectando…')
		GLib.timeout_add(3500, self.refrescar_wifi)

	def pulsar_bt(self, b):
		si = not b.get_style_context().has_class('a-encendido')
		poner_bluetooth(si)
		b.encendido(si, 'Encendiendo…' if si else 'Apagado')
		GLib.timeout_add(2500, self.refrescar_bt)

	def refrescar_bt(self):
		if self.cerrando:
			return False
		bt = bluetooth()
		if bt is not None:
			self.b_bt.encendido(bt[0], (bt[1] or 'Activado') if bt[0] else 'Apagado')
		return False

	def pulsar_luz(self, b):
		si = bandera('luz-nocturna', not bandera('luz-nocturna'))
		threading.Thread(target=aplicar_luz, args=(si,), daemon=True).start()
		b.encendido(si, 'Activada' if si else 'Colores más cálidos')

	def pulsar_molestar(self, b):
		si = not no_molestar()
		poner_no_molestar(si)
		b.encendido(si, 'Sin avisos' if si else '')

	def aplazar(self, clave, funcion):
		"""Al arrastrar un deslizador llegan muchos cambios: se aplica el último cada 80 ms."""
		ya = clave in self.pendientes
		self.pendientes[clave] = funcion
		if not ya:
			def aplicar():
				f = self.pendientes.pop(clave, None)
				if f:
					threading.Thread(target=f, daemon=True).start()
				return False
			GLib.timeout_add(80, aplicar)

	def cambiar_volumen(self, escala):
		valor = escala.get_value() / 100
		if self.mudo:
			self.mudo = False
			ejecutar('wpctl', 'set-mute', '@DEFAULT_AUDIO_SINK@', '0')
		self.aplazar('vol', lambda: subprocess.run(['wpctl', 'set-volume', '-l', '1.0', '@DEFAULT_AUDIO_SINK@', f'{valor:.2f}'],
												   check=False))
		self.icono_volumen()

	def pulsar_mudo(self, _b):
		self.mudo = not self.mudo
		ejecutar('wpctl', 'set-mute', '@DEFAULT_AUDIO_SINK@', '1' if self.mudo else '0')
		self.icono_volumen()

	def icono_volumen(self):
		v = self.escala_vol.get_value()
		nivel = 'muted' if self.mudo or v == 0 else 'low' if v < 34 else 'medium' if v < 67 else 'high'
		hijo = self.b_mudo.get_child()
		if hijo:
			self.b_mudo.remove(hijo)
		self.b_mudo.add(icono([f'audio-volume-{nivel}-symbolic'], 20))
		self.b_mudo.show_all()

	def abrir(self, *orden):
		self.cerrar()
		ejecutar(*orden)

	def quizas_cerrar(self):
		if not self.is_active() and not self.cerrando:
			self.cerrar()
		return False

	def agarrar(self):
		ventana = self.get_window()
		if ventana is None or self.cerrando:
			return False
		asiento = Gdk.Display.get_default().get_default_seat()
		capacidades = Gdk.SeatCapabilities.POINTER | Gdk.SeatCapabilities.TOUCH | Gdk.SeatCapabilities.TABLET_STYLUS
		for _ in range(10):   # el gestor de ventanas puede tener el ratón un instante
			if asiento.grab(ventana, capacidades, True, None, None, None) == Gdk.GrabStatus.SUCCESS:
				self.agarre = True
				break
			time.sleep(0.03)
		return False

	def soltar_agarre(self):
		if self.agarre:
			Gdk.Display.get_default().get_default_seat().ungrab()
			self.agarre = False

	def quizas_fuera(self, x, y):
		"""Un clic o un toque: si cae fuera de la ventana, se cierra y no pasa nada más."""
		ox, oy = self.get_window().get_origin()[1:]
		ancho, alto = self.get_allocated_width(), self.get_allocated_height()
		if not (ox <= x < ox + ancho and oy <= y < oy + alto):
			self.cerrar()
			return True
		return False

	def cerrar(self):
		if self.cerrando:
			return True
		self.soltar_agarre()
		self.cerrando = True
		try:
			os.makedirs(os.path.dirname(CERRADO), exist_ok=True)
			with open(CERRADO, 'w') as f:
				f.write(str(time.time()))
		except OSError:
			pass
		self.hide()
		GLib.timeout_add(400, lambda: self.get_application().quit())   # deja terminar lo último de los deslizadores
		return True


class AppActividades(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Actividades')

	def do_startup(self):
		Gtk.Application.do_startup(self)
		cargar_css(CSS)

	def do_activate(self):
		ventana = self.get_active_window()
		if ventana is not None:   # segunda pulsación con la ventana abierta: se cierra
			ventana.cerrar()
			return
		try:
			# la pulsación en el botón de la barra ya la ha cerrado (al perder el foco): no se vuelve a abrir
			if time.time() - float(open(CERRADO).read()) < 0.6:
				return
		except (OSError, ValueError):
			pass
		v = Actividades(self)
		v.show()
		v.present_with_time(Gtk.get_current_event_time() or int(GLib.get_monotonic_time() / 1000))


if __name__ == '__main__':
	if '--aplicar' in sys.argv:
		if bandera('luz-nocturna'):
			aplicar_luz(True)
	else:
		sys.exit(AppActividades().run([sys.argv[0]]))
