"""Mandarin OS · piezas comunes de las aplicaciones propias (GTK3).

Las aplicaciones se apoyan en el tema GTK «Mandarin»; aquí solo hay los estilos de su maquetación
y utilidades: tamaños y fechas en español, carpetas del usuario, abrir archivos y ventanas de cristal.
"""
import os
import shutil
import subprocess

import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk  # noqa: E402,F401

CSS = b"""
.m-titulo1 { font-family: "Inter Display", "Inter", sans-serif; font-weight: 200; font-size: 22pt; }
.m-titulo2 { font-family: "Inter Display", "Inter", sans-serif; font-weight: 300; font-size: 15pt; }
.m-titulo3 { font-family: "Inter Display", "Inter", sans-serif; font-weight: 500; font-size: 11.5pt; }
.m-usuario { font-family: "Inter Display", "Inter", sans-serif; font-weight: 300; font-size: 13.5pt; }
.m-pie { font-size: 8.5pt; }
.m-tenue { opacity: 0.75; }
.m-seccion { font-size: 8pt; font-weight: 600; }
.m-fuerte { font-weight: 600; }
.m-acento { color: @theme_selected_bg_color; }
button.m-plano { background-image: none; background-color: transparent; border-color: transparent; box-shadow: none; padding: 4px 8px; }
button.m-plano:hover { background-color: alpha(@theme_selected_bg_color, 0.10); }
button.m-plano:checked { background-color: alpha(@theme_selected_bg_color, 0.16); }
button.m-enlace { background-image: none; background-color: transparent; border-color: transparent; box-shadow: none; padding: 1px 0; min-height: 0; }
button.m-enlace label { color: @theme_selected_bg_color; }
button.m-enlace:hover label { text-decoration-line: underline; }
.m-lateral { background-color: @theme_bg_color; border-right: 1px solid @borders; }
.m-lateral row { padding: 4px 8px; margin: 0 6px; border-radius: 2px; }
.m-lateral image { color: @theme_selected_bg_color; }
.m-lateral image.m-pin { color: alpha(@theme_fg_color, 0.35); }
.m-lateral row:selected image, .m-lateral row:selected image.m-pin { color: @theme_selected_fg_color; }
.m-contenido { background-color: @theme_base_color; }
.m-barra { background-color: @theme_bg_color; }
.m-borde-abajo { border-bottom: 1px solid alpha(@theme_fg_color, 0.10); }
.m-borde-arriba { border-top: 1px solid alpha(@theme_fg_color, 0.10); }
.m-ruta { background-color: @theme_base_color; border: 1px solid @borders; border-radius: 2px; padding: 0 4px; }
.m-ruta button { padding: 2px 5px; min-height: 0; }
.m-baldosa { padding: 8px 10px; border-radius: 2px; }
levelbar.m-uso trough { min-height: 10px; border-radius: 0; padding: 1px; }
levelbar.m-uso block { border-radius: 0; }
levelbar.m-uso block.filled, levelbar.m-uso block.low, levelbar.m-uso block.high, levelbar.m-uso block.full { background-color: #f26b1d; border-color: #f26b1d; }
levelbar.m-uso.m-lleno block.filled, levelbar.m-uso.m-lleno block.full, levelbar.m-uso.m-lleno block.high { background-color: #b42335; border-color: #b42335; }
.m-avatar { background-color: #f26b1d; border-radius: 2px; color: #ffffff; }
/* Ventanas de cristal (modo completo, con picom desenfocando detras): marco al 45 %, contenido lechoso al 92 %
   (0.45 + 0.85 del resto). En modo ligero no se toca nada: marco arena y contenido blanco, opacos. */
window.m-cristal, window.m-cristal.background { background-color: alpha(@theme_base_color, 0.45); }
window.m-cristal .m-lateral, window.m-cristal .m-barra, window.m-cristal .m-lateral list,
window.m-cristal .m-lateral viewport { background-color: transparent; }
window.m-cristal .m-contenido { background-color: alpha(@theme_base_color, 0.85); }
window.m-cristal .m-ruta, window.m-cristal entry { background-color: alpha(@theme_base_color, 0.7); }
"""


_CSS_CARGADO = []


def _css_con_acento(datos):
	try:   # el naranja de las apps, cambiado por el color de acento que se haya elegido
		import aspecto
		return aspecto.recolorear(datos.decode('utf-8'), oscuro()).encode('utf-8')
	except Exception:   # noqa: BLE001 — nunca dejar una app sin estilos por esto
		return datos


def recargar_css():
	"""Vuelve a aplicar el color de acento a los estilos propios de la app (tras cambiarlo en el Panel de control)."""
	for proveedor, datos in _CSS_CARGADO:
		proveedor.load_from_data(_css_con_acento(datos))


def cargar_css(extra=b''):
	proveedor = Gtk.CssProvider()
	proveedor.load_from_data(_css_con_acento(CSS + extra))
	_CSS_CARGADO.append((proveedor, CSS + extra))
	Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), proveedor, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


def oscuro():
	return (Gtk.Settings.get_default().props.gtk_theme_name or '').endswith('Oscuro')


def modo():
	"""'completo' (cristal en vivo, Proton) o 'ligero'; lo decide mandarin-modo al entrar."""
	try:
		with open(os.path.expanduser('~/.cache/mandarin/modo')) as f:
			return f.read().strip() or 'ligero'
	except OSError:
		return 'ligero'


def translucida(ventana):
	"""Ventana con canal alfa (para fondos de cristal) si hay compositor."""
	pantalla = ventana.get_screen()
	visual = pantalla.get_rgba_visual()
	if visual is not None and pantalla.is_composited():
		ventana.set_visual(visual)
		return True
	return False


def tam(n):
	if n is None or n < 0:
		return ''
	if n < 1024:
		return f'{n} bytes'
	for unidad in ('KB', 'MB', 'GB', 'TB'):
		n /= 1024
		if n < 1024 or unidad == 'TB':
			return (f'{n:.1f}' if n < 100 else f'{n:.0f}').replace('.', ',') + ' ' + unidad
	return ''


def gb(n):
	return f'{n / 1024 ** 3:.1f}'.replace('.', ',')


DIAS = ('lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo')


def fecha(segundos):
	if not segundos:
		return ''
	f = GLib.DateTime.new_from_unix_local(int(segundos))
	hoy = GLib.DateTime.new_now_local()
	hora = f.format('%H:%M')
	dias = (GLib.Date.new_dmy(hoy.get_day_of_month(), hoy.get_month(), hoy.get_year()).get_julian()
			- GLib.Date.new_dmy(f.get_day_of_month(), f.get_month(), f.get_year()).get_julian())
	if dias == 0:
		return f'hoy, {hora}'
	if dias == 1:
		return f'ayer, {hora}'
	if 1 < dias < 7:
		return f'{DIAS[f.get_day_of_week() - 1]}, {hora}'
	return f.format('%d/%m/%Y')


CARPETAS = (
	('escritorio', 'Escritorio', GLib.UserDirectory.DIRECTORY_DESKTOP, 'user-desktop'),
	('descargas', 'Descargas', GLib.UserDirectory.DIRECTORY_DOWNLOAD, 'folder-download'),
	('documentos', 'Documentos', GLib.UserDirectory.DIRECTORY_DOCUMENTS, 'folder-documents'),
	('imagenes', 'Imágenes', GLib.UserDirectory.DIRECTORY_PICTURES, 'folder-pictures'),
	('musica', 'Música', GLib.UserDirectory.DIRECTORY_MUSIC, 'folder-music'),
	('videos', 'Vídeos', GLib.UserDirectory.DIRECTORY_VIDEOS, 'folder-videos'),
)


def carpeta(clave):
	"""Ruta de una carpeta del usuario ('documentos'...) o la carpeta personal."""
	for c, _, especial, _ in CARPETAS:
		if c == clave:
			ruta = GLib.get_user_special_dir(especial)
			if ruta:
				return ruta
	return GLib.get_home_dir()


def usuario():
	return GLib.get_real_name() if GLib.get_real_name() not in ('', 'Unknown') else GLib.get_user_name()


def existe(programa):
	return shutil.which(programa) is not None


def ejecutar(*orden):
	try:
		subprocess.Popen(list(orden), start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
		return True
	except OSError:
		return False


def es_programa_windows(nombre):
	return nombre.lower().endswith(('.exe', '.msi', '.bat', '.lnk'))


def abrir_archivo(gfile, ventana=None):
	"""Abre un archivo con su programa; los de Windows van a mandarin-exe (Wine o Proton)."""
	ruta = gfile.get_path()
	if ruta and es_programa_windows(ruta):
		return ejecutar('mandarin-exe', ruta)
	try:
		Gio.AppInfo.launch_default_for_uri(gfile.get_uri(), None)
		return True
	except GLib.Error:
		dialogo = Gtk.AppChooserDialog.new(ventana, Gtk.DialogFlags.MODAL, gfile)
		if dialogo.run() == Gtk.ResponseType.OK:
			app = dialogo.get_app_info()
			if app:
				app.launch([gfile], None)
		dialogo.destroy()
		return False


def icono(nombre, px):
	imagen = Gtk.Image.new_from_icon_name(nombre, Gtk.IconSize.DIALOG)
	imagen.set_pixel_size(px)
	return imagen


_cache_iconos = {}


def pixbuf(gicon, px):
	"""Pixbuf de un GIcon a un tamaño, con caché."""
	clave = (gicon.to_string() if gicon else 'nada', px)
	if clave in _cache_iconos:
		return _cache_iconos[clave]
	tema = Gtk.IconTheme.get_default()
	pb = None
	if gicon is not None:
		info = tema.lookup_by_gicon(gicon, px, Gtk.IconLookupFlags.FORCE_SIZE)
		if info:
			try:
				pb = info.load_icon()
			except GLib.Error:
				pb = None
	if pb is None:
		try:
			pb = tema.load_icon('text-x-generic', px, Gtk.IconLookupFlags.FORCE_SIZE)
		except GLib.Error:
			pb = None
	_cache_iconos[clave] = pb
	return pb


def etiqueta(texto, *clases, xalign=0.0, elipsis=False):
	lbl = Gtk.Label(label=texto, xalign=xalign)
	for c in clases:
		lbl.get_style_context().add_class(c)
	if elipsis:
		from gi.repository import Pango
		lbl.set_ellipsize(Pango.EllipsizeMode.END)
	return lbl


def clase(widget, *clases):
	for c in clases:
		widget.get_style_context().add_class(c)
	return widget


def cristal(ventana):
	"""Ventana de cristal de Mandarin en modo completo (marco translúcido y contenido lechoso, ver CSS m-cristal).
	Hay que llamarla antes de mostrar la ventana: el visual con canal alfa solo se puede poner sin realizar."""
	if modo() == 'completo' and translucida(ventana):
		ventana.get_style_context().add_class('m-cristal')
		return True
	return False


# los programas que enseñan la ventana de la contraseña de administrador (agentes de polkit); /proc/…/comm corta a 15
AGENTES = ('lxpolkit', 'polkit-gnome-authentication-agent-1', 'polkit-mate-authentication-agent-1', 'xfce-polkit',
		   'lxqt-policykit-agent', 'polkit-kde-authentication-agent-1', 'mate-polkit')


def asegurar_agente():
	"""Arranca lxpolkit si en esta sesión no hay nada que pida la contraseña de administrador.
	Sin él, pkexec y timedatectl fallan sin enseñar ninguna ventana. Hay que llamarlo fuera del hilo de GTK (espera)."""
	import time
	uid = os.getuid()
	for pid in os.listdir('/proc'):
		if not pid.isdigit():
			continue
		try:
			if os.stat(f'/proc/{pid}').st_uid != uid:
				continue
			with open(f'/proc/{pid}/comm') as f:
				nombre = f.read().strip()
		except OSError:
			continue
		if any(a[:15] == nombre for a in AGENTES):
			return True
	if not existe('lxpolkit'):
		return False
	ejecutar('lxpolkit')
	time.sleep(1.2)
	return True
