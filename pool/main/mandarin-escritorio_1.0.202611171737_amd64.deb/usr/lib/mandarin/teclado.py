#!/usr/bin/env python3
"""Mandarin OS · teclado táctil propio (sustituye a onboard).

Teclado en pantalla con la distribución española: ñ, tildes (tecla ´ o dejando pulsada una vocal), números y
símbolos, mayúsculas (una pulsación: una letra; dos seguidas: bloqueo), borrar con repetición y flechas.
Se coloca abajo, encima de la barra de tareas, y reserva ese hueco para que las ventanas maximizadas no queden
debajo. Nunca se queda con el foco: lo que escribe va a la ventana que tenías activa (por XTest, como un teclado de
verdad; los caracteres que no tiene la distribución del teclado se ponen un instante en una tecla libre).

  mandarin-teclado              abre o esconde el teclado
  mandarin-teclado --mostrar    lo abre        · --ocultar  lo esconde
  mandarin-teclado --fondo      se queda en segundo plano con su botón en la bandeja (lo arranca la sesión)

El botón de la bandeja sale según ~/.config/mandarin/teclado-boton: «tableta» (por defecto: solo con el convertible
plegado, lo que dice /run/mandarin/tableta, que escribe mandarin-tableta.service), «siempre» o «nunca».
"""
import ctypes
import math
import os
import sys
import time
import warnings

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import Gdk, Gio, GLib, Gtk, ejecutar, oscuro  # noqa: E402

import gi  # noqa: E402

gi.require_version('GdkX11', '3.0')
gi.require_version('PangoCairo', '1.0')
from gi.repository import GdkX11, Pango, PangoCairo  # noqa: E402,F401

warnings.filterwarnings('ignore', category=DeprecationWarning)   # Gtk.StatusIcon

CONFIG = os.path.expanduser('~/.config/mandarin')
BOTON = os.path.join(CONFIG, 'teclado-boton')
TABLETA = '/run/mandarin/tableta'


def preferencia():
	try:
		with open(BOTON) as f:
			valor = f.read().strip()
	except OSError:
		valor = ''
	return valor if valor in ('tableta', 'siempre', 'nunca') else 'tableta'


def en_tableta():
	try:
		with open(TABLETA) as f:
			return f.read().strip() == '1'
	except OSError:
		return False


# ─── Escribir en la ventana activa (XTest) ───────────────────────────────────────────────────────────────────────

# caracteres que en X tienen un keysym propio (no el Unicode genérico 0x1000000 + código)
KEYSYMS = {'€': 0x20ac, '…': 0xaae, '–': 0xaaa, '—': 0xaa9, '“': 0xad2, '”': 0xad3, '•': 0xae6, '‘': 0xad0, '’': 0xad1}
ESPECIALES = {'BackSpace': 0xff08, 'Return': 0xff0d, 'Tab': 0xff09, 'Left': 0xff51, 'Right': 0xff53, 'Up': 0xff52,
			  'Down': 0xff54, 'Escape': 0xff1b}


def keysym(caracter):
	if caracter in KEYSYMS:
		return KEYSYMS[caracter]
	cp = ord(caracter)
	return cp if (0x20 <= cp <= 0x7e or 0xa0 <= cp <= 0xff) else 0x1000000 + cp


class Inyector:
	def __init__(self):
		self.x = ctypes.CDLL('libX11.so.6')
		self.t = ctypes.CDLL('libXtst.so.6')
		x, t = self.x, self.t
		x.XOpenDisplay.restype = ctypes.c_void_p
		x.XOpenDisplay.argtypes = [ctypes.c_char_p]
		x.XCloseDisplay.argtypes = [ctypes.c_void_p]
		x.XDisplayKeycodes.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
		x.XkbKeycodeToKeysym.restype = ctypes.c_ulong
		x.XkbKeycodeToKeysym.argtypes = [ctypes.c_void_p, ctypes.c_ubyte, ctypes.c_int, ctypes.c_int]
		x.XKeysymToKeycode.restype = ctypes.c_ubyte
		x.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
		x.XChangeKeyboardMapping.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_ulong), ctypes.c_int]
		x.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
		x.XFlush.argtypes = [ctypes.c_void_p]
		x.XInternAtom.restype = ctypes.c_ulong
		x.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
		x.XChangeProperty.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
									  ctypes.c_void_p, ctypes.c_int]
		t.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
		self.d = None
		self.prestada = None   # la tecla libre que tiene ahora un carácter prestado
		self.abrir()

	def abrir(self):
		"""(Re)abre la conexión con X: así se lee la distribución del teclado tal como esté ahora."""
		self.cerrar()
		self.d = self.x.XOpenDisplay(None)
		if not self.d:
			raise OSError('no se puede abrir la pantalla')
		minimo, maximo = ctypes.c_int(), ctypes.c_int()
		self.x.XDisplayKeycodes(self.d, ctypes.byref(minimo), ctypes.byref(maximo))
		self.mapa = {}
		self.libre = None
		for nivel in range(4):   # nivel 0: tal cual, 1: Mayús, 2: AltGr, 3: Mayús+AltGr
			for kc in range(minimo.value, maximo.value + 1):
				ks = self.x.XkbKeycodeToKeysym(self.d, kc, 0, nivel)
				if ks:
					self.mapa.setdefault(ks, (kc, nivel))
		for kc in range(maximo.value, minimo.value, -1):
			if not any(self.x.XkbKeycodeToKeysym(self.d, kc, 0, nivel) for nivel in range(4)):
				self.libre = kc
				break
		self.shift = self.x.XKeysymToKeycode(self.d, 0xffe1)
		self.altgr = self.x.XKeysymToKeycode(self.d, 0xfe03) or self.x.XKeysymToKeycode(self.d, 0xff7e)

	def cerrar(self):
		if self.d:
			self.devolver()
			self.x.XCloseDisplay(self.d)
			self.d = None

	def devolver(self):
		if self.prestada:
			vacio = (ctypes.c_ulong * 2)(0, 0)
			self.x.XChangeKeyboardMapping(self.d, self.prestada, 2, vacio, 1)
			self.x.XSync(self.d, 0)
			self.prestada = None

	def _tecla(self, kc, abajo):
		self.t.XTestFakeKeyEvent(self.d, kc, 1 if abajo else 0, 0)

	def pulsar(self, ks):
		if ks in self.mapa:
			kc, nivel = self.mapa[ks]
			mods = ([self.shift] if nivel & 1 else []) + ([self.altgr] if nivel & 2 and self.altgr else [])
		elif self.libre:
			kc, mods = self.libre, []
			prestado = (ctypes.c_ulong * 2)(ks, ks)
			self.x.XChangeKeyboardMapping(self.d, kc, 2, prestado, 1)
			self.x.XSync(self.d, 0)
			self.prestada = kc
			time.sleep(0.03)   # que la aplicación se entere del cambio antes de la pulsación
		else:
			return
		for m in mods:
			self._tecla(m, True)
		self._tecla(kc, True)
		self._tecla(kc, False)
		for m in reversed(mods):
			self._tecla(m, False)
		self.x.XFlush(self.d)

	def escribir(self, texto):
		for c in texto:
			self.pulsar(keysym(c))

	def especial(self, nombre):
		self.pulsar(ESPECIALES[nombre])

	def puntal(self, xid, abajo, x0, x1):
		"""Reserva el hueco de abajo (_NET_WM_STRUT_PARTIAL) para que las ventanas maximizadas no queden debajo."""
		cardinal = 6
		parcial = (ctypes.c_long * 12)(0, 0, 0, abajo, 0, 0, 0, 0, 0, 0, x0, x1)
		simple = (ctypes.c_long * 4)(0, 0, 0, abajo)
		for nombre, datos, n in ((b'_NET_WM_STRUT_PARTIAL', parcial, 12), (b'_NET_WM_STRUT', simple, 4)):
			atomo = self.x.XInternAtom(self.d, nombre, 0)
			self.x.XChangeProperty(self.d, xid, atomo, cardinal, 32, 0, ctypes.cast(datos, ctypes.c_void_p), n)
		self.x.XFlush(self.d)


# ─── Distribución ────────────────────────────────────────────────────────────────────────────────────────────────

class Tecla:
	__slots__ = ('etiqueta', 'tipo', 'valor', 'ancho', 'caja')

	def __init__(self, etiqueta, tipo='c', valor=None, ancho=1.0):
		self.etiqueta, self.tipo, self.ancho = etiqueta, tipo, ancho
		self.valor = etiqueta if valor is None else valor
		self.caja = (0, 0, 0, 0)

	def especial(self):
		return self.tipo != 'c' or self.valor == ' '


def letras(texto):
	return [Tecla(c) for c in texto]


def borrar():
	return Tecla('⌫', 'k', 'BackSpace', 1.5)


def intro():
	return Tecla('↵', 'k', 'Return', 1.5)


def ultima_fila(pagina_izq, etiqueta_izq, segunda):
	return [Tecla(etiqueta_izq, 'p', pagina_izq, 1.5), segunda, Tecla(' ', 'c', ' ', 6), Tecla('←', 'k', 'Left'),
			Tecla('→', 'k', 'Right'), Tecla('ocultar', 'ocultar')]


PAGINAS = {
	'letras': [
		letras('qwertyuiop') + [borrar()],
		letras('asdfghjklñ') + [intro()],
		[Tecla('⇧', 'shift', ancho=1.25)] + letras('zxcvbnm,.') + [Tecla('⇧', 'shift', ancho=1.25)],
		ultima_fila('simbolos', '&123', Tecla('´', 'acento')),
	],
	'simbolos': [
		letras('1234567890') + [borrar()],
		letras('@#€&_-()"\'') + [intro()],
		[Tecla('=\\<', 'p', 'mas', 1.25)] + letras('!?¿¡:;/,.') + [Tecla('=\\<', 'p', 'mas', 1.25)],
		ultima_fila('letras', 'abc', Tecla('%')),
	],
	'mas': [
		letras('+*=%<>[]{}') + [borrar()],
		letras('\\|~^`°ºª$£') + [intro()],
		[Tecla('123', 'p', 'simbolos', 1.25)] + letras('«»·•…¨¬©®') + [Tecla('123', 'p', 'simbolos', 1.25)],
		ultima_fila('letras', 'abc', Tecla('Tab', 'k', 'Tab')),
	],
}
ANCHO_FILA = 11.5   # todas las filas suman lo mismo, en anchos de tecla

# dejando pulsada una tecla salen estas (como en el móvil)
VARIANTES = {'a': 'áàäâª', 'e': 'éèëê€', 'i': 'íìïî', 'o': 'óòöôº', 'u': 'úüùû', 'n': 'ñ', 'ñ': 'n', 'c': 'ç',
			 '?': '¿', '!': '¡', '.': '…', '-': '_–—', '$': '€£¥', '"': '«»“”', "'": '‘’', '0': '°', '1': '¹½', '2': '²', '3': '³'}
ACENTOS = {'agudo': dict(zip('aeiouAEIOU', 'áéíóúÁÉÍÓÚ')), 'dieresis': dict(zip('aeiouAEIOU', 'äëïöüÄËÏÖÜ'))}
REPITE = {'BackSpace', 'Left', 'Right'}

COLORES = {
	False: {'fondo': '#E4DED7', 'tecla': '#FFFFFF', 'especial': '#D2CBC3', 'texto': '#2B2420', 'tenue': '#7A706A',
			'sombra': '#B9B1A9', 'acento': '#F26B1D', 'sobre_acento': '#FFFFFF', 'borde': '#CFC7BF'},
	True: {'fondo': '#1C1917', 'tecla': '#3A3431', 'especial': '#2A2522', 'texto': '#F4EFE9', 'tenue': '#A89D95',
		   'sombra': '#0E0C0B', 'acento': '#F26B1D', 'sobre_acento': '#FFFFFF', 'borde': '#2E2926'},
}


def rgb(hexa):
	return tuple(int(hexa[i:i + 2], 16) / 255 for i in (1, 3, 5))


def rect_redondo(cr, x, y, w, h, r):
	cr.new_sub_path()
	cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
	cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
	cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
	cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
	cr.close_path()


# ─── Ventana del teclado ─────────────────────────────────────────────────────────────────────────────────────────

class Teclado(Gtk.Window):
	def __init__(self, app):
		super().__init__(type=Gtk.WindowType.TOPLEVEL, title='Teclado táctil')
		self.app = app
		self.set_type_hint(Gdk.WindowTypeHint.DOCK)   # sin foco, sin botón en la barra, encima de las ventanas
		self.set_accept_focus(False)
		self.set_focus_on_map(False)
		self.set_skip_taskbar_hint(True)
		self.set_skip_pager_hint(True)
		self.set_decorated(False)
		self.set_keep_above(True)
		self.stick()
		self.pagina = 'letras'
		self.mayus = 0          # 0 no, 1 la siguiente letra, 2 bloqueadas
		self.ultimo_shift = 0
		self.acento = None      # None, 'agudo' o 'dieresis'
		self.pulsada = None
		self.variantes = None   # (tecla, [(caracter, caja)], elegida)
		self.temporizador = None
		self.toque = None       # la secuencia del dedo que está pulsando
		self.hueco = None       # alto de la barra de tareas de abajo
		self.area = Gtk.DrawingArea()
		self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK |
							 Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.TOUCH_MASK)
		self.area.connect('draw', self.pintar)
		self.area.connect('button-press-event', lambda _w, e: e.button == 1 and self.pulsar(e.x, e.y))
		self.area.connect('motion-notify-event', lambda _w, e: self.mover(e.x, e.y))
		self.area.connect('button-release-event', lambda _w, e: e.button == 1 and self.soltar(e.x, e.y))
		self.area.connect('touch-event', self.tocar)
		self.add(self.area)
		self.area.show()
		pantalla = Gdk.Screen.get_default()
		pantalla.connect('size-changed', lambda *_: self.get_visible() and self.colocar())
		pantalla.connect('monitors-changed', lambda *_: self.get_visible() and self.colocar())

	# ── posición ──
	def colocar(self):
		monitor = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
		g = monitor.get_geometry()
		if self.hueco is None or not self.get_visible():
			area = monitor.get_workarea()
			self.hueco = max(0, (g.y + g.height) - (area.y + area.height))
		alto = int(min(max(min(g.height * 0.40, g.width * 0.31), 200), 360))
		y = g.y + g.height - self.hueco - alto
		self.set_size_request(g.width, alto)
		self.resize(g.width, alto)
		self.move(g.x, y)
		if self.get_realized():
			try:
				self.app.inyector.puntal(self.get_window().get_xid(), Gdk.Screen.get_default().get_height() - y,
										 g.x, g.x + g.width - 1)
			except (AttributeError, OSError):
				pass
		self.area.queue_draw()

	def mostrar(self):
		if self.get_visible():
			return
		self.pagina, self.mayus, self.acento = 'letras', 0, None
		try:
			self.app.inyector.abrir()   # por si se ha cambiado la distribución del teclado
		except (AttributeError, OSError):
			pass
		self.realize()
		self.colocar()
		self.show()
		GLib.idle_add(lambda: self.colocar() or False)

	# ── geometría de las teclas ──
	def distribuir(self, ancho, alto):
		margen, hueco = 6, 6
		util = min(ancho - 2 * margen, 1400)
		x0 = (ancho - util) / 2
		unidad = util / ANCHO_FILA
		filas = PAGINAS[self.pagina]
		alto_fila = (alto - 12 - hueco * (len(filas) - 1)) / len(filas)
		y = 8
		for fila in filas:
			x = x0
			for t in fila:
				t.caja = (x + hueco / 2, y, t.ancho * unidad - hueco, alto_fila)
				x += t.ancho * unidad
			y += alto_fila + hueco
		return alto_fila

	def tecla_en(self, x, y):
		for fila in PAGINAS[self.pagina]:
			for t in fila:
				tx, ty, tw, th = t.caja
				if tx - 3 <= x <= tx + tw + 3 and ty - 3 <= y <= ty + th + 3:
					return t
		return None

	# ── dibujo ──
	def pintar(self, area, cr):
		c = dict(COLORES[oscuro()])
		try:
			import aspecto
			c['acento'] = aspecto.acento()   # el color de acento elegido en Personalización
		except ImportError:
			pass
		ancho, alto = area.get_allocated_width(), area.get_allocated_height()
		cr.set_source_rgb(*rgb(c['fondo']))
		cr.paint()
		cr.set_source_rgb(*rgb(c['borde']))
		cr.rectangle(0, 0, ancho, 1)
		cr.fill()
		alto_fila = self.distribuir(ancho, alto)
		tam_letra = max(13, alto_fila * 0.36)
		for fila in PAGINAS[self.pagina]:
			for t in fila:
				self.pintar_tecla(cr, t, c, tam_letra)
		if self.variantes:
			self.pintar_variantes(cr, c, tam_letra)

	def estado_tecla(self, t):
		"""(fondo, color del texto) de cada tecla según lo que esté activo."""
		if t is self.pulsada and not self.variantes:
			return 'acento', 'sobre_acento'
		if t.tipo == 'shift':
			return ('acento', 'sobre_acento') if self.mayus == 2 else ('tecla', 'acento') if self.mayus == 1 else ('especial', 'texto')
		if t.tipo == 'acento' and self.acento:
			return 'tecla', 'acento'
		if t.tipo == 'k' and t.valor == 'Return':
			return 'acento', 'sobre_acento'
		return ('especial' if t.especial() else 'tecla'), 'texto'

	def pintar_tecla(self, cr, t, c, tam_letra):
		x, y, w, h = t.caja
		fondo, tinta = self.estado_tecla(t)
		rect_redondo(cr, x, y + 1.2, w, h, 4)
		cr.set_source_rgb(*rgb(c['sombra']))
		cr.fill()
		rect_redondo(cr, x, y, w, h, 4)
		cr.set_source_rgb(*rgb(c[fondo]))
		cr.fill()
		cr.set_source_rgb(*rgb(c[tinta]))
		cx, cy = x + w / 2, y + h / 2
		s = min(w, h) * 0.34
		if t.tipo == 'k' and t.valor == 'BackSpace':
			self.icono_borrar(cr, cx, cy, s)
		elif t.tipo == 'k' and t.valor == 'Return':
			self.icono_intro(cr, cx, cy, s)
		elif t.tipo == 'shift':
			self.icono_mayus(cr, cx, cy, s, relleno=self.mayus > 0, raya=self.mayus == 2)
		elif t.tipo == 'ocultar':
			self.icono_ocultar(cr, cx, cy, s)
		elif t.valor == ' ':
			self.texto(cr, 'espacio', cx, cy, tam_letra * 0.62, c['tenue'] if tinta == 'texto' else c[tinta])
		else:
			etiqueta = t.etiqueta
			if t.tipo == 'acento':
				etiqueta = '¨' if self.acento == 'dieresis' else '´'
			elif t.tipo == 'c' and self.pagina == 'letras':
				if self.mayus:
					etiqueta = etiqueta.upper()
				if self.acento and etiqueta in ACENTOS[self.acento]:
					etiqueta = ACENTOS[self.acento][etiqueta]
			pequena = t.tipo in ('p',) or (t.tipo == 'k' and len(etiqueta) > 1)
			self.texto(cr, etiqueta, cx, cy, tam_letra * (0.62 if pequena else 1), c[tinta])
			if t.tipo == 'c' and t.valor in VARIANTES:   # un puntito: esta tecla tiene más si la dejas pulsada
				cr.set_source_rgb(*rgb(c['tenue'] if tinta == 'texto' else c[tinta]))
				cr.arc(x + w - 7, y + 7, 1.6, 0, 2 * math.pi)
				cr.fill()

	def texto(self, cr, texto, cx, cy, px, color):
		capa = PangoCairo.create_layout(cr)
		fuente = Pango.FontDescription.from_string('Inter')
		fuente.set_absolute_size(px * Pango.SCALE)
		capa.set_font_description(fuente)
		capa.set_text(texto, -1)
		_tinta, logico = capa.get_pixel_extents()
		cr.set_source_rgb(*rgb(color))
		cr.move_to(cx - logico.width / 2 - logico.x, cy - logico.height / 2 - logico.y)
		PangoCairo.show_layout(cr, capa)

	# iconos dibujados (para no depender de que la fuente tenga ⌫ ⇧ ↵)
	@staticmethod
	def icono_borrar(cr, cx, cy, s):
		w, h = s * 2.2, s * 1.5
		x0, y0 = cx - w / 2, cy - h / 2
		cr.set_line_width(max(1.4, s * 0.13))
		cr.set_line_join(1)
		cr.move_to(x0, cy)
		cr.line_to(x0 + h * 0.5, y0)
		cr.line_to(x0 + w, y0)
		cr.line_to(x0 + w, y0 + h)
		cr.line_to(x0 + h * 0.5, y0 + h)
		cr.close_path()
		cr.stroke()
		mx, d = x0 + h * 0.5 + (w - h * 0.5) / 2, h * 0.22
		cr.move_to(mx - d, cy - d)
		cr.line_to(mx + d, cy + d)
		cr.move_to(mx + d, cy - d)
		cr.line_to(mx - d, cy + d)
		cr.stroke()

	@staticmethod
	def icono_intro(cr, cx, cy, s):
		cr.set_line_width(max(1.4, s * 0.13))
		cr.set_line_cap(1)
		cr.set_line_join(1)
		derecha, izquierda, arriba = cx + s * 0.9, cx - s * 0.9, cy - s * 0.7
		abajo = cy + s * 0.35
		cr.move_to(derecha, arriba)
		cr.line_to(derecha, abajo)
		cr.line_to(izquierda, abajo)
		cr.stroke()
		cr.move_to(izquierda + s * 0.45, abajo - s * 0.42)
		cr.line_to(izquierda, abajo)
		cr.line_to(izquierda + s * 0.45, abajo + s * 0.42)
		cr.stroke()

	@staticmethod
	def icono_mayus(cr, cx, cy, s, relleno=False, raya=False):
		cr.set_line_width(max(1.4, s * 0.13))
		cr.set_line_join(1)
		top = cy - s * 0.95
		cr.move_to(cx, top)
		cr.line_to(cx + s * 0.85, top + s * 0.85)
		cr.line_to(cx + s * 0.4, top + s * 0.85)
		cr.line_to(cx + s * 0.4, top + s * 1.55)
		cr.line_to(cx - s * 0.4, top + s * 1.55)
		cr.line_to(cx - s * 0.4, top + s * 0.85)
		cr.line_to(cx - s * 0.85, top + s * 0.85)
		cr.close_path()
		cr.fill() if relleno else cr.stroke()
		if raya:
			cr.rectangle(cx - s * 0.5, top + s * 1.8, s, max(1.6, s * 0.14))
			cr.fill()

	@staticmethod
	def icono_ocultar(cr, cx, cy, s):
		w, h = s * 2, s * 1.2
		x0, y0 = cx - w / 2, cy - h / 2 - s * 0.35
		cr.set_line_width(max(1.2, s * 0.11))
		rect_redondo(cr, x0, y0, w, h, 2)
		cr.stroke()
		paso = w / 5
		for fila in range(2):
			for i in range(4):
				cr.rectangle(x0 + paso * (i + 0.75), y0 + h * (0.25 + fila * 0.3), paso * 0.5, h * 0.16)
		cr.rectangle(x0 + w * 0.3, y0 + h * 0.8, w * 0.4, h * 0.1)
		cr.fill()
		cr.set_line_cap(1)
		yb = y0 + h + s * 0.35
		cr.move_to(cx - s * 0.35, yb)
		cr.line_to(cx, yb + s * 0.3)
		cr.line_to(cx + s * 0.35, yb)
		cr.stroke()

	def pintar_variantes(self, cr, c, tam_letra):
		_t, opciones, elegida = self.variantes
		if not opciones:
			return
		x0 = opciones[0][1][0]
		y0 = opciones[0][1][1]
		ancho = opciones[-1][1][0] + opciones[-1][1][2] - x0
		alto = opciones[0][1][3]
		rect_redondo(cr, x0 - 4, y0 - 4, ancho + 8, alto + 8, 6)
		cr.set_source_rgba(0, 0, 0, 0.25)
		cr.fill()
		rect_redondo(cr, x0 - 3, y0 - 3, ancho + 6, alto + 6, 5)
		cr.set_source_rgb(*rgb(c['tecla']))
		cr.fill()
		for i, (caracter, (x, y, w, h)) in enumerate(opciones):
			if i == elegida:
				rect_redondo(cr, x, y, w, h, 4)
				cr.set_source_rgb(*rgb(c['acento']))
				cr.fill()
			self.texto(cr, caracter, x + w / 2, y + h / 2, tam_letra, c['sobre_acento'] if i == elegida else c['texto'])

	# ── toques y clics ──
	def tocar(self, _w, e):
		secuencia = e.touch.sequence
		if e.type == Gdk.EventType.TOUCH_BEGIN:
			if self.toque is None:
				self.toque = secuencia
				self.pulsar(e.touch.x, e.touch.y)
		elif secuencia == self.toque:
			if e.type == Gdk.EventType.TOUCH_UPDATE:
				self.mover(e.touch.x, e.touch.y)
			elif e.type in (Gdk.EventType.TOUCH_END, Gdk.EventType.TOUCH_CANCEL):
				self.toque = None
				self.soltar(e.touch.x, e.touch.y)
		return True

	def parar(self):
		if self.temporizador:
			GLib.source_remove(self.temporizador)
			self.temporizador = None

	def pulsar(self, x, y):
		t = self.tecla_en(x, y)
		self.parar()
		self.pulsada = t
		if t is None:
			return True
		if t.tipo == 'k' and t.valor in REPITE:
			self.app.especial(t.valor)
			self.temporizador = GLib.timeout_add(450, self.empezar_repeticion, t)
		elif t.tipo == 'c' and t.valor in VARIANTES:
			self.temporizador = GLib.timeout_add(420, self.abrir_variantes, t)
		self.area.queue_draw()
		return True

	def empezar_repeticion(self, t):
		self.temporizador = GLib.timeout_add(65, self.repetir, t)
		return False

	def repetir(self, t):
		if self.pulsada is not t:
			self.temporizador = None
			return False
		self.app.especial(t.valor)
		return True

	def abrir_variantes(self, t):
		self.temporizador = None
		base = t.valor
		if self.pagina == 'letras' and self.mayus:
			base = base.upper()
		lista = VARIANTES[t.valor]
		if self.pagina == 'letras' and self.mayus:
			lista = lista.upper()
		x, y, w, h = t.caja
		ancho_total = self.area.get_allocated_width()
		n = len(lista)
		izq = min(max(4, x + w / 2 - n * w / 2), ancho_total - 4 - n * w)
		arriba = max(2, y - h - 6)
		opciones = [(car, (izq + i * w + 2, arriba, w - 4, h)) for i, car in enumerate(lista)]
		self.variantes = (t, opciones, 0)
		self.area.queue_draw()
		return False

	def mover(self, x, y):
		if self.variantes:
			t, opciones, elegida = self.variantes
			for i, (_c, (ox, _oy, ow, _oh)) in enumerate(opciones):
				if ox - 2 <= x <= ox + ow + 2:
					elegida = i
			if elegida != self.variantes[2]:
				self.variantes = (t, opciones, elegida)
				self.area.queue_draw()
			return True
		if self.pulsada is not None:
			t = self.tecla_en(x, y)
			if t is not self.pulsada and t is not None:
				self.parar()
				self.pulsada = t   # el dedo resbala a otra tecla: vale la de debajo, como en el móvil
				self.area.queue_draw()
		return True

	def soltar(self, x, y):
		self.parar()
		if self.variantes:
			_t, opciones, elegida = self.variantes
			self.variantes = None
			self.pulsada = None
			self.escribir(opciones[elegida][0], ya_hecho=True)
		else:
			t, self.pulsada = self.pulsada, None
			if t is not None and not (t.tipo == 'k' and t.valor in REPITE):
				self.activar(t)
		self.area.queue_draw()
		return True

	def activar(self, t):
		if t.tipo == 'c':
			self.escribir(t.valor)
		elif t.tipo == 'k':
			self.app.especial(t.valor)
		elif t.tipo == 'shift':
			ahora = time.monotonic()
			if self.mayus == 0:
				self.mayus = 1
			elif self.mayus == 1:
				self.mayus = 2 if ahora - self.ultimo_shift < 0.45 else 0
			else:
				self.mayus = 0
			self.ultimo_shift = ahora
		elif t.tipo == 'acento':
			self.acento = {None: 'agudo', 'agudo': 'dieresis', 'dieresis': None}[self.acento]
		elif t.tipo == 'p':
			self.pagina = t.valor
		elif t.tipo == 'ocultar':
			self.app.ocultar()

	def escribir(self, caracter, ya_hecho=False):
		if not ya_hecho and self.pagina == 'letras':
			if self.mayus:
				caracter = caracter.upper()
			if self.acento:
				caracter = ACENTOS[self.acento].get(caracter, caracter)
		self.acento = None
		if self.mayus == 1 and caracter.strip():
			self.mayus = 0
		self.app.escribir(caracter)


# ─── Aplicación: el teclado, su botón en la bandeja y las órdenes ───────────────────────────────────────────────

class AppTeclado(Gtk.Application):
	def __init__(self):
		super().__init__(application_id='org.mandarinos.Teclado', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
		self.ventana = None
		self.inyector = None
		self.fondo = False
		self.icono = None
		self.tableta_antes = False
		self.vigilantes = []

	def do_startup(self):
		Gtk.Application.do_startup(self)
		try:
			self.inyector = Inyector()
		except OSError as e:
			print('mandarin-teclado: no se puede escribir en las ventanas:', e, file=sys.stderr)
		self.ventana = Teclado(self)
		self.add_window(self.ventana)

	def do_command_line(self, linea):
		args = linea.get_arguments()[1:]
		if '--fondo' in args:
			if not self.fondo:
				self.fondo = True
				self.hold()
				self.preparar_bandeja()
		elif '--ocultar' in args:
			self.ocultar()
		elif '--mostrar' in args:
			self.mostrar()
		else:
			self.alternar()
		return 0

	def escribir(self, texto):
		if self.inyector:
			self.inyector.escribir(texto)

	def especial(self, nombre):
		if self.inyector:
			self.inyector.especial(nombre)

	def mostrar(self):
		self.ventana.mostrar()

	def ocultar(self):
		self.ventana.hide()
		if not self.fondo:
			self.quit()   # abierto suelto (sin el servicio de la sesión): no se queda gastando memoria

	def alternar(self):
		self.ocultar() if self.ventana.get_visible() else self.mostrar()

	# ── botón en la bandeja (junto a la red, el volumen y la batería) ──
	def preparar_bandeja(self):
		self.icono = Gtk.StatusIcon.new_from_icon_name('mandarin-teclado')
		self.icono.set_title('Teclado táctil')
		self.icono.set_tooltip_text('Teclado táctil')
		self.icono.connect('activate', lambda *_: self.alternar())
		self.icono.connect('popup-menu', self.menu_bandeja)
		for ruta in (BOTON, TABLETA):
			vigilante = Gio.File.new_for_path(ruta).monitor_file(Gio.FileMonitorFlags.NONE, None)
			vigilante.connect('changed', lambda *_: self.actualizar_bandeja())
			self.vigilantes.append(vigilante)
		GLib.timeout_add_seconds(5, self.actualizar_bandeja)   # por si /run/mandarin aún no existía
		self.actualizar_bandeja()

	def actualizar_bandeja(self, *_):
		pref, tableta = preferencia(), en_tableta()
		self.icono.set_visible(pref == 'siempre' or (pref == 'tableta' and tableta))
		if self.tableta_antes and not tableta and self.ventana.get_visible():
			self.ventana.hide()   # al volver a abrir el portátil sobra el teclado de la pantalla
		self.tableta_antes = tableta
		return True

	def menu_bandeja(self, icono, boton, tiempo):
		menu = Gtk.Menu()
		for texto, accion in (('Esconder el teclado' if self.ventana.get_visible() else 'Abrir el teclado', self.alternar),
							  ('Configuración del teclado táctil…', lambda: ejecutar('mandarin-panel', 'teclado'))):
			item = Gtk.MenuItem(label=texto)
			item.connect('activate', lambda _i, a=accion: a())
			menu.append(item)
		menu.show_all()
		menu.popup(None, None, Gtk.StatusIcon.position_menu, icono, boton, tiempo)


if __name__ == '__main__':
	sys.exit(AppTeclado().run(sys.argv))
