#!/usr/bin/env python3
"""Mandarin OS · Propiedades de archivos, carpetas y unidades, como la ventana de Windows.

Archivos y carpetas: General (nombre, tipo, «Se abre con», ubicación, tamaño, fechas, atributos) y Permisos.
Unidades: General (espacio usado y disponible con su rosco, «Liberar espacio») y Hardware (disco, conexión…).
La abren el explorador (clic derecho › Propiedades, Alt+Intro, Este equipo) y el escritorio (DisplayFileProperties).

Uso suelto, para probar: python3 propiedades.py <ruta|uri>...
"""
import grp
import math
import os
import pwd
import shlex
import shutil
import stat
import subprocess
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import DIAS, Gdk, Gio, GLib, Gtk, cargar_css, clase, etiqueta, oscuro, tam  # noqa: E402
import gi  # noqa: E402

gi.require_version('PangoCairo', '1.0')
from gi.repository import Pango, PangoCairo  # noqa: E402

NARANJA = (0xf2 / 255, 0x6b / 255, 0x1d / 255)
CSS = b"""
.p-clave { opacity: 0.72; }
.p-cabecera { font-family: "Inter Display", "Inter", sans-serif; font-weight: 500; font-size: 11pt; }
.p-pagina { padding: 4px; }
"""
SISTEMAS = {'vfat': 'FAT32', 'msdos': 'FAT', 'exfat': 'exFAT', 'ntfs': 'NTFS', 'ntfs3': 'NTFS', 'fuseblk': 'NTFS',
			'ext2': 'ext2', 'ext3': 'ext3', 'ext4': 'ext4', 'btrfs': 'Btrfs', 'xfs': 'XFS', 'iso9660': 'CDFS', 'udf': 'UDF',
			'overlay': 'overlay (sistema en vivo)', 'squashfs': 'SquashFS'}
CONEXIONES = {'sata': 'SATA', 'ata': 'IDE / ATA', 'usb': 'USB', 'nvme': 'NVMe', 'mmc': 'Tarjeta SD / MMC', 'scsi': 'SCSI',
			  'virtio': 'Virtual (máquina virtual)'}
_css_puesto = False


def poner_css():
	global _css_puesto
	if not _css_puesto:
		p = Gtk.CssProvider()
		p.load_from_data(CSS)
		Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
		_css_puesto = True


def gris_libre():
	return (0.36, 0.36, 0.39) if oscuro() else (0.86, 0.86, 0.88)


def bytes_largo(n):
	return f'{n:,} bytes'.replace(',', '.')


def tam_doble(n):
	"""«1,2 MB (1.258.291 bytes)», como Windows."""
	return bytes_largo(n) if n < 1024 else f'{tam(n)} ({bytes_largo(n)})'


MESES = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre',
		 'diciembre')


def fecha_larga(segundos):
	"""«sábado, 14 de noviembre de 2026, 17:25:03» (en español aunque el sistema esté en otro idioma)."""
	if not segundos:
		return 'No disponible'
	f = GLib.DateTime.new_from_unix_local(int(segundos))
	return f"{DIAS[f.get_day_of_week() - 1]}, {f.get_day_of_month()} de {MESES[f.get_month() - 1]} de {f.get_year()}, {f.format('%H:%M:%S')}"


def plural(n, uno, varios):
	return f'1 {uno}' if n == 1 else f'{n} {varios}'


def montajes():
	"""{punto de montaje: (dispositivo, sistema de archivos, opciones)} según /proc/self/mounts."""
	def limpio(s):
		return s.replace('\\040', ' ').replace('\\011', '\t').replace('\\134', '\\')
	res = {}
	try:
		with open('/proc/self/mounts') as f:
			for linea in f:
				p = linea.split()
				if len(p) >= 4:
					res[limpio(p[1])] = (limpio(p[0]), p[2], p[3].split(','))
	except OSError:
		pass
	return res


def es_unidad(ruta):
	"""La raíz de un disco: «/» o lo montado en /media, /run/media o /mnt (lo que Este equipo enseña como unidad)."""
	return ruta == '/' or (os.path.ismount(ruta) and ruta.startswith(('/media/', '/run/media/', '/mnt/')))


def datos_disco(dispositivo):
	"""Modelo, conexión, tipo y tamaño del disco donde está una partición (lsblk)."""
	if not dispositivo.startswith('/dev/'):
		return {}
	try:
		pk = subprocess.run(['lsblk', '-ndo', 'PKNAME', dispositivo], capture_output=True, text=True, timeout=3).stdout.strip()
		disco = f'/dev/{pk}' if pk else dispositivo
		salida = subprocess.run(['lsblk', '-bndPo', 'MODEL,VENDOR,TRAN,ROTA,SIZE,RM', disco], capture_output=True, text=True,
								timeout=3).stdout
	except (OSError, subprocess.SubprocessError):
		return {}
	datos = {'DISCO': disco}
	for par in shlex.split(salida):
		clave, _, valor = par.partition('=')
		datos[clave] = valor.strip()
	return datos


class Medida:
	"""Cuenta archivos, carpetas y bytes (en un hilo: las carpetas grandes tardan); la ventana lo lee cada poco.
	No sale del disco de cada carpeta (como Windows con las unidades montadas dentro)."""

	def __init__(self, rutas, carpetas=0, hilo=True):
		self.archivos, self.carpetas, self.bytes, self.disco = 0, carpetas, 0, 0
		self.fin = self.parar = False
		if hilo:
			threading.Thread(target=self.medir, args=(list(rutas),), daemon=True).start()
		else:
			self.medir(rutas)

	def sumar(self, st):
		self.archivos += 1
		self.bytes += st.st_size
		self.disco += st.st_blocks * 512

	def medir(self, rutas):
		pila = []
		for r in rutas:
			try:
				st = os.lstat(r)
			except OSError:
				continue
			if stat.S_ISDIR(st.st_mode):
				pila.append((r, st.st_dev))
			else:
				self.sumar(st)
		while pila and not self.parar:
			carpeta, disco = pila.pop()
			try:
				with os.scandir(carpeta) as entradas:
					for e in entradas:
						try:
							st = e.stat(follow_symlinks=False)
						except OSError:
							continue
						if stat.S_ISDIR(st.st_mode):
							if st.st_dev == disco:
								self.carpetas += 1
								pila.append((e.path, disco))
						else:
							self.sumar(st)
			except OSError:
				pass
		self.fin = True

	def contiene(self):
		return f"{plural(self.archivos, 'archivo', 'archivos')}, {plural(self.carpetas, 'carpeta', 'carpetas')}"


class Rejilla(Gtk.Grid):
	"""Página de dos columnas, «Clave:  valor», con líneas de separación (la maquetación de Windows)."""

	def __init__(self):
		super().__init__(column_spacing=18, row_spacing=8, margin=14)
		self.n = 0

	def fila(self, clave, valor):
		if isinstance(valor, str):
			valor = etiqueta(valor)
			valor.set_line_wrap(True)
			valor.set_max_width_chars(34)
		k = clase(etiqueta(clave), 'p-clave')
		k.set_valign(Gtk.Align.START)
		self.attach(k, 0, self.n, 1, 1)
		self.attach(valor, 1, self.n, 1, 1)
		self.n += 1
		return valor

	def cabecera(self, imagen, widget):
		imagen.set_halign(Gtk.Align.START)
		self.attach(imagen, 0, self.n, 1, 1)
		widget.set_hexpand(True)
		widget.set_valign(Gtk.Align.CENTER)
		self.attach(widget, 1, self.n, 1, 1)
		self.n += 1

	def separador(self):
		self.attach(Gtk.Separator(margin_top=2, margin_bottom=2), 0, self.n, 2, 1)
		self.n += 1

	def todo(self, widget):
		self.attach(widget, 0, self.n, 2, 1)
		self.n += 1
		return widget


def cuadro(color):
	"""El cuadradito de color de «Espacio usado / disponible»."""
	a = Gtk.DrawingArea(valign=Gtk.Align.CENTER)
	a.set_size_request(13, 13)

	def pintar(_a, cr):
		cr.rectangle(0.5, 0.5, 12, 12)
		cr.set_source_rgb(*color)
		cr.fill_preserve()
		cr.set_source_rgba(0, 0, 0, 0.3)
		cr.set_line_width(1)
		cr.stroke()
	a.connect('draw', pintar)
	return a


class Rosco(Gtk.DrawingArea):
	"""El gráfico de la unidad: anillo naranja (usado) sobre gris (libre) y el porcentaje en medio."""

	def __init__(self, parte):
		super().__init__(halign=Gtk.Align.CENTER)
		self.parte = max(0.0, min(parte, 1.0))
		self.set_size_request(150, 150)
		self.connect('draw', self.pintar)

	def pintar(self, _a, cr):
		w, h = self.get_allocated_width(), self.get_allocated_height()
		r = min(w, h) / 2 - 2
		grosor = r * 0.36
		radio = r - grosor / 2
		cx, cy = w / 2, h / 2
		cr.set_line_width(grosor)
		cr.set_source_rgb(*gris_libre())
		cr.arc(cx, cy, radio, 0, 2 * math.pi)
		cr.stroke()
		if self.parte > 0:
			cr.set_source_rgb(*NARANJA)
			cr.arc(cx, cy, radio, -math.pi / 2, -math.pi / 2 + 2 * math.pi * self.parte)
			cr.stroke()
		c = self.get_style_context().get_color(Gtk.StateFlags.NORMAL)
		cr.set_source_rgba(c.red, c.green, c.blue, c.alpha)
		capa = PangoCairo.create_layout(cr)
		capa.set_font_description(Pango.FontDescription.from_string('Inter Display Light 17'))
		capa.set_text(f'{round(self.parte * 100)} %', -1)
		ancho, alto = capa.get_pixel_size()
		cr.move_to(cx - ancho / 2, cy - alto / 2)
		PangoCairo.show_layout(cr, capa)


class Propiedades(Gtk.Window):
	def __init__(self, archivos, padre=None, app=None, montaje=None):
		super().__init__(transient_for=padre, type_hint=Gdk.WindowTypeHint.DIALOG, resizable=False)
		poner_css()
		if app is not None:
			self.set_application(app)
		self.archivos = archivos
		self.montaje = montaje
		self.cambios = {}   # lo cambiado → función que lo guarda (Aceptar / Aplicar)
		self.medida = None
		self.c_permisos, self.c_ejecutar = [], None
		self.set_icon_name('document-properties')
		self.set_position(Gtk.WindowPosition.CENTER_ON_PARENT if padre else Gtk.WindowPosition.CENTER)
		self.set_default_size(400, -1)
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=10)
		self.add(caja)
		self.libro = Gtk.Notebook()
		caja.pack_start(self.libro, True, True, 0)
		botones = Gtk.Box(spacing=6, halign=Gtk.Align.END)
		caja.pack_start(botones, False, False, 0)
		for texto, f in (('Aceptar', self.aceptar), ('Cancelar', self.destroy), ('Aplicar', self.aplicar)):
			b = Gtk.Button(label=texto)
			b.set_size_request(88, -1)
			b.connect('clicked', lambda _b, f=f: f())
			botones.pack_start(b, False, False, 0)
		self.b_aplicar = b
		self.b_aplicar.set_sensitive(False)
		self.connect('destroy', self.cerrar)
		self.connect('key-press-event', self.tecla)

		ruta = archivos[0].get_path() if len(archivos) == 1 else None
		if montaje is not None or (ruta and es_unidad(ruta)):
			self.unidad(archivos[0])
		elif len(archivos) == 1:
			self.uno(archivos[0])
		else:
			self.varios(archivos)
		self.show_all()

	# ---------- guardar ----------
	def tecla(self, _w, ev):
		if ev.keyval == Gdk.KEY_Escape:
			self.destroy()
			return True
		return False

	def cambio(self, clave, guardar):
		self.cambios[clave] = guardar
		self.b_aplicar.set_sensitive(True)

	def aplicar(self):
		# el nombre se cambia lo último: lo demás aún usa la ruta de antes
		for clave in sorted(self.cambios, key=lambda c: c == 'nombre'):
			try:
				self.cambios[clave]()
			except (GLib.Error, OSError) as e:
				d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.WARNING,
									  buttons=Gtk.ButtonsType.OK, text='No se ha podido guardar el cambio.')
				d.format_secondary_text(getattr(e, 'message', None) or e.strerror or str(e))
				d.run()
				d.destroy()
				return False
		self.cambios.clear()
		self.b_aplicar.set_sensitive(False)
		return True

	def aceptar(self):
		if self.aplicar():
			self.destroy()

	def cerrar(self, *_a):
		if self.medida:
			self.medida.parar = True
			self.medida = None

	def medir(self, rutas, carpetas=0):
		self.medida = m = Medida(rutas, carpetas)

		def mirar():
			if self.medida is not m:
				return False
			self.l_tam.set_text(tam_doble(m.bytes) + ('' if m.fin else '…'))
			self.l_disco.set_text(tam_doble(m.disco) + ('' if m.fin else '…'))
			self.l_contiene.set_text(m.contiene())
			return not m.fin
		GLib.timeout_add(200, mirar)

	# ---------- un archivo o una carpeta ----------
	def uno(self, f):
		try:
			info = f.query_info('standard::*,time::*,unix::*,access::*', Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None)
		except GLib.Error as e:
			self.set_title('Propiedades')
			self.libro.append_page(Rejilla().todo(etiqueta(e.message)), Gtk.Label(label='General'))
			return
		es_dir = info.get_file_type() == Gio.FileType.DIRECTORY
		enlace = info.get_is_symlink()
		nombre = info.get_display_name()
		self.set_title(f'Propiedades de {nombre}')
		local = f.get_path() is not None and info.has_attribute('unix::mode')
		permisos = self.permisos(info, es_dir) if local and not enlace else None

		r = Rejilla()
		img = Gtk.Image.new_from_gicon(info.get_icon(), Gtk.IconSize.DIALOG)
		img.set_pixel_size(32)
		self.e_nombre = Gtk.Entry(text=nombre)
		self.e_nombre.set_sensitive(info.get_attribute_boolean('access::can-rename'))
		self.e_nombre.connect('changed', lambda _e: self.cambio('nombre', self.guardar_nombre))
		r.cabecera(img, self.e_nombre)
		r.separador()
		tipo = info.get_content_type() or ''
		if enlace:
			r.fila('Tipo:', f'Acceso directo a {info.get_symlink_target()}')
		elif es_dir:
			r.fila('Tipo:', 'Carpeta de archivos')
		else:
			desc = Gio.content_type_get_description(tipo) if tipo else 'Archivo'
			ext = os.path.splitext(nombre)[1]
			r.fila('Tipo de archivo:', f'{desc} ({ext})' if ext else desc)
			if tipo:
				r.fila('Se abre con:', self.se_abre_con(f, tipo))
		r.separador()
		padre = f.get_parent()
		r.fila('Ubicación:', padre.get_parse_name() if padre else '')
		if es_dir:
			self.l_tam = r.fila('Tamaño:', 'Calculando…')
			self.l_disco = r.fila('Tamaño en disco:', 'Calculando…')
			self.l_contiene = r.fila('Contiene:', 'Calculando…')
			if f.get_path():
				self.medir([f.get_path()])
			else:
				for l in (self.l_tam, self.l_disco, self.l_contiene):
					l.set_text('No disponible')
		else:
			r.fila('Tamaño:', tam_doble(info.get_size()))
			if info.has_attribute('unix::blocks'):
				r.fila('Tamaño en disco:', tam_doble(info.get_attribute_uint64('unix::blocks') * 512))
		r.separador()
		r.fila('Creado:', fecha_larga(info.get_attribute_uint64('time::created') if info.has_attribute('time::created') else 0))
		r.fila('Modificado:', fecha_larga(info.get_attribute_uint64('time::modified')))
		r.fila('Último acceso:', fecha_larga(info.get_attribute_uint64('time::access')))
		r.separador()
		r.fila('Atributos:', self.atributos(f, info, nombre, permisos is not None))
		self.libro.append_page(r, Gtk.Label(label='General'))
		if permisos is not None:
			self.libro.append_page(permisos, Gtk.Label(label='Permisos'))

	def guardar_nombre(self):
		nuevo = self.e_nombre.get_text().strip()
		f = self.archivos[0]
		if not nuevo:
			raise OSError(0, 'El nombre no puede quedar vacío.')
		if '/' in nuevo:
			raise OSError(0, 'El nombre no puede llevar «/».')
		if nuevo != f.get_basename():
			self.archivos[0] = f.set_display_name(nuevo, None)
			self.set_title(f'Propiedades de {nuevo}')

	def se_abre_con(self, f, tipo):
		caja = Gtk.Box(spacing=6)
		img = Gtk.Image()
		img.set_pixel_size(16)
		nombre = etiqueta('', elipsis=True)

		def pintar():
			app = Gio.AppInfo.get_default_for_type(tipo, False)
			if app:
				img.set_from_gicon(app.get_icon() or Gio.ThemedIcon.new('application-x-executable'), Gtk.IconSize.MENU)
				nombre.set_text(app.get_display_name())
			else:
				img.clear()
				nombre.set_text('Sin programa asociado')

		def elegir(_b):
			d = Gtk.AppChooserDialog.new(self, Gtk.DialogFlags.MODAL, f)
			if d.run() == Gtk.ResponseType.OK and d.get_app_info():
				try:
					d.get_app_info().set_as_default_for_type(tipo)
				except GLib.Error:
					pass
				pintar()
			d.destroy()
		pintar()
		cambiar = Gtk.Button(label='Cambiar…')
		cambiar.connect('clicked', elegir)
		caja.pack_start(img, False, False, 0)
		caja.pack_start(nombre, True, True, 0)
		caja.pack_end(cambiar, False, False, 0)
		return caja

	def atributos(self, f, info, nombre, local):
		caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
		modo = info.get_attribute_uint32('unix::mode')
		solo = Gtk.CheckButton(label='Solo lectura', active=local and not (modo & stat.S_IWUSR))
		solo.set_sensitive(bool(self.c_permisos) and self.c_permisos[0].get_sensitive())
		# «Solo lectura» es el permiso del propietario (pestaña Permisos)
		solo.connect('toggled', lambda b: self.c_permisos[0].set_active_id('r' if b.get_active() else 'rw'))
		con_punto = nombre.startswith('.')
		oculto = Gtk.CheckButton(label='Oculto', active=con_punto or info.get_is_hidden())
		padre = f.get_parent()
		oculto.set_sensitive(not con_punto and padre is not None and padre.get_path() is not None)
		if con_punto:
			oculto.set_tooltip_text('Su nombre empieza por un punto: en Linux eso lo oculta siempre.')
		oculto.connect('toggled', lambda b: self.cambio('oculto', lambda: self.guardar_oculto(b.get_active())))
		caja.pack_start(solo, False, False, 0)
		caja.pack_start(oculto, False, False, 0)
		return caja

	def guardar_oculto(self, si):
		"""Oculto sin cambiar el nombre: el archivo .hidden de la carpeta (lo respetan el explorador y GTK)."""
		f = self.archivos[0]
		lista = os.path.join(f.get_parent().get_path(), '.hidden')
		try:
			with open(lista) as h:
				nombres = [n.rstrip('\n') for n in h if n.strip()]
		except FileNotFoundError:
			nombres = []
		nombre = f.get_basename()
		nombres = [n for n in nombres if n != nombre] + ([nombre] if si else [])
		if nombres:
			with open(lista, 'w') as h:
				h.write('\n'.join(nombres) + '\n')
		elif os.path.exists(lista):
			os.remove(lista)

	def permisos(self, info, es_dir):
		r = Rejilla()
		uid, gid = info.get_attribute_uint32('unix::uid'), info.get_attribute_uint32('unix::gid')
		modo = info.get_attribute_uint32('unix::mode')
		try:
			dueno = pwd.getpwuid(uid).pw_name
		except KeyError:
			dueno = str(uid)
		try:
			grupo = grp.getgrgid(gid).gr_name
		except KeyError:
			grupo = str(gid)
		r.fila('Propietario:', dueno)
		r.fila('Grupo:', grupo)
		r.separador()
		puede = os.getuid() in (0, uid)
		opciones = (('rw', 'Ver y modificar' if es_dir else 'Lectura y escritura'), ('r', 'Solo ver' if es_dir else 'Solo lectura'),
					('n', 'Ninguno'))
		for quien, corrimiento in (('Propietario', 6), ('Grupo', 3), ('Otros usuarios', 0)):
			c = Gtk.ComboBoxText()
			for id_, texto in opciones:
				c.append(id_, texto)
			bits = (modo >> corrimiento) & 7
			c.set_active_id('rw' if bits & 2 else ('r' if bits & 4 else 'n'))
			c.set_sensitive(puede)
			c.connect('changed', lambda *_a: self.cambio('permisos', lambda: self.guardar_permisos(es_dir)))
			r.fila(f'{quien}:', c)
			self.c_permisos.append(c)
		if not es_dir:
			r.separador()
			self.c_ejecutar = Gtk.CheckButton(label='Permitir ejecutarlo como un programa', active=bool(modo & stat.S_IXUSR))
			self.c_ejecutar.set_sensitive(puede)
			self.c_ejecutar.connect('toggled', lambda *_a: self.cambio('permisos', lambda: self.guardar_permisos(es_dir)))
			r.todo(self.c_ejecutar)
		if not puede:
			nota = clase(etiqueta(f'Solo {dueno} (su propietario) o un administrador pueden cambiarlos.'), 'm-pie', 'm-tenue')
			nota.set_line_wrap(True)
			r.todo(nota)
		r.get_style_context().add_class('p-pagina')
		return r

	def guardar_permisos(self, es_dir):
		ruta = self.archivos[0].get_path()
		modo = stat.S_IMODE(os.lstat(ruta).st_mode)
		nuevo = modo & 0o7000
		for c, corrimiento in zip(self.c_permisos, (6, 3, 0)):
			bits = {'rw': 6, 'r': 4, 'n': 0}[c.get_active_id()]
			if bits and (es_dir or (self.c_ejecutar and self.c_ejecutar.get_active())):
				bits |= 1   # carpetas: poder entrar; programas: poder ejecutarlos
			nuevo |= bits << corrimiento
		os.chmod(ruta, nuevo)

	# ---------- varios a la vez ----------
	def varios(self, archivos):
		infos = []
		for f in archivos:
			try:
				infos.append(f.query_info('standard::*', Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None))
			except GLib.Error:
				pass
		carpetas = sum(1 for i in infos if i.get_file_type() == Gio.FileType.DIRECTORY)
		sueltos = len(infos) - carpetas
		texto = ', '.join(p for p in (plural(sueltos, 'archivo', 'archivos') if sueltos else '',
									  plural(carpetas, 'carpeta', 'carpetas') if carpetas else '') if p)
		self.set_title(f'Propiedades de {texto}')
		r = Rejilla()
		img = Gtk.Image.new_from_icon_name('edit-copy', Gtk.IconSize.DIALOG)
		img.set_pixel_size(32)
		r.cabecera(img, clase(etiqueta(texto), 'p-cabecera'))
		r.separador()
		tipos = {i.get_content_type() for i in infos}
		if not carpetas and len(tipos) == 1 and None not in tipos:
			r.fila('Tipo:', f'Todos del tipo {Gio.content_type_get_description(tipos.pop())}')
		elif carpetas and not sueltos:
			r.fila('Tipo:', 'Carpetas de archivos')
		else:
			r.fila('Tipo:', 'Varios tipos')
		padres = {f.get_parent().get_uri() if f.get_parent() else '' for f in archivos}
		padre = archivos[0].get_parent()
		r.fila('Ubicación:', f'Todo en {padre.get_parse_name()}' if len(padres) == 1 and padre else 'Varias ubicaciones')
		r.separador()
		self.l_tam = r.fila('Tamaño:', 'Calculando…')
		self.l_disco = r.fila('Tamaño en disco:', 'Calculando…')
		self.l_contiene = r.fila('Contiene:', 'Calculando…')
		self.medir([f.get_path() for f in archivos if f.get_path()], carpetas)
		self.libro.append_page(r, Gtk.Label(label='General'))

	# ---------- unidades ----------
	def unidad(self, raiz):
		ruta = raiz.get_path() or '/'
		montaje = self.montaje
		if montaje is None and ruta != '/':
			try:
				montaje = raiz.find_enclosing_mount(None)
			except GLib.Error:
				montaje = None
		self.montaje = montaje
		dispositivo, sistema, opciones = montajes().get(ruta, ('', '', []))
		try:
			info = raiz.query_filesystem_info('filesystem::*', None)
		except GLib.Error:
			info = None
		total = info.get_attribute_uint64('filesystem::size') if info else 0
		libre = info.get_attribute_uint64('filesystem::free') if info else 0
		usado = max(0, total - libre)
		sistema = sistema or (info.get_attribute_string('filesystem::type') if info else '') or ''
		hw = datos_disco(dispositivo)
		nombre = montaje.get_name() if montaje else ('Disco local (/)' if ruta == '/' else os.path.basename(ruta))
		self.set_title(f'Propiedades de {nombre}')

		if sistema in ('overlay', 'squashfs', 'tmpfs'):
			tipo = 'Sistema en vivo (desde el USB o DVD)'
		elif sistema in ('iso9660', 'udf'):
			tipo = 'Unidad de CD / DVD'
		elif sistema.startswith(('nfs', 'cifs', 'smb', 'fuse.sshfs')):
			tipo = 'Unidad de red'
		elif hw.get('TRAN') == 'usb' or hw.get('RM') == '1' or (montaje is not None and montaje.can_eject()):
			tipo = 'Unidad extraíble'
		else:
			tipo = 'Disco local'

		r = Rejilla()
		if montaje is not None and montaje.get_icon():
			img = Gtk.Image.new_from_gicon(montaje.get_icon(), Gtk.IconSize.DIALOG)
		else:
			img = Gtk.Image.new_from_icon_name('drive-harddisk', Gtk.IconSize.DIALOG)
		img.set_pixel_size(32)
		r.cabecera(img, clase(etiqueta(nombre), 'p-cabecera'))
		r.separador()
		r.fila('Tipo:', tipo)
		r.fila('Sistema de archivos:', SISTEMAS.get(sistema, sistema.upper() or 'Desconocido'))
		r.separador()
		espacio = Gtk.Grid(column_spacing=14, row_spacing=8)
		filas = ((cuadro(NARANJA), 'Espacio usado:', usado), (cuadro(gris_libre()), 'Espacio disponible:', libre), None,
				 (None, 'Capacidad:', total))
		for i, fila in enumerate(filas):
			if fila is None:
				espacio.attach(Gtk.Separator(margin_top=2, margin_bottom=2), 0, i, 4, 1)
				continue
			muestra, texto, n = fila
			if muestra is not None:
				espacio.attach(muestra, 0, i, 1, 1)
			espacio.attach(clase(etiqueta(texto), 'p-clave'), 1, i, 1, 1)
			espacio.attach(etiqueta(bytes_largo(n), xalign=1.0, ), 2, i, 1, 1)
			espacio.attach(etiqueta(tam(n) if n else '0 bytes', xalign=1.0), 3, i, 1, 1)
		espacio.get_child_at(2, 0).set_hexpand(True)
		r.todo(espacio)
		r.todo(Rosco(usado / total if total else 0)).set_margin_top(6)
		pie = Gtk.Box()
		pie.set_center_widget(etiqueta(f'Unidad {ruta}' if ruta == '/' else nombre, 'm-pie'))
		casa = os.path.expanduser('~')
		try:
			misma = os.stat(casa).st_dev == os.stat(ruta).st_dev
		except OSError:
			misma = False
		if misma:   # donde está tu carpeta personal: papelera y miniaturas se pueden vaciar desde aquí
			liberar = Gtk.Button(label='Liberar espacio')
			liberar.connect('clicked', self.liberar)
			pie.pack_end(liberar, False, False, 0)
		r.todo(pie)
		self.libro.append_page(r, Gtk.Label(label='General'))
		self.libro.append_page(self.hardware(dispositivo, ruta, opciones, hw, montaje), Gtk.Label(label='Hardware'))

	def hardware(self, dispositivo, ruta, opciones, hw, montaje):
		r = Rejilla()
		modelo = ' '.join(p for p in (hw.get('VENDOR', ''), hw.get('MODEL', '')) if p)
		r.fila('Disco:', modelo or 'Desconocido')
		if hw.get('TRAN'):
			r.fila('Conexión:', CONEXIONES.get(hw['TRAN'], hw['TRAN'].upper()))
		if hw.get('ROTA') in ('0', '1') and hw.get('TRAN') != 'usb':
			r.fila('Tecnología:', 'SSD (estado sólido)' if hw['ROTA'] == '0' else 'Disco duro (de platos)')
		if hw.get('SIZE', '').isdigit():
			r.fila('Tamaño del disco:', tam(int(hw['SIZE'])))
		r.separador()
		r.fila('Partición:', dispositivo or 'Desconocida')
		r.fila('Montada en:', ruta)
		r.fila('Acceso:', 'Solo lectura' if 'ro' in opciones else 'Lectura y escritura')
		if montaje is not None and (montaje.can_eject() or montaje.can_unmount()):
			r.separador()
			b = Gtk.Button(label='Expulsar' if montaje.can_eject() else 'Desmontar', halign=Gtk.Align.START)
			b.connect('clicked', lambda *_a: expulsar(montaje, self, lambda: self.destroy()))
			r.todo(b)
		return r

	def liberar(self, boton):
		papelera = os.path.join(GLib.get_user_data_dir(), 'Trash')
		miniaturas = os.path.join(GLib.get_user_cache_dir(), 'thumbnails')
		boton.set_sensitive(False)
		boton.set_label('Calculando…')

		def medir():
			res = [Medida([d], hilo=False).disco for d in (papelera, miniaturas)]
			GLib.idle_add(preguntar, res)

		def preguntar(res):
			boton.set_label('Liberar espacio')
			boton.set_sensitive(True)
			total = sum(res)
			if total < 1024:
				d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
									  buttons=Gtk.ButtonsType.OK, text='No hay nada que limpiar.')
				d.format_secondary_text('La papelera y las miniaturas guardadas ya están vacías.')
				d.run()
				d.destroy()
				return False
			d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
								  buttons=Gtk.ButtonsType.OK_CANCEL, text=f'Se pueden liberar {tam(total)}')
			d.format_secondary_text(f'Papelera: {tam(res[0])}\nMiniaturas de imágenes (se vuelven a crear solas): {tam(res[1])}\n\n'
									'Lo que hay en la papelera se borrará para siempre.')
			if d.run() == Gtk.ResponseType.OK:
				subprocess.run(['gio', 'trash', '--empty'], check=False)
				shutil.rmtree(miniaturas, ignore_errors=True)
				mostrar(self.archivos, self.get_transient_for(), self.get_application(), self.montaje)
				self.destroy()
			d.destroy()
			return False
		threading.Thread(target=medir, daemon=True).start()


def expulsar(montaje, ventana=None, despues=None):
	"""Expulsa (o desmonta) una unidad; si algo la está usando, lo dice."""
	def hecho(m, res):
		try:
			(m.eject_with_operation_finish if m.can_eject() else m.unmount_with_operation_finish)(res)
			if despues:
				despues()
		except GLib.Error as e:
			d = Gtk.MessageDialog(transient_for=ventana, modal=True, message_type=Gtk.MessageType.WARNING,
								  buttons=Gtk.ButtonsType.OK, text='No se ha podido expulsar la unidad.')
			d.format_secondary_text(e.message)
			d.run()
			d.destroy()
	op = Gtk.MountOperation(parent=ventana)
	if montaje.can_eject():
		montaje.eject_with_operation(Gio.MountUnmountFlags.NONE, op, None, hecho)
	else:
		montaje.unmount_with_operation(Gio.MountUnmountFlags.NONE, op, None, hecho)


def mostrar(archivos, padre=None, app=None, montaje=None):
	if not archivos:
		return None
	v = Propiedades(list(archivos), padre, app, montaje)
	v.present()
	return v


if __name__ == '__main__':
	cargar_css()
	lista = [Gio.File.new_for_commandline_arg(a) for a in sys.argv[1:]] or [Gio.File.new_for_path(os.path.expanduser('~'))]
	ventana = mostrar(lista)
	ventana.connect('destroy', Gtk.main_quit)
	Gtk.main()
