#!/usr/bin/env python3
"""Mandarin OS · Administrador de tareas, como el de Windows 10.

Pestañas: Procesos (aplicaciones, procesos en segundo plano y del sistema, con el consumo resaltado en amarillo),
Rendimiento (CPU, memoria, disco y red con gráficas de 60 s), Inicio, Usuarios, Detalles y Servicios.
«Menos detalles» deja solo la lista de aplicaciones. Ctrl+Mayús+Esc lo abre.

Uso: mandarin-tareas [procesos | rendimiento | inicio | usuarios | detalles | servicios]
"""
import collections
import configparser
import glob
import os
import shutil
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gi  # noqa: E402

from comun import Gdk, GdkPixbuf, Gio, GLib, Gtk, cargar_css, clase, ejecutar, etiqueta, oscuro, pixbuf  # noqa: E402,F401
from gi.repository import Pango  # noqa: E402
import psutil  # noqa: E402

try:
    gi.require_version('Wnck', '3.0')
    from gi.repository import Wnck
except (ImportError, ValueError):
    Wnck = None

GLib.set_prgname('mandarin-tareas')
GLib.set_application_name('Administrador de tareas')

PESTANAS = ['procesos', 'rendimiento', 'inicio', 'usuarios', 'detalles', 'servicios']
TITULOS = ['Procesos', 'Rendimiento', 'Inicio', 'Usuarios', 'Detalles', 'Servicios']
# colores de Windows 10 para cada recurso en «Rendimiento»
COLORES = {'cpu': (0.07, 0.47, 0.79), 'mem': (0.55, 0.07, 0.68), 'disco': (0.30, 0.65, 0.05), 'red': (0.65, 0.31, 0.0)}
CONFIG = os.path.expanduser('~/.config/mandarin/tareas')
NCPU = psutil.cpu_count() or 1

CSS = b"""
.m-tareas treeview.view { font-size: 9.5pt; }
.m-tareas treeview.view:selected { background-color: #cce8ff; color: #000000; }
.m-tareas list row:selected { background-color: #cce8ff; }
.m-tareas list row:selected label { color: #000000; }
.m-tareas notebook > header tab { padding: 4px 12px; }
.m-tareas .m-pie-tareas { padding: 6px 10px; border-top: 1px solid alpha(@theme_fg_color, 0.10); }
.m-cabecera-num { font-size: 10.5pt; }
.m-cabecera-txt { font-size: 8.5pt; color: alpha(@theme_fg_color, 0.65); }
.m-recurso { padding: 6px 8px; }
.m-recurso-titulo { font-size: 12pt; }
.m-grande { font-family: "Inter Display", "Inter", sans-serif; font-weight: 300; font-size: 20pt; }
.m-dato-num { font-size: 13pt; }
"""
# tema oscuro: la fila elegida en azul oscuro (como el Administrador de tareas de Windows 11) y no en azul claro
CSS_OSCURO = b"""
.m-tareas treeview.view:selected { background-color: #2b4f73; color: #ffffff; }
.m-tareas list row:selected { background-color: #2b4f73; }
.m-tareas list row:selected label { color: #ffffff; }
"""


def calor(f):
    """Color de fondo de la celda según el uso (0..1), como el amarillo de Windows 10.
    En el tema oscuro, ámbar oscuro (como Windows 11), para que el texto claro se siga leyendo."""
    if f is None:
        return None
    f = max(0.0, min(1.0, f))
    negro = oscuro()
    if f < 0.005:
        return '#332c22' if negro else '#fff9e3'
    a, b = ((0x3d, 0x33, 0x22), (0x7d, 0x55, 0x12)) if negro else ((0xff, 0xf4, 0xc4), (0xff, 0xb3, 0x47))
    if f > 0.85:
        return '#94401b' if negro else '#ff9a5c'
    t = min(1.0, f * 1.6)
    return '#%02x%02x%02x' % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def mb(n):
    return f'{n / 1048576:.1f} MB'.replace('.', ',')


def velocidad(bps):
    return f'{bps / 1048576:.1f} MB/s'.replace('.', ',')


def red_mbps(bps):
    return f'{bps * 8 / 1e6:.1f} Mbps'.replace('.', ',')


class Datos:
    """Lo que se mide cada segundo: procesos (con su CPU, memoria y disco) y los totales del equipo."""

    def __init__(self):
        self.procesos = {}  # pid -> psutil.Process (para que cpu_percent compare con la vez anterior)
        self.io_anterior = {}
        self.t_anterior = time.monotonic()
        self.disco_ant = psutil.disk_io_counters()
        self.red_ant = psutil.net_io_counters()
        self.historia = {k: collections.deque([0.0] * 60, maxlen=60) for k in COLORES}
        self.filas = []
        self.totales = {}
        psutil.cpu_percent(None)
        self.apps_por_exe = {}
        for app in Gio.AppInfo.get_all():
            exe = os.path.basename((app.get_executable() or '').split()[0]) if app.get_executable() else ''
            if exe and exe not in self.apps_por_exe:
                self.apps_por_exe[exe] = app

    def medir(self):
        ahora = time.monotonic()
        dt = max(0.2, ahora - self.t_anterior)
        self.t_anterior = ahora
        vivos = set()
        filas = []
        yo = os.getuid()
        for p in psutil.process_iter(['pid', 'name', 'username', 'uids', 'memory_info', 'status', 'cmdline', 'ppid',
                                      'num_threads', 'exe']):
            pid = p.info['pid']
            vivos.add(pid)
            proc = self.procesos.setdefault(pid, p)
            try:
                cpu = proc.cpu_percent(None) / NCPU
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                cpu = 0.0
            disco = 0.0
            try:
                io = proc.io_counters()
                total = io.read_bytes + io.write_bytes
                disco = max(0.0, (total - self.io_anterior.get(pid, total)) / dt)
                self.io_anterior[pid] = total
            except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError):
                pass
            mem = p.info['memory_info'].rss if p.info['memory_info'] else 0
            uid = p.info['uids'].real if p.info['uids'] else -1
            filas.append({'pid': pid, 'ppid': p.info['ppid'], 'nombre': p.info['name'] or '?', 'cpu': cpu, 'mem': mem,
                          'disco': disco, 'usuario': p.info['username'] or '', 'propio': uid == yo,
                          'estado': p.info['status'], 'hilos': p.info['num_threads'] or 0,
                          'cmd': ' '.join(p.info['cmdline'] or [])[:200], 'exe': p.info['exe'] or ''})
        for pid in list(self.procesos):
            if pid not in vivos:
                self.procesos.pop(pid, None)
                self.io_anterior.pop(pid, None)
        self.filas = filas
        cpu = psutil.cpu_percent(None)
        vm = psutil.virtual_memory()
        d = psutil.disk_io_counters()
        r = psutil.net_io_counters()
        disco_bps = ((d.read_bytes + d.write_bytes) - (self.disco_ant.read_bytes + self.disco_ant.write_bytes)) / dt if d and self.disco_ant else 0
        ocupado = 0.0
        if d and self.disco_ant and hasattr(d, 'busy_time'):
            ocupado = min(100.0, (d.busy_time - self.disco_ant.busy_time) / (dt * 10))
        red_bps = ((r.bytes_sent + r.bytes_recv) - (self.red_ant.bytes_sent + self.red_ant.bytes_recv)) / dt
        enviado = (r.bytes_sent - self.red_ant.bytes_sent) / dt
        recibido = (r.bytes_recv - self.red_ant.bytes_recv) / dt
        self.disco_ant, self.red_ant = d, r
        self.totales = {'cpu': cpu, 'mem': vm.percent, 'mem_usada': vm.total - vm.available, 'mem_total': vm.total,
                        'mem_libre': vm.available, 'disco': ocupado, 'disco_bps': disco_bps, 'red_bps': red_bps,
                        'enviado': enviado, 'recibido': recibido, 'procesos': len(filas),
                        'hilos': sum(f['hilos'] for f in filas)}
        self.historia['cpu'].append(cpu)
        self.historia['mem'].append(vm.percent)
        self.historia['disco'].append(ocupado)
        self.historia['red'].append(min(100.0, red_bps * 8 / 1e6))  # escala: 100 Mbps


class Grafica(Gtk.DrawingArea):
    """Gráfica de 60 s como las de Windows 10: rejilla clara, línea y relleno del color del recurso."""

    def __init__(self, datos, clave, rejilla=True):
        super().__init__()
        self.datos, self.clave, self.rejilla = datos, clave, rejilla
        self.connect('draw', self.dibujar)

    def dibujar(self, _w, cr):
        w, h = self.get_allocated_width(), self.get_allocated_height()
        r, g, b = COLORES[self.clave]
        negro = oscuro()
        if negro:   # más claro para que se vea sobre el fondo oscuro
            r, g, b = (r + 1) / 2, (g + 1) / 2, (b + 1) / 2
        cr.set_source_rgb(*((0.13, 0.12, 0.11) if negro else (1, 1, 1)))
        cr.paint()
        if self.rejilla:
            cr.set_source_rgba(r, g, b, 0.22 if negro else 0.12)
            cr.set_line_width(1)
            for i in range(1, 10):
                cr.move_to(0, int(h * i / 10) + 0.5)
                cr.line_to(w, int(h * i / 10) + 0.5)
            for i in range(1, 20):
                cr.move_to(int(w * i / 20) + 0.5, 0)
                cr.line_to(int(w * i / 20) + 0.5, h)
            cr.stroke()
        valores = list(self.datos.historia[self.clave])
        paso = w / (len(valores) - 1)
        cr.move_to(0, h)
        for i, v in enumerate(valores):
            cr.line_to(i * paso, h - h * v / 100)
        cr.line_to(w, h)
        cr.close_path()
        cr.set_source_rgba(r, g, b, 0.20 if negro else 0.10)
        cr.fill_preserve()
        cr.new_path()
        for i, v in enumerate(valores):
            (cr.move_to if i == 0 else cr.line_to)(i * paso, h - h * v / 100)
        cr.set_source_rgb(r, g, b)
        cr.set_line_width(1.2)
        cr.stroke()
        cr.rectangle(0.5, 0.5, w - 1, h - 1)
        cr.set_source_rgba(r, g, b, 0.6)
        cr.stroke()
        return True


class Tareas(Gtk.ApplicationWindow):
    def __init__(self, app, pestana='procesos'):
        super().__init__(application=app, title='Administrador de tareas')
        self.set_default_size(900, 640)
        self.set_icon_name('utilities-system-monitor')
        clase(self, 'm-tareas')
        self.datos = Datos()
        self.intervalo = 1000
        self.recurso = 'cpu'
        raiz = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(raiz)
        self.menu = self.barra_menu()
        raiz.pack_start(self.menu, False, False, 0)
        self.cuaderno = Gtk.Notebook()
        for funcion, titulo in zip((self.pestana_procesos, self.pestana_rendimiento, self.pestana_inicio,
                                    self.pestana_usuarios, self.pestana_detalles, self.pestana_servicios), TITULOS):
            self.cuaderno.append_page(funcion(), Gtk.Label(label=titulo))
        self.cuaderno.connect('switch-page', lambda _c, _p, n: GLib.idle_add(self.al_cambiar, n))
        raiz.pack_start(self.cuaderno, True, True, 0)
        self.sencillo = self.vista_sencilla()
        raiz.pack_start(self.sencillo, True, True, 0)
        raiz.pack_start(self.pie(), False, False, 0)
        self.show_all()
        self.detalles = True
        try:
            with open(CONFIG) as f:
                self.detalles = f.read().strip() != 'menos'
        except OSError:
            pass
        self.poner_detalles(self.detalles)
        if pestana in PESTANAS:
            self.cuaderno.set_current_page(PESTANAS.index(pestana))
        self.tictac()
        self.temporizador = GLib.timeout_add(self.intervalo, self.tictac)

    # ---------- menú y pie ----------
    def barra_menu(self):
        barra = Gtk.MenuBar()

        def menu(nombre, entradas):
            item = Gtk.MenuItem(label=nombre)
            sub = Gtk.Menu()
            for texto, f in entradas:
                if texto is None:
                    sub.append(Gtk.SeparatorMenuItem())
                    continue
                if isinstance(f, bool):
                    e = Gtk.CheckMenuItem(label=texto)
                    e.connect('toggled', lambda c: self.set_keep_above(c.get_active()))
                else:
                    e = Gtk.MenuItem(label=texto)
                    e.connect('activate', lambda _e, f=f: f())
                sub.append(e)
            item.set_submenu(sub)
            barra.append(item)

        menu('Archivo', [('Ejecutar nueva tarea', self.nueva_tarea), (None, None), ('Salir', self.close)])
        menu('Opciones', [('Siempre visible', False)])
        menu('Vista', [('Actualizar ahora', self.tictac), (None, None),
                       ('Velocidad de actualización: alta', lambda: self.velocidad(500)),
                       ('Velocidad de actualización: normal', lambda: self.velocidad(1000)),
                       ('Velocidad de actualización: baja', lambda: self.velocidad(4000))])
        return barra

    def pie(self):
        caja = clase(Gtk.Box(spacing=8), 'm-pie-tareas')
        self.b_detalles = clase(Gtk.Button(relief=Gtk.ReliefStyle.NONE), 'm-plano')
        self.b_detalles.connect('clicked', lambda *a: self.poner_detalles(not self.detalles))
        caja.pack_start(self.b_detalles, False, False, 0)
        self.b_finalizar = Gtk.Button(label='Finalizar tarea', sensitive=False)
        self.b_finalizar.connect('clicked', lambda *a: self.finalizar())
        caja.pack_end(self.b_finalizar, False, False, 0)
        return caja

    def poner_detalles(self, mas):
        self.detalles = mas
        self.cuaderno.set_visible(mas)
        self.menu.set_visible(mas)
        self.sencillo.set_visible(not mas)
        self.b_detalles.set_label('⌃  Menos detalles' if mas else '⌄  Más detalles')
        if not mas:
            self.resize(420, 380)
        else:
            self.resize(900, 640)
        os.makedirs(os.path.dirname(CONFIG), exist_ok=True)
        with open(CONFIG, 'w') as f:
            f.write('mas' if mas else 'menos')
        self.tictac()

    def velocidad(self, ms):
        self.intervalo = ms
        GLib.source_remove(self.temporizador)
        self.temporizador = GLib.timeout_add(ms, self.tictac)

    def nueva_tarea(self):
        d = Gtk.Dialog(title='Crear nueva tarea', transient_for=self, modal=True)
        d.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Aceptar', Gtk.ResponseType.OK)
        d.set_default_response(Gtk.ResponseType.OK)
        caja = d.get_content_area()
        caja.set_spacing(8)
        caja.set_border_width(12)
        caja.add(etiqueta('Escribe el nombre del programa, carpeta o documento que quieres abrir.'))
        entrada = Gtk.Entry(activates_default=True)
        caja.add(entrada)
        d.show_all()
        if d.run() == Gtk.ResponseType.OK and entrada.get_text().strip():
            texto = entrada.get_text().strip()
            if os.path.exists(os.path.expanduser(texto)):
                Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(os.path.expanduser(texto)).get_uri(), None)
            else:
                ejecutar('sh', '-c', texto)
        d.destroy()

    def al_cambiar(self, n):
        self.tictac()
        if PESTANAS[n] == 'inicio':
            self.cargar_inicio()
        elif PESTANAS[n] == 'servicios':
            self.cargar_servicios()
        return False

    # ---------- cada segundo ----------
    def tictac(self):
        self.datos.medir()
        if not self.detalles:
            self.pintar_sencillo()
            return True
        pagina = PESTANAS[self.cuaderno.get_current_page()]
        if pagina == 'procesos':
            self.pintar_procesos()
        elif pagina == 'rendimiento':
            self.pintar_rendimiento()
        elif pagina == 'usuarios':
            self.pintar_usuarios()
        elif pagina == 'detalles':
            self.pintar_detalles()
        return True

    # ---------- aplicaciones (ventanas abiertas) ----------
    def aplicaciones(self):
        """pid -> (nombre, icono) de los programas con ventana, como el grupo «Aplicaciones» de Windows."""
        apps = {}
        pantalla = Wnck.Screen.get_default() if Wnck is not None else None
        if pantalla is None:
            return self.aplicaciones_gdk()
        pantalla.force_update()
        if not pantalla.get_windows():
            return self.aplicaciones_gdk()
        for v in pantalla.get_windows():
            if v.get_window_type() != Wnck.WindowType.NORMAL or v.is_skip_tasklist():
                continue
            pid = v.get_pid()
            if pid <= 0 or pid == os.getpid() and False:
                continue
            nombre = (v.get_application().get_name() if v.get_application() else '') or v.get_name()
            apps.setdefault(pid, (nombre, v.get_mini_icon(), [])) [2].append(v)
        return apps

    def aplicaciones_gdk(self):
        """Respaldo sin Wnck: la lista de ventanas del gestor de ventanas (_NET_CLIENT_LIST_STACKING) leída con GDK.
        Las ventanas se cierran luego por su proceso (no hay objeto ventana al que pedírselo)."""
        apps = {}
        pantalla = Gdk.Screen.get_default()
        for gw in (pantalla.get_window_stack() or []) if pantalla else []:
            try:
                ok, _t, _f, datos = Gdk.property_get(gw, Gdk.Atom.intern('_NET_WM_PID', False),
                                                     Gdk.Atom.intern('CARDINAL', False), 0, 1, False)
                ok2, _t2, _f2, nombre = Gdk.property_get(gw, Gdk.Atom.intern('_NET_WM_NAME', False),
                                                         Gdk.Atom.intern('UTF8_STRING', False), 0, 1024, False)
            except (TypeError, GLib.Error):
                continue
            if not ok or not datos:
                continue
            pid = int.from_bytes(bytes(datos[:8]), 'little') & 0xffffffff
            texto = bytes(nombre).decode('utf-8', 'replace') if ok2 and nombre else ''
            apps.setdefault(pid, (texto, None, []))
        return apps

    def nombre_e_icono(self, fila):
        exe = os.path.basename(fila['exe']) or fila['nombre']
        app = self.datos.apps_por_exe.get(exe) or self.datos.apps_por_exe.get(fila['nombre'])
        if app is not None:
            return app.get_display_name(), pixbuf(app.get_icon(), 16)
        return fila['nombre'], None

    # ---------- Procesos ----------
    def pestana_procesos(self):
        # icono, nombre, cpu, mem, disco, red, fondo cpu, fondo mem, fondo disco, fondo red, pid, peso (negrita grupos)
        self.m_proc = Gtk.ListStore(GdkPixbuf.Pixbuf, str, str, str, str, str, str, str, str, str, int, int)
        vista = Gtk.TreeView(model=self.m_proc)
        vista.set_enable_search(True)
        vista.set_search_column(1)
        col = Gtk.TreeViewColumn()
        col.set_title('Nombre')
        col.set_expand(True)
        r_i = Gtk.CellRendererPixbuf(xpad=4)
        r_t = Gtk.CellRendererText(ellipsize=Pango.EllipsizeMode.END)
        col.pack_start(r_i, False)
        col.pack_start(r_t, True)
        col.add_attribute(r_i, 'pixbuf', 0)
        col.add_attribute(r_t, 'text', 1)
        col.add_attribute(r_t, 'weight', 11)
        vista.append_column(col)
        self.cabeceras = {}
        for i, (clave, titulo) in enumerate((('cpu', 'CPU'), ('mem', 'Memoria'), ('disco', 'Disco'), ('red', 'Red'))):
            r = Gtk.CellRendererText(xalign=1.0)
            c = Gtk.TreeViewColumn()
            c.pack_start(r, True)
            c.add_attribute(r, 'text', 2 + i)
            c.add_attribute(r, 'cell-background', 6 + i)
            c.set_min_width(96)
            caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            num = clase(Gtk.Label(label='0%', xalign=1), 'm-cabecera-num')
            caja.pack_start(num, False, False, 0)
            caja.pack_start(clase(Gtk.Label(label=titulo, xalign=1), 'm-cabecera-txt'), False, False, 0)
            caja.show_all()
            c.set_widget(caja)
            c.set_alignment(1.0)
            self.cabeceras[clave] = num
            vista.append_column(c)
        vista.get_selection().connect('changed', lambda s: self.b_finalizar.set_sensitive(self.pid_elegido() > 0))
        self.v_proc = vista
        desplaza = Gtk.ScrolledWindow()
        desplaza.add(vista)
        self.desplaza_proc = desplaza
        return desplaza

    def pid_elegido(self):
        if not self.detalles:
            fila = self.l_sencilla.get_selected_row()
            return fila.pid if fila else -1
        pagina = PESTANAS[self.cuaderno.get_current_page()]
        vista = self.v_proc if pagina == 'procesos' else (self.v_det if pagina == 'detalles' else None)
        if vista is None:
            return -1
        modelo, it = vista.get_selection().get_selected()
        if it is None:
            return -1
        return modelo[it][10] if pagina == 'procesos' else modelo[it][1]

    def pintar_procesos(self):
        apps = self.aplicaciones()
        filas = self.datos.filas
        hijos = collections.defaultdict(list)
        for f in filas:
            hijos[f['ppid']].append(f)
        por_pid = {f['pid']: f for f in filas}

        def suma(pid, clave, visto=None):
            visto = visto if visto is not None else set()
            if pid in visto:
                return 0
            visto.add(pid)
            f = por_pid.get(pid)
            return (f[clave] if f else 0) + sum(suma(h['pid'], clave, visto) for h in hijos.get(pid, []) if h['pid'] not in apps)

        grupo_apps, grupo_fondo, grupo_sistema = [], [], []
        dentro = set()
        for pid, (nombre, icono, _v) in apps.items():
            if pid not in por_pid:
                continue
            g = {'pid': pid, 'nombre': nombre, 'icono': icono, 'cpu': suma(pid, 'cpu'), 'mem': suma(pid, 'mem'),
                 'disco': suma(pid, 'disco')}
            grupo_apps.append(g)
            pila = [pid]
            while pila:
                x = pila.pop()
                dentro.add(x)
                pila += [h['pid'] for h in hijos.get(x, []) if h['pid'] not in apps]
        for f in filas:
            if f['pid'] in dentro or f['pid'] == 0:
                continue
            nombre, icono = self.nombre_e_icono(f)
            g = {'pid': f['pid'], 'nombre': nombre, 'icono': icono, 'cpu': f['cpu'], 'mem': f['mem'], 'disco': f['disco']}
            (grupo_fondo if f['propio'] else grupo_sistema).append(g)
        orden = lambda g: (-g['cpu'], -g['mem'])  # noqa: E731
        t = self.datos.totales
        self.cabeceras['cpu'].set_text(f"{t['cpu']:.0f}%")
        self.cabeceras['mem'].set_text(f"{t['mem']:.0f}%")
        self.cabeceras['disco'].set_text(f"{t['disco']:.0f}%")
        self.cabeceras['red'].set_text(f"{min(100, t['red_bps'] * 8 / 1e6):.0f}%")
        elegido = self.pid_elegido()
        valor = self.desplaza_proc.get_vadjustment().get_value()
        self.m_proc.clear()
        mem_total = t['mem_total'] or 1
        for titulo, grupo in (('Aplicaciones', grupo_apps), ('Procesos en segundo plano', grupo_fondo),
                              ('Procesos del sistema', grupo_sistema)):
            if not grupo:
                continue
            self.m_proc.append([None, f'{titulo} ({len(grupo)})', '', '', '', '', None, None, None, None, -1, 700])
            for g in sorted(grupo, key=orden):
                cpu = f"{g['cpu']:.1f} %".replace('.', ',')
                self.m_proc.append([g['icono'], g['nombre'], cpu, mb(g['mem']), velocidad(g['disco']), '0 Mbps',
                                    calor(g['cpu'] / 100), calor(g['mem'] / mem_total * 4), calor(g['disco'] / 20e6),
                                    calor(0), g['pid'], 400])
        if elegido > 0:
            for fila in self.m_proc:
                if fila[10] == elegido:
                    self.v_proc.get_selection().select_iter(fila.iter)
                    break
        GLib.idle_add(lambda: self.desplaza_proc.get_vadjustment().set_value(valor) and False)

    def finalizar(self):
        pid = self.pid_elegido()
        if pid <= 0:
            return
        apps = self.aplicaciones()
        if pid in apps:  # primero como Windows: pedir a sus ventanas que se cierren
            for v in apps[pid][2]:
                v.close(Gtk.get_current_event_time())
            GLib.timeout_add(1500, lambda: self.matar(pid, suave=False) or False)
            return
        self.matar(pid)

    def matar(self, pid, suave=True):
        try:
            p = psutil.Process(pid)
            if not p.is_running():
                return
            if p.uids().real == os.getuid():
                p.terminate() if suave else p.kill()
            else:
                ejecutar('pkexec', 'kill', '-TERM' if suave else '-KILL', str(pid))
        except psutil.NoSuchProcess:
            pass
        except psutil.AccessDenied:
            ejecutar('pkexec', 'kill', str(pid))
        GLib.timeout_add(400, lambda: self.tictac() and False)

    # ---------- Menos detalles ----------
    def vista_sencilla(self):
        self.l_sencilla = Gtk.ListBox()
        self.l_sencilla.connect('row-selected', lambda *a: self.b_finalizar.set_sensitive(self.pid_elegido() > 0))
        desplaza = Gtk.ScrolledWindow(margin=8)
        desplaza.add(self.l_sencilla)
        return desplaza

    def pintar_sencillo(self):
        apps = self.aplicaciones()
        elegido = self.pid_elegido()
        actuales = {f.pid: f for f in self.l_sencilla.get_children()}
        for pid, (nombre, icono, _v) in apps.items():
            if pid in actuales:
                continue
            fila = Gtk.ListBoxRow()
            fila.pid = pid
            caja = Gtk.Box(spacing=10, margin=6)
            caja.pack_start(Gtk.Image.new_from_pixbuf(icono) if icono else Gtk.Image(), False, False, 0)
            caja.pack_start(etiqueta(nombre, elipsis=True), True, True, 0)
            fila.add(caja)
            fila.show_all()
            self.l_sencilla.add(fila)
        for pid, fila in actuales.items():
            if pid not in apps:
                self.l_sencilla.remove(fila)
        if elegido > 0:
            for fila in self.l_sencilla.get_children():
                if fila.pid == elegido:
                    self.l_sencilla.select_row(fila)

    # ---------- Rendimiento ----------
    def pestana_rendimiento(self):
        caja = Gtk.Box()
        lista = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        lista.set_size_request(230, -1)
        self.mini = {}
        self.mini_txt = {}
        for clave, titulo in (('cpu', 'CPU'), ('mem', 'Memoria'), ('disco', 'Disco 0'), ('red', 'Red')):
            fila = Gtk.ListBoxRow()
            fila.clave = clave
            h = clase(Gtk.Box(spacing=10), 'm-recurso')
            g = Grafica(self.datos, clave, rejilla=False)
            g.set_size_request(70, 46)
            h.pack_start(g, False, False, 0)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
            v.pack_start(clase(etiqueta(titulo), 'm-recurso-titulo'), False, False, 0)
            txt = clase(etiqueta(''), 'm-tenue', 'm-pie')
            v.pack_start(txt, False, False, 0)
            h.pack_start(v, True, True, 0)
            fila.add(h)
            lista.add(fila)
            self.mini[clave], self.mini_txt[clave] = g, txt
        lista.connect('row-selected', lambda _l, f: f and self.elegir_recurso(f.clave))
        lado = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        lado.add(lista)
        caja.pack_start(lado, False, False, 0)
        caja.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 0)
        derecha = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=16)
        cab = Gtk.Box()
        self.r_titulo = clase(etiqueta('CPU'), 'm-grande')
        self.r_modelo = clase(etiqueta('', xalign=1, elipsis=True), 'm-tenue')
        cab.pack_start(self.r_titulo, False, False, 0)
        cab.pack_end(self.r_modelo, True, True, 0)
        derecha.pack_start(cab, False, False, 0)
        sub = Gtk.Box()
        self.r_eje = clase(etiqueta('% de utilización'), 'm-tenue', 'm-pie')
        sub.pack_start(self.r_eje, False, False, 0)
        sub.pack_end(clase(etiqueta('100%', xalign=1), 'm-tenue', 'm-pie'), False, False, 0)
        derecha.pack_start(sub, False, False, 0)
        self.grande = Grafica(self.datos, 'cpu')
        self.grande.set_size_request(-1, 260)
        derecha.pack_start(self.grande, True, True, 0)
        pie = Gtk.Box()
        pie.pack_start(clase(etiqueta('60 segundos'), 'm-tenue', 'm-pie'), False, False, 0)
        pie.pack_end(clase(etiqueta('0', xalign=1), 'm-tenue', 'm-pie'), False, False, 0)
        derecha.pack_start(pie, False, False, 0)
        self.r_datos = Gtk.Grid(column_spacing=40, row_spacing=4, margin_top=10)
        derecha.pack_start(self.r_datos, False, False, 0)
        caja.pack_start(derecha, True, True, 0)
        lista.select_row(lista.get_row_at_index(0))
        return caja

    def elegir_recurso(self, clave):
        self.recurso = clave
        self.grande.clave = clave
        if self.datos.totales:  # (al construir la pestaña aún no se ha medido nada)
            self.pintar_rendimiento()

    def procesador(self):
        try:
            with open('/proc/cpuinfo') as f:
                for linea in f:
                    if linea.startswith('model name'):
                        return ' '.join(linea.split(':', 1)[1].split())
        except OSError:
            pass
        return ''

    def pintar_rendimiento(self):
        t = self.datos.totales
        self.mini_txt['cpu'].set_text(f"{t['cpu']:.0f}%")
        self.mini_txt['mem'].set_text(f"{t['mem_usada'] / 2**30:.1f}/{t['mem_total'] / 2**30:.1f} GB ({t['mem']:.0f}%)".replace('.', ','))
        self.mini_txt['disco'].set_text(f"{t['disco']:.0f}%")
        self.mini_txt['red'].set_text(f"E: {red_mbps(t['enviado'])}  R: {red_mbps(t['recibido'])}")
        for g in self.mini.values():
            g.queue_draw()
        self.grande.queue_draw()
        clave = self.recurso
        titulos = {'cpu': 'CPU', 'mem': 'Memoria', 'disco': 'Disco 0', 'red': 'Red'}
        self.r_titulo.set_text(titulos[clave])
        ejes = {'cpu': '% de utilización', 'mem': 'Uso de memoria', 'disco': 'Tiempo activo', 'red': 'Rendimiento (100 Mbps)'}
        self.r_eje.set_text(ejes[clave])
        if clave == 'cpu':
            self.r_modelo.set_text(self.procesador())
            frec = psutil.cpu_freq()
            arranque = time.time() - psutil.boot_time()
            datos = [('Uso', f"{t['cpu']:.0f}%"), ('Velocidad', f'{frec.current / 1000:.2f} GHz'.replace('.', ',') if frec else '—'),
                     ('Procesos', str(t['procesos'])), ('Subprocesos', str(t['hilos'])),
                     ('Núcleos lógicos', str(NCPU)),
                     ('Tiempo activo', f'{int(arranque // 86400)}:{int(arranque % 86400 // 3600):02d}:{int(arranque % 3600 // 60):02d}:{int(arranque % 60):02d}')]
        elif clave == 'mem':
            self.r_modelo.set_text(f"{t['mem_total'] / 2**30:.1f} GB".replace('.', ','))
            sw = psutil.swap_memory()
            datos = [('En uso', f"{t['mem_usada'] / 2**30:.1f} GB".replace('.', ',')),
                     ('Disponible', f"{t['mem_libre'] / 2**30:.1f} GB".replace('.', ',')),
                     ('Memoria de intercambio', f'{sw.used / 2**30:.1f}/{sw.total / 2**30:.1f} GB'.replace('.', ','))]
        elif clave == 'disco':
            uso = psutil.disk_usage('/')
            self.r_modelo.set_text(f'{uso.total / 1e9:.0f} GB')
            datos = [('Tiempo activo', f"{t['disco']:.0f}%"), ('Velocidad', velocidad(t['disco_bps'])),
                     ('Capacidad', f'{uso.total / 1e9:.0f} GB'), ('Usado', f'{uso.percent:.0f}%')]
        else:
            self.r_modelo.set_text('')
            datos = [('Enviar', red_mbps(t['enviado'])), ('Recibir', red_mbps(t['recibido']))]
        for h in self.r_datos.get_children():
            self.r_datos.remove(h)
        for i, (k, v) in enumerate(datos):
            col, fila = (i % 3), (i // 3) * 2
            self.r_datos.attach(clase(etiqueta(k), 'm-tenue', 'm-pie'), col, fila, 1, 1)
            self.r_datos.attach(clase(etiqueta(v), 'm-dato-num'), col, fila + 1, 1, 1)
        self.r_datos.show_all()

    # ---------- Inicio ----------
    def pestana_inicio(self):
        # nombre, editor, estado, impacto, ruta, icono
        self.m_ini = Gtk.ListStore(str, str, str, str, str, GdkPixbuf.Pixbuf)
        vista = Gtk.TreeView(model=self.m_ini)
        col = Gtk.TreeViewColumn()
        col.set_title('Nombre')
        col.set_expand(True)
        r_i, r_t = Gtk.CellRendererPixbuf(xpad=4), Gtk.CellRendererText()
        col.pack_start(r_i, False)
        col.pack_start(r_t, True)
        col.add_attribute(r_i, 'pixbuf', 5)
        col.add_attribute(r_t, 'text', 0)
        vista.append_column(col)
        for i, titulo in ((1, 'Editor'), (2, 'Estado'), (3, 'Impacto de inicio')):
            vista.append_column(Gtk.TreeViewColumn(titulo, Gtk.CellRendererText(), text=i))
        self.v_ini = vista
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        desplaza = Gtk.ScrolledWindow()
        desplaza.add(vista)
        caja.pack_start(desplaza, True, True, 0)
        botones = Gtk.Box(spacing=8, margin=8)
        b = Gtk.Button(label='Habilitar / Deshabilitar')
        b.connect('clicked', lambda *a: self.alternar_inicio())
        botones.pack_end(b, False, False, 0)
        caja.pack_start(botones, False, False, 0)
        return caja

    def entradas_inicio(self):
        entradas = {}
        for carpeta in ('/etc/xdg/autostart', os.path.expanduser('~/.config/autostart')):
            for ruta in sorted(glob.glob(os.path.join(carpeta, '*.desktop'))):
                entradas[os.path.basename(ruta)] = ruta  # la del usuario manda sobre la del sistema
        return entradas

    def cargar_inicio(self):
        self.m_ini.clear()
        for nombre, ruta in self.entradas_inicio().items():
            if nombre.startswith('mandarin-'):
                continue  # piezas del propio sistema: no se ofrecen para desactivar
            c = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                c.read(ruta, encoding='utf-8')
                e = c['Desktop Entry']
            except (configparser.Error, KeyError, UnicodeDecodeError):
                continue
            if e.get('NoDisplay', 'false') == 'true' and not ruta.startswith(os.path.expanduser('~')):
                continue
            activo = e.get('Hidden', 'false') != 'true' and e.get('X-GNOME-Autostart-enabled', 'true') != 'false'
            icono = None
            if e.get('Icon'):
                icono = pixbuf(Gio.ThemedIcon.new(e.get('Icon')), 16)
            self.m_ini.append([e.get('Name[es]', e.get('Name', nombre)), e.get('X-Mandarin-Editor', '—'),
                               'Habilitado' if activo else 'Deshabilitado', 'No medido', ruta, icono])

    def alternar_inicio(self):
        modelo, it = self.v_ini.get_selection().get_selected()
        if it is None:
            return
        ruta = modelo[it][4]
        propio = os.path.join(os.path.expanduser('~/.config/autostart'), os.path.basename(ruta))
        os.makedirs(os.path.dirname(propio), exist_ok=True)
        if ruta != propio:
            shutil.copy(ruta, propio)
        with open(propio, encoding='utf-8') as f:
            lineas = [x for x in f.read().splitlines() if not x.startswith('Hidden=')]
        if modelo[it][2] == 'Habilitado':
            i = next((n for n, x in enumerate(lineas) if x.strip() == '[Desktop Entry]'), 0)
            lineas.insert(i + 1, 'Hidden=true')
        with open(propio, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lineas) + '\n')
        self.cargar_inicio()

    # ---------- Usuarios ----------
    def pestana_usuarios(self):
        self.m_usu = Gtk.ListStore(str, str, str, str, str)
        vista = Gtk.TreeView(model=self.m_usu)
        for i, (titulo, derecha) in enumerate((('Usuario', False), ('Estado', False), ('CPU', True), ('Memoria', True))):
            c = Gtk.TreeViewColumn(titulo, Gtk.CellRendererText(xalign=1.0 if derecha else 0.0), text=i)
            c.set_expand(i == 0)
            vista.append_column(c)
        desplaza = Gtk.ScrolledWindow()
        desplaza.add(vista)
        return desplaza

    def pintar_usuarios(self):
        conectados = {u.name for u in psutil.users()} | {os.environ.get('USER', '')}
        cpu, mem = collections.Counter(), collections.Counter()
        for f in self.datos.filas:
            cpu[f['usuario']] += f['cpu']
            mem[f['usuario']] += f['mem']
        self.m_usu.clear()
        for u in sorted(x for x in conectados if x):
            self.m_usu.append([u, 'Conectado', f'{cpu[u]:.1f} %'.replace('.', ','), mb(mem[u]), u])

    # ---------- Detalles ----------
    def pestana_detalles(self):
        # nombre, pid, estado, usuario, cpu, memoria, descripción
        self.m_det = Gtk.ListStore(str, int, str, str, str, str, str)
        vista = Gtk.TreeView(model=self.m_det)
        for i, (titulo, derecha) in enumerate((('Nombre', False), ('PID', True), ('Estado', False), ('Nombre de usuario', False),
                                               ('CPU', True), ('Memoria', True), ('Descripción', False))):
            r = Gtk.CellRendererText(xalign=1.0 if derecha else 0.0, ellipsize=Pango.EllipsizeMode.END if i == 6 else Pango.EllipsizeMode.NONE)
            c = Gtk.TreeViewColumn(titulo, r, text=i)
            c.set_resizable(True)
            c.set_sort_column_id(i)
            c.set_expand(i == 6)
            vista.append_column(c)
        vista.get_selection().connect('changed', lambda s: self.b_finalizar.set_sensitive(self.pid_elegido() > 0))
        self.v_det = vista
        desplaza = Gtk.ScrolledWindow()
        desplaza.add(vista)
        self.desplaza_det = desplaza
        return desplaza

    def pintar_detalles(self):
        estados = {'running': 'En ejecución', 'sleeping': 'En ejecución', 'idle': 'En ejecución', 'stopped': 'Suspendido',
                   'zombie': 'Sin respuesta', 'disk-sleep': 'En ejecución'}
        elegido = self.pid_elegido()
        valor = self.desplaza_det.get_vadjustment().get_value()
        orden = self.m_det.get_sort_column_id()
        self.m_det.clear()
        for f in sorted(self.datos.filas, key=lambda f: f['nombre'].lower()):
            self.m_det.append([f['nombre'], f['pid'], estados.get(f['estado'], f['estado']), f['usuario'],
                               f"{f['cpu']:02.0f}", f"{f['mem'] // 1024:,} K".replace(',', '.'), f['cmd']])
        if orden[0] is not None and orden[0] >= 0:
            self.m_det.set_sort_column_id(*orden)
        if elegido > 0:
            for fila in self.m_det:
                if fila[1] == elegido:
                    self.v_det.get_selection().select_iter(fila.iter)
                    break
        GLib.idle_add(lambda: self.desplaza_det.get_vadjustment().set_value(valor) and False)

    # ---------- Servicios ----------
    def pestana_servicios(self):
        self.m_ser = Gtk.ListStore(str, str, str)
        vista = Gtk.TreeView(model=self.m_ser)
        for i, titulo in enumerate(('Nombre', 'Descripción', 'Estado')):
            c = Gtk.TreeViewColumn(titulo, Gtk.CellRendererText(ellipsize=Pango.EllipsizeMode.END), text=i)
            c.set_resizable(True)
            c.set_sort_column_id(i)
            c.set_expand(i == 1)
            vista.append_column(c)
        self.v_ser = vista
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        desplaza = Gtk.ScrolledWindow()
        desplaza.add(vista)
        caja.pack_start(desplaza, True, True, 0)
        botones = Gtk.Box(spacing=8, margin=8)
        for texto, accion in (('Detener', 'stop'), ('Reiniciar', 'restart'), ('Iniciar', 'start')):
            b = Gtk.Button(label=texto)
            b.connect('clicked', lambda _b, a=accion: self.servicio(a))
            botones.pack_end(b, False, False, 0)
        caja.pack_start(botones, False, False, 0)
        return caja

    def cargar_servicios(self):
        self.m_ser.clear()
        try:
            salida = subprocess.run(['systemctl', 'list-units', '--type=service', '--all', '--no-legend', '--plain',
                                     '--no-pager'], capture_output=True, text=True, timeout=10).stdout
        except (OSError, subprocess.SubprocessError):
            return
        for linea in salida.splitlines():
            partes = linea.split(None, 4)
            if len(partes) < 5:
                continue
            unidad, _carga, activo, sub, descripcion = partes
            estado = 'En ejecución' if sub == 'running' else ('Detenido' if activo != 'active' else sub)
            self.m_ser.append([unidad.removesuffix('.service'), descripcion, estado])

    def servicio(self, accion):
        modelo, it = self.v_ser.get_selection().get_selected()
        if it is None:
            return
        subprocess.Popen(['pkexec', 'systemctl', accion, modelo[it][0] + '.service'])
        GLib.timeout_add(2500, lambda: self.cargar_servicios() or False)


class AppTareas(Gtk.Application):
    def __init__(self):
        super().__init__(application_id='org.mandarinos.Tareas', flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)

    def do_startup(self):
        Gtk.Application.do_startup(self)
        cargar_css(CSS + (CSS_OSCURO if oscuro() else b''))

    def do_command_line(self, linea):
        args = [a for a in linea.get_arguments()[1:] if not a.startswith('-')]
        ventana = self.get_active_window()
        if ventana is None:
            ventana = Tareas(self, args[0] if args else 'procesos')
        elif args and args[0] in PESTANAS:
            ventana.cuaderno.set_current_page(PESTANAS.index(args[0]))
        ventana.present()
        return 0


if __name__ == '__main__':
    sys.exit(AppTareas().run(sys.argv))
