/* Mandarin OS · franja de arriba del instalador (en lugar de la lista lateral), como la instalación de un Mac:
   el logo pequeño, puntos de progreso (hechos en naranja claro, el actual en naranja) y el nombre del paso. */
import io.calamares.ui 1.0
import QtQuick 2.3

// Calamares toma la altura de la raíz (entre 16 y 64 px): sin anchors.fill, que la dejaba a 0
Rectangle {
    id: franja
    color: "#ffffff"
    height: 64

    Image {
        anchors.left: parent.left
        anchors.leftMargin: 22
        anchors.verticalCenter: parent.verticalCenter
        source: "file:/" + Branding.imagePath(Branding.ProductLogo)
        sourceSize.height: 30
        height: 30
        fillMode: Image.PreserveAspectFit
        smooth: true
    }

    Column {
        anchors.centerIn: parent
        spacing: 8

        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 12
            Repeater {
                model: ViewManager
                Rectangle {
                    width: index == ViewManager.currentStepIndex ? 22 : 8
                    height: 8
                    radius: 4
                    color: index == ViewManager.currentStepIndex ? "#f26b1d"
                         : (index < ViewManager.currentStepIndex ? "#ffc8a0" : "#e5e5ea")
                    Behavior on width { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                    Behavior on color { ColorAnimation { duration: 220 } }
                }
            }
        }

        // el nombre del paso actual
        Repeater {
            model: ViewManager
            Text {
                visible: index == ViewManager.currentStepIndex
                anchors.horizontalCenter: parent.horizontalCenter
                text: display
                color: "#8e8e93"
                font.family: "Inter"
                font.pixelSize: 13
                font.letterSpacing: 0.4
            }
        }
    }

    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width
        height: 1
        color: "#f2f2f7"
    }
}
