/* Mandarin OS · lo que se ve mientras se instala: arriba el logo y «mandarin» con el brillo de cristal del
   arranque; en medio, diapositivas con capturas del sistema y lo bueno de Linux, que cambian solas cada 7 s;
   abajo, puntos de progreso. Las capturas las prepara distro/arte/sistema/generar-diapositivas.sh. */
import QtQuick 2.0

Item {
    id: raiz
    property bool activo: false
    function onActivate() { activo = true }
    function onLeave() { activo = false }

    property int actual: 0
    property var diapositivas: [
        { img: "diapositivas/1.jpg", titulo: "Un escritorio que ya conoces",
          texto: "Menú de inicio, barra de tareas y papelera donde siempre. Nada nuevo que aprender." },
        { img: "diapositivas/2.jpg", titulo: "El menú de inicio",
          texto: "Tus programas, tus carpetas y un buscador. Ábrelo con el botón naranja o con la tecla Windows." },
        { img: "diapositivas/3.jpg", titulo: "Explorador de archivos",
          texto: "Inicio, Galería y Este equipo, como en Windows. Y «Extraer aquí» para los archivos ZIP." },
        { img: "diapositivas/4.jpg", titulo: "Panel de control",
          texto: "Todo el sistema ordenado por categorías: pantalla, sonido, programas, cuentas…" },
        { img: "diapositivas/5.jpg", titulo: "Cristal de verdad",
          texto: "En los equipos con gráfica moderna, el menú y las ventanas son de cristal esmerilado." },
        { img: "", titulo: "Miles de programas",
          texto: "La Tienda trae Flathub: Discord, Spotify, VLC, Steam… y los programas de Windows (.exe) se abren solos con Wine." },
        { img: "", titulo: "Libre, seguro y para siempre",
          texto: "Por dentro es Debian: sin virus de Windows, sin anuncios ni rastreo, y con actualizaciones gratis. Tu equipo antiguo, como el primer día." }
    ]

    Rectangle { anchors.fill: parent; color: "#ffffff" }

    Row {
        id: cabecera
        anchors.top: parent.top
        anchors.topMargin: 16
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 10
        Image { source: "logo-lateral.png"; width: 28; height: 28; smooth: true; anchors.verticalCenter: parent.verticalCenter }
        Image {
            id: palabra
            property int paso: 0
            source: (paso < 60 ? "palabra/palabra-" + paso : "palabra/palabra-base") + ".png"
            height: 28
            fillMode: Image.PreserveAspectFit
            smooth: true
            anchors.verticalCenter: parent.verticalCenter
        }
    }

    Item {
        id: escena
        anchors.top: cabecera.bottom
        anchors.topMargin: 14
        anchors.bottom: puntos.top
        anchors.bottomMargin: 10
        anchors.left: parent.left
        anchors.right: parent.right

        Repeater {
            model: raiz.diapositivas.length
            Item {
                anchors.fill: parent
                opacity: index === raiz.actual ? 1 : 0
                visible: opacity > 0
                Behavior on opacity { NumberAnimation { duration: 600; easing.type: Easing.InOutQuad } }
                property var d: raiz.diapositivas[index]

                Column {
                    anchors.centerIn: parent
                    spacing: 16

                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: Math.min(escena.width * 0.74, (escena.height - 110) * 1.6)
                        height: width / 1.6
                        radius: 8
                        color: "#ffffff"
                        border.color: d.img !== "" ? "#e5e5ea" : "transparent"
                        Image {
                            anchors.fill: parent
                            anchors.margins: d.img !== "" ? 1 : parent.height * 0.18
                            source: d.img !== "" ? d.img : "logo.png"
                            fillMode: d.img !== "" ? Image.PreserveAspectCrop : Image.PreserveAspectFit
                            smooth: true
                            asynchronous: true
                        }
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: d.titulo
                        color: "#1c1c1e"
                        font.family: "Inter"
                        font.weight: Font.Light
                        font.pixelSize: 26
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: Math.min(escena.width * 0.7, 640)
                        text: d.texto
                        color: "#8e8e93"
                        font.family: "Inter"
                        font.pixelSize: 16
                        wrapMode: Text.WordWrap
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
            }
        }
    }

    Row {
        id: puntos
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 12
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 8
        Repeater {
            model: raiz.diapositivas.length
            Rectangle {
                width: index === raiz.actual ? 18 : 6
                height: 6
                radius: 3
                color: index === raiz.actual ? "#f26b1d" : "#e5e5ea"
                Behavior on width { NumberAnimation { duration: 220 } }
            }
        }
    }

    Timer {
        interval: 20; repeat: true; running: raiz.activo
        onTriggered: palabra.paso = (palabra.paso + 1) % 120
    }
    Timer {
        interval: 7000; repeat: true; running: raiz.activo
        onTriggered: raiz.actual = (raiz.actual + 1) % raiz.diapositivas.length
    }
}
