/* Mandarin OS · botones del instalador, como la instalación de un Mac: «Atrás» de texto a la izquierda, «Salir»
   discreto, y «Continuar» (o «Instalar», «Hecho») como botón naranja relleno a la derecha. */
import io.calamares.ui 1.0
import io.calamares.core 1.0
import QtQuick 2.3

// Calamares toma la altura de la raíz (entre 16 y 64 px): sin anchors.fill, que la dejaba a 0
Rectangle {
    id: barra
    color: "#ffffff"
    height: 64

    function limpio(t) { return (t || "").replace("&", "") }

    // botón de texto (Atrás, Salir)
    component Enlace: Item {
        id: enl
        property string texto: ""
        property color tinta: "#f26b1d"
        signal pulsado()
        width: etiqueta.implicitWidth + 24
        height: 40
        opacity: enabled ? 1 : 0.35
        Text {
            id: etiqueta
            anchors.centerIn: parent
            text: enl.texto
            color: zona.pressed ? Qt.darker(enl.tinta, 1.3) : enl.tinta
            font.family: "Inter"
            font.pixelSize: 16
        }
        MouseArea { id: zona; anchors.fill: parent; enabled: enl.enabled; cursorShape: Qt.PointingHandCursor; onClicked: enl.pulsado() }
    }

    Enlace {
        anchors.left: parent.left
        anchors.leftMargin: 28
        anchors.verticalCenter: parent.verticalCenter
        texto: "‹  " + barra.limpio(ViewManager.backLabel)
        enabled: ViewManager.backEnabled
        visible: ViewManager.backAndNextVisible
        onPulsado: ViewManager.back()
    }

    Row {
        anchors.right: parent.right
        anchors.rightMargin: 28
        anchors.verticalCenter: parent.verticalCenter
        spacing: 18

        Enlace {
            anchors.verticalCenter: parent.verticalCenter
            texto: barra.limpio(ViewManager.quitLabel)
            tinta: "#8e8e93"
            enabled: ViewManager.quitEnabled
            visible: ViewManager.quitVisible && !principal.final_
            onPulsado: ViewManager.quit()
        }

        // el principal: naranja relleno
        Rectangle {
            id: principal
            visible: ViewManager.backAndNextVisible || ViewManager.quitVisible
            // en el último paso («Terminar») el botón naranja es «Hecho»
            property bool final_: !ViewManager.backAndNextVisible
                                  || ViewManager.currentStepIndex >= ViewManager.rowCount() - 1
            property bool activo: final_ ? ViewManager.quitEnabled : ViewManager.nextEnabled
            width: Math.max(150, texto.implicitWidth + 56)
            height: 42
            radius: 8
            color: !activo ? "#f2c8ad" : (zona2.pressed ? "#c9540f" : (zona2.containsMouse ? "#f47d36" : "#f26b1d"))
            Behavior on color { ColorAnimation { duration: 120 } }
            scale: zona2.pressed ? 0.97 : 1
            Behavior on scale { NumberAnimation { duration: 90 } }
            Text {
                id: texto
                anchors.centerIn: parent
                text: principal.final_ ? barra.limpio(ViewManager.quitLabel) : barra.limpio(ViewManager.nextLabel)
                color: "#ffffff"
                font.family: "Inter"
                font.pixelSize: 16
                font.weight: Font.DemiBold
            }
            MouseArea {
                id: zona2
                anchors.fill: parent
                hoverEnabled: true
                enabled: principal.activo
                cursorShape: Qt.PointingHandCursor
                onClicked: principal.final_ ? ViewManager.quit() : ViewManager.next()
            }
        }
    }
}
