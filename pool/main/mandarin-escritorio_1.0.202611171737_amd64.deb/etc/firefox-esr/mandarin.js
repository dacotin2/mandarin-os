// Mandarin OS: Firefox con la barra de título del sistema, para que lleve el marco de cristal de Mandarin
// (con las pestañas en la barra, Firefox dibuja la suya y picom difuminaba su margen de sombra: salía un halo)
pref("browser.tabs.inTitlebar", 0);
